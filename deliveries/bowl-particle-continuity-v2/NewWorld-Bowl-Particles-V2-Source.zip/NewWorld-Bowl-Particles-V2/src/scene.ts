import {bowlPose,drawBowl,project} from './bowl';
import {initParticles,drawFirst,drawMorph,surfaceFeedback} from './particles';
import {bezier,camera,clamp,ease,hash,lerp,phase,screen} from './math';

const W=1920,H=1080,INK='#e8eceb',SOFT='#97a3a8',RED='#eb666d',TEAL='#a0b9bc';
type Ctx=CanvasRenderingContext2D;
const make=()=>{const c=document.createElement('canvas');c.width=W;c.height=H;return c};
let title:HTMLCanvasElement,source:HTMLCanvasElement,final:HTMLCanvasElement;

const STEP=5;
const words=(c:Ctx,t:string,x:number,y:number,size=42,color=INK,display=false)=>{c.fillStyle=color;c.font=`${display?'700':'400'} ${size}px ${display?'BowlDisplay':'BowlSans'}`;c.fillText(t,x,y)};
const line=(c:Ctx,a:number,b:number,d:number,e:number,color=SOFT,width=2)=>{c.beginPath();c.moveTo(a,b);c.lineTo(d,e);c.strokeStyle=color;c.lineWidth=width;c.stroke()};
function shadow(c:Ctx,x:number,y:number,w:number,h:number,alpha=.5){const g=c.createRadialGradient(x,y,0,x,y,w);g.addColorStop(0,`rgba(0,0,0,${alpha})`);g.addColorStop(1,'rgba(0,0,0,0)');c.save();c.translate(x,y);c.scale(1,h/w);c.fillStyle=g; // normalized elliptical shadow, kept local
 c.restore();c.save();c.translate(x,y);c.scale(1,h/w);const q=c.createRadialGradient(0,0,0,0,0,w);q.addColorStop(0,`rgba(0,0,0,${alpha})`);q.addColorStop(1,'transparent');c.fillStyle=q;c.fillRect(-w,-w,w*2,w*2);c.restore()}
function world(c:Ctx,f:number,fn:()=>void){const q=camera(f);c.save();c.translate(q.x,q.y);c.scale(q.s,q.s);fn();c.restore()}
function titleAt(c:Ctx,x=180){words(c,'碗洗了',x,447,140,INK,true);words(c,'为什么还在吵？',x,583,92,INK,true);line(c,x,630,x+84,630,RED,4)}

function finalScene(c:Ctx,includeWord=true){
 words(c,'01',145,190,45,RED);if(includeWord)words(c,'约定落空',235,192,74,INK,true);
 words(c,'饭后分工，已经说好。',145,263,40,SOFT);
 // A common work surface, not two information cards.
 const top=c.createLinearGradient(0,455,0,890);top.addColorStop(0,'#2c343a');top.addColorStop(1,'#181e23');c.fillStyle=top;c.beginPath();c.moveTo(222,515);c.lineTo(1526,515);c.lineTo(1680,838);c.lineTo(102,838);c.closePath();c.fill();line(c,102,838,1680,838,'#535e64',1.5);
 line(c,381,403,1250,403,'#69797f',2);line(c,381,403,381,450,'#69797f',2);line(c,1250,403,1250,450,'#69797f',2);
 words(c,'阿宁 · 做饭',272,470,42,INK);words(c,'小乔 · 收拾',1140,470,42,INK);
 // Finished meal: an empty serving plate and a closed pot, modeled as layered ellipses.
 shadow(c,428,732,225,48,.65);c.fillStyle='#727c81';c.beginPath();c.ellipse(400,686,163,62,0,0,Math.PI*2);c.fill();c.fillStyle='#c2cccd';c.beginPath();c.ellipse(400,676,166,60,0,0,Math.PI*2);c.fill();c.strokeStyle='#84969d';c.lineWidth=3;c.beginPath();c.ellipse(400,674,127,42,0,0,Math.PI*2);c.stroke();
 c.fillStyle='#414e55';c.beginPath();c.ellipse(508,613,108,33,0,0,Math.PI*2);c.fill();c.fillRect(400,606,216,57);c.beginPath();c.ellipse(508,658,108,30,0,0,Math.PI*2);c.fill();const lid=c.createLinearGradient(400,560,590,630);lid.addColorStop(0,'#a5b4b9');lid.addColorStop(1,'#52616b');c.fillStyle=lid;c.beginPath();c.ellipse(508,603,115,38,0,Math.PI,Math.PI*2);c.fill();c.beginPath();c.ellipse(508,602,115,22,0,0,Math.PI*2);c.fill();c.fillStyle='#273137';c.fillRect(494,560,28,26);
 line(c,240,659,240,755,'#9caaad',5);for(let i=0;i<4;i++)line(c,230+i*6,644,230+i*6,674,'#9caaad',2);line(c,676,635,676,755,'#a2afb2',6);
 // Same bowl, now dirty, and another dish behind it: the undone task remains material.
 shadow(c,1232,753,280,52,.7);drawBowl(c,{x:1342,y:620,s:.60,pitch:.79,yaw:.25,roll:.04},true,false);drawBowl(c,{x:1214,y:685,s:.88,pitch:.87,yaw:.85,roll:.075},true,false);
 c.strokeStyle=TEAL;c.lineWidth=3;c.beginPath();c.arc(380,903,14,0,Math.PI*2);c.stroke();c.beginPath();c.moveTo(373,903);c.lineTo(379,909);c.lineTo(388,896);c.stroke();words(c,'已完成',414,917,34,TEAL);
 c.strokeStyle=RED;c.beginPath();c.arc(1218,903,14,-Math.PI*.4,Math.PI*1.2);c.stroke();words(c,'仍未收拾',1250,917,34,RED);
 // Time locates a fictional event. No relationship score or psychological gauge.
 c.save();c.translate(1596,296);c.strokeStyle='#6b7c84';c.lineWidth=2;c.beginPath();c.arc(0,0,54,0,Math.PI*2);c.stroke();for(let i=0;i<12;i++){const a=i*Math.PI/6;line(c,Math.sin(a)*45,-Math.cos(a)*45,Math.sin(a)*49,-Math.cos(a)*49,'#91a1a8',2)}line(c,0,0,-29,7,INK,3);line(c,0,0,0,37,INK,2);c.restore();words(c,'21:30',1510,393,43,INK,true);
}

export function prepare(){
 if(title)return;
 title=make();titleAt(title.getContext('2d')!);
 const sourceBowl=make(),sourceWord=make(),targetWord=make();
 world(sourceBowl.getContext('2d')!,200,()=>drawBowl(sourceBowl.getContext('2d')!,bowlPose(200)));
 world(sourceWord.getContext('2d')!,200,()=>words(sourceWord.getContext('2d')!,'约定落空',755,365,54,INK,true));
 final=make();finalScene(final.getContext('2d')!,false);words(targetWord.getContext('2d')!,'约定落空',235,192,74,INK,true);
 initParticles(title,sourceBowl,sourceWord,final,targetWord);
}

function background(c:Ctx,f:number){
 c.fillStyle='#0c1014';c.fillRect(0,0,W,H);const g=c.createRadialGradient(1110,440,20,1080,510,1110);g.addColorStop(0,'#202a31');g.addColorStop(.5,'#151c22');g.addColorStop(1,'#090d11');c.fillStyle=g;c.fillRect(0,0,W,H);
 // Fixed broad studio illumination; no decorative drifting background.
 const q=c.createLinearGradient(0,0,1920,1080);q.addColorStop(0,'#8da7af09');q.addColorStop(.48,'#8da7af00');q.addColorStop(1,'#00000022');c.fillStyle=q;c.fillRect(0,0,W,H);
 words(c,'新世界',105,102,25,'#9ba7ad');
 if(f<205){words(c,f<90?'关系观察 / 01':'一件事，如何变成一场争吵',105,1009,24,'#7b8a91');}
}
function drop(c:Ctx,f:number){const p=phase(f,22,41);if(f<22||f>45)return;const b=bowlPose(f),a=project({x:109,y:22,z:166},b),y=a.y+215*p*p;c.save();c.globalAlpha=1-phase(f,41,45);c.fillStyle='#d4e9ef';c.beginPath();c.ellipse(a.x,y,4,7+8*p,0,0,Math.PI*2);c.fill();c.restore()}

function route(c:Ctx,f:number){
 const reveal=phase(f,92,148);c.save();c.beginPath();c.moveTo(590,597);c.bezierCurveTo(680,597,720,516,850,510);c.bezierCurveTo(990,500,1060,592,1230,590);c.bezierCurveTo(1380,588,1440,680,1610,670);c.globalAlpha=1-phase(f,196,210);c.strokeStyle='#91a7ae';c.lineWidth=2.5;c.setLineDash([1]);c.lineDashOffset=0;c.save();c.clip();c.restore();
 // Path-length reveal via a clipping plane that follows narrative order.
 c.save();c.beginPath();c.rect(580,250,1060*reveal+2,540);c.clip();c.beginPath();c.moveTo(590,597);c.bezierCurveTo(680,597,720,516,850,510);c.bezierCurveTo(990,500,1060,592,1230,590);c.bezierCurveTo(1380,588,1440,680,1610,670);c.stroke();c.restore();
 c.globalAlpha=1;const stages=[{start:105,x:850,y:510,title:'约定落空',sub:'任务没有兑现'},{start:116,x:1230,y:590,title:'评价扩大',sub:'从一件事，到整个人'},{start:128,x:1610,y:670,title:'冲突爆发',sub:'辩解 · 翻旧账'}];
 stages.forEach((s,i)=>{const t=phase(f,s.start,s.start+12)*(i>0?1-phase(f,170,191):1);if(!t)return;c.save();c.globalAlpha=t;const x=s.x,y=s.y;
  c.globalAlpha=t*(1-phase(f,196,210));words(c,`0${i+1}`,x-95,y-199,31,i===0?TEAL:RED);c.globalAlpha=t;if(f<200)words(c,s.title,x-95,y-145,54,INK,true);c.globalAlpha=t*(1-phase(f,196,210));words(c,s.sub,x-95,y-90,29,SOFT);
  c.strokeStyle=i===0?TEAL:RED;c.lineWidth=2.3;
  if(i===0){c.beginPath();c.moveTo(x+33,y-42);c.lineTo(x-45,y-42);c.lineTo(x-45,y+42);c.lineTo(x+45,y+42);c.lineTo(x+45,y+8);c.stroke();c.setLineDash([4,7]);line(c,x+45,y+8,x+45,y-42,'#d3d8d344',1.7);c.setLineDash([]);c.beginPath();c.arc(x+45,y-42,4,0,Math.PI*2);c.fillStyle=TEAL;c.fill();}
  if(i===1){c.beginPath();c.roundRect(x-40,y-33,80,66,8);c.stroke();c.globalAlpha=t*.75;c.beginPath();c.ellipse(x,y,90*t,62*t,.18,0,Math.PI*2);c.stroke();line(c,x-28,y,x+28,y,RED,2);}
  if(i===2){for(let k=0;k<3;k++){c.beginPath();for(let j=0;j<=96;j++){const a=j/96*Math.PI*2*t;const xx=x+Math.sin(a*2+k*1.04)*89,yy=y+Math.sin(a*3+k*.63)*48;j?c.lineTo(xx,yy):c.moveTo(xx,yy)}c.strokeStyle=k===1?'#adbdc2':RED;c.lineWidth=2.2;c.stroke()}c.globalAlpha=t*.55;c.beginPath();c.moveTo(x-70,y-20);c.bezierCurveTo(x-180,y-80,x-170,y-110,x-239,y-100);c.stroke();}
  c.restore();
 });c.restore();
}

export function drawFrame(c:Ctx,f:number){
 c.clearRect(0,0,W,H);background(c,f);
 if(f<200){
  world(c,f,()=>{const b=bowlPose(f);shadow(c,b.x,b.y+210*b.s,330*b.s,60*b.s,.55);c.save();if(f<43){const edge=lerp(1920,950,phase(f,0,40));c.beginPath();c.rect(edge,200,1920-edge,700);c.clip()}drawBowl(c,b,false,true,surfaceFeedback(f));drop(c,f);c.restore();
   if(f>=90){c.save();route(c,f);c.restore()}
  });
  if(f<43)titleAt(c,lerp(580,180,phase(f,0,38)));else drawFirst(c,f);
 }else{world(c,f,()=>{if(f<210)route(c,f);const b=bowlPose(f);shadow(c,b.x,b.y+210*b.s,330*b.s,60*b.s,.55*(1-phase(f,212,236)))});drawMorph(c,f)}
}
