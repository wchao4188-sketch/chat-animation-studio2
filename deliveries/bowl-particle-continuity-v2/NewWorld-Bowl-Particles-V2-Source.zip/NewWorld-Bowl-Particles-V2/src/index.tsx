import React from 'react';
import {Composition,registerRoot} from 'remotion';
import {Film} from './Film';
const Root=()=> <Composition id="BowlKnowledge10s" component={Film} durationInFrames={300} width={1920} height={1080} fps={30}/>;
registerRoot(Root);
