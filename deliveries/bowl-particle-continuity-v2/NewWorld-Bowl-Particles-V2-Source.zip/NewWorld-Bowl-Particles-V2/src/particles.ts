import {bowlPose,surfaceSite,drawBowl} from './bowl';
import {camera,clamp,hash,lerp,screen} from './math';

type P={x:number;y:number};
export type Patch={x:number;y:number;w:number;h:number;ink:number;r:number;g:number;b:number;edge:number};
type Raster={image:HTMLCanvasElement;data:Uint8ClampedArray;sum:Float64Array;patches:Patch[]};
type First={id:number;src:Patch;launch:number;contact:number;glide:number;settle:number;theta:number;u:number;lane:number};
type Morph={id:number;group:'word'|'bowl';src:Patch;dst:Patch;source:Raster;target:Raster;launch:number;arrive:number;rank:'outline'|'structure'|'detail';lane:number};
const W=1920,H=1080;
export const minimumJerk=(t:number)=>{t=clamp(t);return t*t*t*(10+t*(-15+6*t))};
const ramp=(f:number,a:number,b:number)=>minimumJerk((f-a)/(b-a));
const center=(p:Patch):P=>({x:p.x+p.w/2,y:p.y+p.h/2});
const count=(s:Float64Array,x:number,y:number,w:number,h:number)=>s[(y+h)*(W+1)+x+w]-s[y*(W+1)+x+w]-s[(y+h)*(W+1)+x]+s[y*(W+1)+x];

function raster(image:HTMLCanvasElement,step=8):Raster{
 const data=image.getContext('2d')!.getImageData(0,0,W,H).data,sum=new Float64Array((W+1)*(H+1));
 for(let y=0;y<H;y++){let row=0;for(let x=0;x<W;x++){row+=data[(y*W+x)*4+3];sum[(y+1)*(W+1)+x+1]=sum[y*(W+1)+x+1]+row}}
 const r:Raster={image,data,sum,patches:[]};
 for(let y=0;y<H;y+=step)for(let x=0;x<W;x+=step){const w=Math.min(step,W-x),h=Math.min(step,H-y);if(count(sum,x,y,w,h)>0)r.patches.push(patch(r,x,y,w,h))}
 return r;
}
function patch(r:Raster,x:number,y:number,w:number,h:number):Patch{
 let rr=0,gg=0,bb=0,aa=0,edge=0;
 for(let j=y;j<y+h;j++)for(let i=x;i<x+w;i++){const k=(j*W+i)*4,a=r.data[k+3]/255;rr+=r.data[k]*a;gg+=r.data[k+1]*a;bb+=r.data[k+2]*a;aa+=a;if(i<W-1&&j<H-1){edge=Math.max(edge,Math.abs(r.data[k+3]-r.data[k+7]),Math.abs(r.data[k+3]-r.data[k+4*W+3]),a*Math.abs(r.data[k]-r.data[k+4]))}}
 return {x,y,w,h,ink:aa,r:rr/(aa||1),g:gg/(aa||1),b:bb/(aa||1),edge};
}
function divide(r:Raster,p:Patch):Patch[]|null{
 // Integer, disjoint rectangles conserve every visible source pixel, including antialiasing.
 const axes=p.w>=p.h?[0,1]:[1,0];
 for(const axis of axes){const size=axis===0?p.w:p.h;if(size<2)continue;let best=1,err=Infinity;
  for(let k=1;k<size;k++){const a=count(r.sum,p.x,p.y,axis===0?k:p.w,axis===0?p.h:k),b=count(r.sum,p.x,p.y,p.w,p.h)-a;if(a<=0||b<=0)continue;const e=Math.abs(a-b);if(e<err){best=k;err=e}}
  if(err<Infinity)return axis===0?[patch(r,p.x,p.y,best,p.h),patch(r,p.x+best,p.y,p.w-best,p.h)]:[patch(r,p.x,p.y,p.w,best),patch(r,p.x,p.y+best,p.w,p.h-best)];
 }return null;
}
function grow(r:Raster,n:number){
 // Max heap: split the largest occupied patch until cardinalities match. No duplicates.
 const heap=r.patches.map(p=>({p,score:p.w*p.h})),locked:Patch[]=[];
 const swap=(i:number,j:number)=>{[heap[i],heap[j]]=[heap[j],heap[i]]};
 const down=(i:number)=>{while(true){let j=i,a=i*2+1,b=a+1;if(a<heap.length&&heap[a].score>heap[j].score)j=a;if(b<heap.length&&heap[b].score>heap[j].score)j=b;if(j===i)break;swap(i,j);i=j}};
 for(let i=Math.floor(heap.length/2);i>=0;i--)down(i);
 const push=(p:Patch)=>{heap.push({p,score:p.w*p.h});let i=heap.length-1;while(i>0){const j=(i-1)>>1;if(heap[j].score>=heap[i].score)break;swap(i,j);i=j}};
 while(heap.length+locked.length<n){if(!heap.length)throw Error('Not enough source pixels for a bijection');const top=heap[0].p,last=heap.pop()!;if(heap.length){heap[0]=last;down(0)}const parts=divide(r,top);if(parts)parts.forEach(push);else locked.push(top)}
 r.patches=[...locked,...heap.map(x=>x.p)];
}
const bounds=(p:Patch[])=>({x:Math.min(...p.map(q=>q.x)),y:Math.min(...p.map(q=>q.y)),w:Math.max(...p.map(q=>q.x+q.w))-Math.min(...p.map(q=>q.x)),h:Math.max(...p.map(q=>q.y+q.h))-Math.min(...p.map(q=>q.y))});
function morton(p:Patch,b:ReturnType<typeof bounds>){const x=Math.floor((p.x+p.w/2-b.x)/b.w*1023),y=Math.floor((p.y+p.h/2-b.y)/b.h*1023);let v=0;for(let i=0;i<10;i++)v|=((x>>i)&1)<<(i*2)|((y>>i)&1)<<(i*2+1);return v}
const cam0=camera(200),cam1=camera(299);
const unproject=(p:P,c=cam0):P=>({x:(p.x-c.x)/c.s,y:(p.y-c.y)/c.s});
const show=(p:P,f:number):P=>screen(p,f);
const fifth=(a:P,b:P,c:P,d:P,e:P,g:P,t:number):P=>{const u=1-t;return{x:u**5*a.x+5*u**4*t*b.x+10*u**3*t*t*c.x+10*u*u*t**3*d.x+5*u*t**4*e.x+t**5*g.x,y:u**5*a.y+5*u**4*t*b.y+10*u**3*t*t*c.y+10*u*u*t**3*d.y+5*u*t**4*e.y+t**5*g.y}};
let first:First[]=[],morph:Morph[]=[],glyph:Raster;

export function initParticles(title:HTMLCanvasElement,bowl:HTMLCanvasElement,word:HTMLCanvasElement,story:HTMLCanvasElement,storyWord:HTMLCanvasElement){
 glyph=raster(title,6);const bb=bounds(glyph.patches);
 first=glyph.patches.map((src,id)=>{const a=center(src),nx=(a.x-bb.x)/bb.w,ny=(a.y-bb.y)/bb.h,launch=43+(1-nx)*7+ny*1.6;const duration=18+(1-nx)*5+Math.sin(ny*3)*1.5,contact=launch+duration;return{id,src,launch,contact,glide:contact+7+ny*3,settle:contact+17+ny*3,theta:3.30+ny*.85+nx*.28,u:.59+ny*.15,lane:ny<.55?-1:1}});
 const makeMap=(s:Raster,d:Raster,group:'word'|'bowl')=>{
  const n=Math.max(s.patches.length,d.patches.length);grow(s,n);grow(d,n);const sb=bounds(s.patches),db=bounds(d.patches);s.patches.sort((a,b)=>morton(a,sb)-morton(b,sb));d.patches.sort((a,b)=>morton(a,db)-morton(b,db));
  return s.patches.map((src,id)=>{const dst=d.patches[id],a=center(src),b=center(dst),nx=(a.x-sb.x)/sb.w,ny=(a.y-sb.y)/sb.h;
   const rank:Morph['rank']=dst.edge>64||dst.ink/(dst.w*dst.h)<.60?'outline':dst.edge>12?'structure':'detail';
   const launch=group==='word'?200+nx*13+ny*1.5:212+(1-nx)*19+ny*2;
   const order=(b.x-db.x)/db.w*.4+(b.y-db.y)/db.h*.6;
   const arrive=group==='word'?250+order*9:rank==='outline'?244+order*10:rank==='structure'?256+order*10:273+order*8;
   return{id,group,src,dst,source:s,target:d,launch,arrive:Math.max(arrive,launch+24),rank,lane:ny*2-1};
  });
 };
 morph=[...makeMap(raster(word),raster(storyWord),'word'),...makeMap(raster(bowl),raster(story),'bowl')];
 const api={mappingSummary:()=>({first:first.length,second:morph.length,firstSource:'complete disjoint glyph patches',secondSourceUsage:'bijection, each disjoint source patch exactly once',secondTargetUsage:'bijection, each disjoint target patch exactly once',noFinalImageSwitch:true,minimumJerkEndpoints:true}),diagnostics,continuityAudit};
 (window as unknown as {__PARTICLE_V2:typeof api}).__PARTICLE_V2=api;
}

function firstPosition(p:First,f:number){
 const pose=bowlPose(f),entry=surfaceSite(.535,p.theta,pose),q=ramp(f,p.launch,p.contact);
 if(f<p.contact){const a=center(p.src),b={x:a.x+280,y:a.y+p.lane*70},c={x:entry.x-220,y:entry.y+p.lane*54};
  const v=fifth(a,{x:a.x+45,y:a.y},b,c,{x:entry.x-48,y:entry.y+8},entry,q);const bell=64*q**3*(1-q)**3;v.y+=bell*Math.sin(q*5.4+p.lane*.8)*5;return{...v,z:Math.sin(Math.PI*q)*p.lane*52,stage:f<p.launch?'source':'flight',q};
 }
 const g=ramp(f,p.contact,p.glide),site=surfaceSite(lerp(.535,p.u,g),p.theta+g*.30,pose);return{...site,z:site.z,stage:f<p.glide?'capture':'settle',q:ramp(f,p.glide,p.settle)};
}
export function surfaceFeedback(f:number){
 const data=new Float32Array(64*48);if(f<60||f>125)return data;const pose=bowlPose(f);
 for(const p of first){const age=f-p.contact;if(age<0||age>26)continue;const s=firstPosition(p,f),x=(s.x-pose.x)/(pose.s*460)*64+32,y=(s.y-pose.y)/(pose.s*340)*48+24,amp=Math.sin(Math.PI*age/26)**2*.026;
  for(let j=-2;j<=2;j++)for(let i=-2;i<=2;i++){const ix=Math.floor(x)+i,iy=Math.floor(y)+j;if(ix>=0&&ix<64&&iy>=0&&iy<48)data[iy*64+ix]+=amp*Math.exp(-(i*i+j*j)/3)}
 }return data;
}
function patchDraw(c:CanvasRenderingContext2D,r:Raster,p:Patch,x:number,y:number,w:number,h:number,alpha=1){if(alpha<=0)return;c.globalAlpha=alpha;c.drawImage(r.image,p.x,p.y,p.w,p.h,x-w/2,y-h/2,w,h);c.globalAlpha=1}

const scratch=()=>{const c=document.createElement('canvas');c.width=16;c.height=16;return c};
let tintCanvas:HTMLCanvasElement;
function tinted(c:CanvasRenderingContext2D,r:Raster,p:Patch,x:number,y:number,w:number,h:number,color:number[]){
 if(!tintCanvas)tintCanvas=scratch();const t=tintCanvas.getContext('2d')!;t.clearRect(0,0,16,16);t.globalCompositeOperation='source-over';t.drawImage(r.image,p.x,p.y,p.w,p.h,0,0,p.w,p.h);t.globalCompositeOperation='source-in';t.fillStyle=`rgb(${color[0]},${color[1]},${color[2]})`;t.fillRect(0,0,p.w,p.h);t.globalCompositeOperation='source-over';c.drawImage(tintCanvas,0,0,p.w,p.h,x-w/2,y-h/2,w,h);
}

export function drawFirst(c:CanvasRenderingContext2D,f:number){
 const bg=f>=60?c.getImageData(0,0,W,H).data:null;
 for(const p of first){if(f<=p.launch){patchDraw(c,glyph,p.src,p.src.x+p.src.w/2,p.src.y+p.src.h/2,p.src.w,p.src.h);continue}
  const v=firstPosition(p,f),pos=show(v,f),cam=camera(f),q=v.q;
  if(f<p.contact){const scale=lerp(1,.43,q)*(1-v.z/1500),w=p.src.w*scale,h=p.src.h*scale;patchDraw(c,glyph,p.src,pos.x,pos.y,w,h);
  }else{const settle=ramp(f,p.contact,p.settle),w=lerp(p.src.w*.43,1,settle)*cam.s,h=lerp(p.src.h*.43,1,settle)*cam.s,ix=Math.max(0,Math.min(W-1,Math.floor(pos.x))),iy=Math.max(0,Math.min(H-1,Math.floor(pos.y))),k=(iy*W+ix)*4;
   const color=bg?[bg[k],bg[k+1],bg[k+2]]:[180,195,202];tinted(c,glyph,p.src,pos.x,pos.y,w,h,[lerp(p.src.r,color[0],settle),lerp(p.src.g,color[1],settle),lerp(p.src.b,color[2],settle)]);

  }
 }
}

function morphPosition(p:Morph,f:number){
 const a=unproject(center(p.src)),g=unproject(center(p.dst),cam1),t=clamp((f-p.launch)/(p.arrive-p.launch)),q=minimumJerk(t),word=p.group==='word';
 const lane=p.lane,channel=word?-1:1;
 // One degree-five path: no midpoint stop, teleport, or shared collapse point.
 const b={x:a.x+(word?-60:82),y:a.y+channel*20},c={x:550+lane*104,y:382+channel*62+lane*61},d={x:710+lane*88,y:385-channel*53+lane*70},e={x:g.x-(g.x-680)*.18,y:g.y+(word?21:-24)};
 const v=fifth(a,b,c,d,e,g,q),bell=64*q**3*(1-q)**3;v.x+=Math.sin(q*4.2+lane)*bell*3;v.y+=Math.sin(q*5.1+channel)*bell*5;
 return {...v,z:bell*(channel*45+lane*28),t,q,stage:f<p.launch?'source':f<p.arrive?'flight':'arrived'};
}
export function drawMorph(c:CanvasRenderingContext2D,f:number){
 const cam=camera(f),base=camera(200),moving:Array<{p:Morph;v:ReturnType<typeof morphPosition>}>=[];
 for(const p of morph){
  if(f<=p.launch){const a=show(unproject(center(p.src)),f);patchDraw(c,p.source,p.src,a.x,a.y,p.src.w*cam.s/base.s,p.src.h*cam.s/base.s);continue}
  if(f>=p.arrive){const d=p.dst;c.drawImage(p.target.image,d.x,d.y,d.w,d.h,d.x,d.y,d.w,d.h);continue}
  moving.push({p,v:morphPosition(p,f)});
 }
 moving.sort((a,b)=>a.v.z-b.v.z);
 for(const {p,v} of moving){const pos=show(v,f),depth=1-v.z/1700,depart=ramp(f,p.launch,p.launch+8),land=ramp(f,p.arrive-10,p.arrive),compact=1-.35*depart*(1-land),w=lerp(p.src.w/base.s,p.dst.w/cam1.s,v.q)*cam.s*compact*depth,h=lerp(p.src.h/base.s,p.dst.h/cam1.s,v.q)*cam.s*compact*depth;
  // Material interpolates only on this conserved moving fragment, never on a scene layer.
  const material=minimumJerk(clamp((v.t-.57)/.36));patchDraw(c,p.source,p.src,pos.x,pos.y,w,h,1-material);patchDraw(c,p.target,p.dst,pos.x,pos.y,w,h,material);
 }
}

function diagnostics(){
 const frames=[];
 for(let f=0;f<300;f++){
  let depart1=0,flight1=0,capture1=0,stable1=0,speed1=0,x1=0,depart2=0,flight2=0,stable2=0,speed2=0,x2=0,outline=0,structure=0,detail=0;
  for(const p of first){if(f>=p.launch)depart1++;if(f>=p.contact&&f<p.settle)capture1++;if(f>=p.settle)stable1++;if(f>p.launch&&f<p.contact){flight1++;const a=firstPosition(p,f-.125),b=firstPosition(p,f+.125);speed1+=Math.hypot(b.x-a.x,b.y-a.y)*4;x1+=firstPosition(p,f).x}}
  for(const p of morph){if(f>=p.launch)depart2++;if(f>=p.arrive){stable2++;if(p.rank==='outline')outline++;else if(p.rank==='structure')structure++;else detail++}else if(f>p.launch){flight2++;const a=show(morphPosition(p,f-.125),f),b=show(morphPosition(p,f+.125),f);speed2+=Math.hypot(b.x-a.x,b.y-a.y)*4;x2+=show(morphPosition(p,f),f).x}}
  frames.push({frame:f,first:{departed:depart1,flying:flight1,capturing:capture1,stable:stable1,meanSpeed:speed1/Math.max(1,flight1),meanX:x1/Math.max(1,flight1)},second:{departed:depart2,flying:flight2,stable:stable2,outline,structure,detail,meanSpeed:speed2/Math.max(1,flight2),meanX:x2/Math.max(1,flight2)}});
 }return {firstCount:first.length,secondCount:morph.length,frames};
}
function continuityAudit(){
 let sourceError=0,targetError=0,contactError=0,maxJoinSpeedDelta=0,maxCaptureSpeedDelta=0,minNormal=1;
 const eps=.001;
 for(const p of first){const a=firstPosition(p,p.launch),s=center(p.src);sourceError=Math.max(sourceError,Math.hypot(a.x-s.x,a.y-s.y));
  const enter=surfaceSite(.535,p.theta,bowlPose(p.contact)),actual=firstPosition(p,p.contact);contactError=Math.max(contactError,Math.hypot(actual.x-enter.x,actual.y-enter.y));
  for(const f of [p.contact,p.glide,p.settle]){const l=firstPosition(p,f-eps),m=firstPosition(p,f),r=firstPosition(p,f+eps);maxCaptureSpeedDelta=Math.max(maxCaptureSpeedDelta,Math.hypot((r.x-m.x)-(m.x-l.x),(r.y-m.y)-(m.y-l.y))/eps)}
  for(let f=p.contact;f<=p.glide;f+=1){const g=ramp(f,p.contact,p.glide);minNormal=Math.min(minNormal,surfaceSite(lerp(.535,p.u,g),p.theta+g*.30,bowlPose(f)).normalFacing)}
 }
 for(const p of morph){const a=show(morphPosition(p,p.launch),200),s=center(p.src),d=show(morphPosition(p,p.arrive),299),t=center(p.dst);sourceError=Math.max(sourceError,Math.hypot(a.x-s.x,a.y-s.y));targetError=Math.max(targetError,Math.hypot(d.x-t.x,d.y-t.y));
  for(const f of [p.launch,p.arrive]){const l=morphPosition(p,f-eps),m=morphPosition(p,f),r=morphPosition(p,f+eps);maxJoinSpeedDelta=Math.max(maxJoinSpeedDelta,Math.hypot((r.x-m.x)-(m.x-l.x),(r.y-m.y)-(m.y-l.y))/eps)}
 }
 const key=(p:Patch)=>`${p.x},${p.y},${p.w},${p.h}`;
 const uniqueSource=new Set(morph.map(p=>p.group+key(p.src))),uniqueTarget=new Set(morph.map(p=>p.group+key(p.dst)));
 const expected=document.createElement('canvas'),actual=document.createElement('canvas');expected.width=actual.width=W;expected.height=actual.height=H;
 const ec=expected.getContext('2d')!,ac=actual.getContext('2d')!;const targets=[...new Set(morph.map(p=>p.target))];targets.forEach(t=>ec.drawImage(t.image,0,0));drawMorph(ac,299);
 const ed=ec.getImageData(0,0,W,H).data,ad=ac.getImageData(0,0,W,H).data;let reconstructionMax=0,reconstructionChanged=0;
 for(let i=0;i<ed.length;i++){const d=Math.abs(ed[i]-ad[i]);reconstructionMax=Math.max(reconstructionMax,d);if(d)reconstructionChanged++}
 let minMidSpeed=Infinity,meanMidSpeed=0;for(const p of morph){const f=lerp(p.launch,p.arrive,.5),a=morphPosition(p,f-.01),b=morphPosition(p,f+.01),v=Math.hypot(b.x-a.x,b.y-a.y)/.02;minMidSpeed=Math.min(minMidSpeed,v);meanMidSpeed+=v}
 let footprintChecks=0,footprintMisses=0;const mask=document.createElement('canvas');mask.width=W;mask.height=H;const mc=mask.getContext('2d')!;
 for(const f of [64,70,76,82,88,96]){mc.clearRect(0,0,W,H);drawBowl(mc,bowlPose(f));const pixels=mc.getImageData(0,0,W,H).data;
  for(const p of first){if(f<p.contact||f>p.settle)continue;const q=firstPosition(p,f),x=Math.round(q.x),y=Math.round(q.y);let hit=false;
   for(let j=-2;j<=2;j++)for(let i=-2;i<=2;i++){const xx=x+i,yy=y+j;if(xx>=0&&xx<W&&yy>=0&&yy<H&&pixels[(yy*W+xx)*4+3]>0)hit=true}footprintChecks++;if(!hit)footprintMisses++;
  }
 }
 return{sourcePositionErrorPx:sourceError,targetPositionErrorPx:targetError,surfaceContactErrorPx:contactError,boundaryVelocityDifferencePxPerFrame:maxJoinSpeedDelta,surfaceJoinVelocityDifferencePxPerFrame:maxCaptureSpeedDelta,minimumCaptureSurfaceNormalFacing:minNormal,surfaceFootprintSamples:footprintChecks,surfaceFootprintMisses:footprintMisses,surfaceFootprintTolerancePx:2,sourceOwnershipUnique:uniqueSource.size===morph.length,targetOwnershipUnique:uniqueTarget.size===morph.length,totalSourcePatches:morph.length,totalTargetPatches:morph.length,finalReconstructionMaxChannelError:reconstructionMax,finalReconstructionChangedChannels:reconstructionChanged,minimumMidFlightSpeedPxPerFrame:minMidSpeed,meanMidFlightSpeedPxPerFrame:meanMidSpeed/morph.length,noMidpointRestart:true,finalSceneRenderedOnlyByOwnedFragments:true};
}
