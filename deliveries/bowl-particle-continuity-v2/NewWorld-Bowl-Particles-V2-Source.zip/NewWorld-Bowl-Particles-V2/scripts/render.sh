#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
npx remotion render src/index.tsx BowlKnowledge10s output/NewWorld-Bowl-Particles-V2-Render.mp4 --browser-executable=/usr/bin/chromium --codec=h264 --crf=16 --pixel-format=yuv420p --concurrency=3
ffmpeg -v error -y -i output/NewWorld-Bowl-Particles-V2-Render.mp4 -map 0:v:0 -map 0:a:0 -c:v copy -af atrim=duration=10 -c:a aac -b:a 192k -t 10 -movflags +faststart output/NewWorld-Bowl-Particles-V2-Preview.mp4
