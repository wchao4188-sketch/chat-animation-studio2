from pathlib import Path
import json,wave,subprocess,hashlib
import numpy as np
from scipy.signal import butter,sosfilt
from scipy.ndimage import gaussian_filter1d
R=Path(__file__).resolve().parents[1];A=R/'public/audio';O=R/'output';sr=48000;N=sr*10;t=np.arange(N)/sr
tele=json.loads((O/'particle-telemetry.json').read_text());rows=tele['frames'];frame_times=np.arange(300)/30
def track(group,key):return np.asarray([r[group][key] for r in rows],dtype=float)
def env(v):return gaussian_filter1d(np.interp(t,frame_times,v),sr*.009,mode='nearest')
def normalized(v):return v/(max(float(v.max()),1))
def read(name,channels):
 with wave.open(str(A/name)) as w:x=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float64)/32768
 return x.reshape(-1,channels) if channels>1 else x
rng=np.random.default_rng(4188);noise=rng.normal(0,1,N)
air=sosfilt(butter(2,[350,2800],btype='bandpass',fs=sr,output='sos'),noise)
grain=sosfilt(butter(2,[2300,6800],btype='bandpass',fs=sr,output='sos'),rng.normal(0,1,N))
low=sosfilt(butter(2,[180,900],btype='bandpass',fs=sr,output='sos'),rng.normal(0,1,N))
tracks=[];states=[]
for group,total in [('first',tele['firstCount']),('second',tele['secondCount'])]:
 departing=np.maximum(0,np.diff(track(group,'departed'),prepend=0));landing=np.maximum(0,np.diff(track(group,'stable'),prepend=0));speed=track(group,'meanSpeed');flying=track(group,'flying')/total
 d=env(normalized(departing));flow=env(np.sqrt(flying)*np.minimum(speed/32,1.6));arrive=env(normalized(landing));pan=np.clip(env(track(group,'meanX'))/1920*1.1-.55,-.55,.55)
 if group=='first':
  contact=env(track(group,'capturing')/total);frequency=740+800*np.clip(env(speed)/38,0,1);phase=np.cumsum(2*np.pi*frequency/sr)
  signal=.005*grain*d+.014*air*flow+.009*contact*(np.sin(phase)+.24*np.sin(phase*1.91))+.003*low*arrive
 else:
  outline=env(normalized(np.maximum(0,np.diff(track(group,'outline'),prepend=0))));structure=env(normalized(np.maximum(0,np.diff(track(group,'structure'),prepend=0))));detail=env(normalized(np.maximum(0,np.diff(track(group,'detail'),prepend=0))))
  frequency=390+320*np.clip(env(speed)/24,0,1);phase=np.cumsum(2*np.pi*frequency/sr)
  signal=.007*grain*d+.020*air*flow+.005*np.sin(phase)*outline+.007*low*structure+.0025*grain*detail
 stereo=np.stack([signal*np.sqrt((1-pan)/2),signal*np.sqrt((1+pan)/2)],axis=1);tracks.append(stereo)
 states.append({'system':group,'detachment_start_frame':int(np.flatnonzero(departing>0)[0]),'first_landing_frame':int(np.flatnonzero(landing>0)[0]),'flow_peak_frame':int(flow[::1600].argmax()),'last_active_frame':int(np.flatnonzero((d+flow+arrive)[::1600]>.001)[-1]),'driven_by':'Per-frame ownership, analytic velocity, capture and landing counts from actual animation'})
base=np.zeros((N,2))
for frame,kind in [(39,'water'),(111,'stage'),(122,'stage'),(141,'stage')]:
 n=round(sr*(.24 if kind=='water' else .13));z=np.arange(n)/sr
 if kind=='water':s=(np.sin(2*np.pi*(1100*z-850*z*z))+.28*np.sin(2*np.pi*2150*z))*np.exp(-z*28)*.029
 else:s=(np.sin(2*np.pi*285*z)+.2*np.sin(2*np.pi*770*z))*np.exp(-z*32)*.013
 j=frame*1600;base[j:j+n]+=s[:,None]
voice=read('narration.wav',1);music=read('music.wav',2);first,second=tracks;first*=2.6;second*=3.0;sfx=base+first+second
flow=np.asarray([r['second']['flying']/tele['secondCount'] for r in rows]);music_gain=1-.22*env(np.sqrt(flow));master=voice[:,None]+music*music_gain[:,None]+sfx;master*=np.minimum(1,(10-t)/.15)[:,None];peak=float(abs(master).max());master*=min(1,.89/(peak+1e-12))
for name,x in [('first-particle-sfx.wav',first),('second-particle-sfx.wav',second),('sfx-v2.wav',sfx),('master-v2.wav',master)]:
 with wave.open(str(A/name),'wb') as w:w.setparams((2,2,sr,0,'NONE','not compressed'));w.writeframes((x.clip(-1,1)*32767).astype('<i2').tobytes())
report={'sample_rate':sr,'samples':N,'duration':10,'state_driven_systems':states,'effects_description':'Locally synthesized continuous granular/air/ceramic textures; not recorded foley','fixed_whoosh_reused':False,'music_mix_gain':'Up to 22% smooth reduction driven by second-system in-flight occupancy; source music file unchanged','voice_unchanged_sha256':hashlib.sha256((A/'narration.wav').read_bytes()).hexdigest(),'music_unchanged_sha256':hashlib.sha256((A/'music.wav').read_bytes()).hexdigest(),'master_peak':float(abs(master).max()),'sfx_rms':float(np.sqrt(np.mean(sfx*sfx))),'human_listening':False,'voice_limit':'Existing synthetic narration retained; opening homophone ASR ambiguity remains, not a new diction approval.'}
(O/'sound-state-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
