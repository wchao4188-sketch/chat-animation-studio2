#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
npm run typecheck
npx remotion render src/index.tsx BeneathTheBowl output/Beneath-The-Bowl-Render.mp4 --browser-executable=/usr/bin/chromium --codec=h264 --crf=15 --pixel-format=yuv420p --concurrency=3
ffmpeg -v error -y -i output/Beneath-The-Bowl-Render.mp4 -map 0:v:0 -map 0:a:0 -c:v copy -af atrim=duration=10 -c:a aac -b:a 256k -t 10 -movflags +faststart output/NewWorld-Beneath-The-Bowl-10s.mp4
