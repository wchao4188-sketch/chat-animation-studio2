"""Run after production. Refine actual static opening/final poses at a higher native sample count."""
import bpy,time,subprocess,shutil,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];S=bpy.context.scene;S.render.engine='BLENDER_EEVEE_NEXT';S.eevee.taa_render_samples=48;S.render.resolution_percentage=100
for node in list(S.node_tree.nodes):
 if node.type=='OUTPUT_FILE':S.node_tree.nodes.remove(node)
results=[]
for frame in [1,199]:
 S.frame_set(frame);dst=R/f'output/review/high-sample-{frame:04}.png';clean=R/f'output/review/high-sample-clean-{frame:04}.png';S.render.filepath=str(dst);t=time.time();bpy.ops.render.render(write_still=True)
 with (R/'output/oidn-refine.log').open('a') as log:subprocess.run(['python',str(R/'scripts/denoise.py'),str(dst),str(clean)],stdout=log,stderr=log,check=True)
 # Existing hold frames are hard-linked; copying bytes preserves that shared, correct static state.
 shutil.copyfile(clean,R/f'public/frames/frame_{frame:04}.png');results.append({'frame':frame,'samples':48,'width':1920,'height':1080,'seconds':time.time()-t});print('HOLD_REFINED',frame,time.time()-t,flush=True)
(R/'output/hold-refinement.json').write_text(json.dumps(results,indent=2))
subprocess.run(['ffmpeg','-v','error','-y','-framerate','30','-start_number','1','-i',str(R/'public/frames/frame_%04d.png'),'-frames:v','300','-c:v','libx264','-crf','12','-preset','medium','-pix_fmt','yuv420p','-movflags','+faststart',str(R/'public/Bowl-3D-Layer.mp4')],check=True)
