from pathlib import Path
import json
R=Path(__file__).resolve().parents[1];O=R/'output';q=json.loads((O/'quality-check.json').read_text());p=json.loads((O/'playback-check.json').read_text());c=json.loads((O/'particle-continuity.json').read_text());h=json.loads((O/'hold-refinement.json').read_text())
text=f'''# 《新世界：碗洗了，为什么还在吵？》实际制作与验收

## 实际交付

- {q['video']['width']}×{q['video']['height']}、16:9、{q['video']['fps']}、{q['video']['frames']}帧、{q['video']['duration']:.3f}秒。
- H.264 / yuv420p，AAC / 48kHz / 双声道。{q['file']['bytes']:,} 字节。
- SHA-256：`{q['file']['sha256']}`。
- 原有项目和成片保持不动。本期新建独立目录。

## 视觉创作与实际修改

真实Blender三维场景：连续内外表面的瓷碗、程序化釉面、两端铂金环、32条连续曲线与360个持久粒子。摄影机与景深从干净的碗下移到已经存在的关系结。粒子从两端表面运动到中间，保持固定身份，停留在同一套曲线上。

开场不直接给出两人生活表演，结尾不展示问题已经解决。干净的碗仍在，关系结也仍在，画面与文字共同说明：争吵可能不只为了眼前这一件事。

实际发现并修复：初版太早露出完整关系结；背景地平线生硬；部分曲线端点没有准确接在环上；粒子到达速度不够平顺；水珠的黑色反射像污点；生产渲染中发现镜头揭示晚于粒子动作，随后提前揭示并重新渲染。旧草稿和测试帧保留。

## 粒子连续性与检查范围

- {c['particles']}个粒子，1–300帧身份持续，没有用透明度消失后重新生成。
- 脱离时间最早 {c['minimum_departure']:.3f} 秒，最晚到达 {c['maximum_arrival']:.6f} 秒。
- 在脱离点前后各1微秒的位置差最大 {c['maximum_position_jump_at_departure']:.9g} 场景单位；到达点为 {c['maximum_position_jump_at_arrival']:.9g}。这是解析位置连续性检查，不等于认证真实物理模拟。
- 颗粒终点与曲线共用拉紧参数；以近似表面偏移实现视觉接触。没有宣称完整流体/刚体碰撞求解。
- 实际MP4全部300帧编入12页总览；另外检查高清关键帧与0.5倍速粒子段。技术数值不替代观感判断。

## 渲染方法与限制

三维原生1920×1080，没有低分辨率放大。Blender 4.3.2 Eevee，镜头揭示段4次采样、粒子主体段8次采样，开场和结尾静止姿态48次采样；独立OIDN 2.3.3处理。末尾是真实静止阅读段，复用相同状态的图像，运动区间没有降帧。

当前Blender的Cycles没有内置OpenImageDenoise支持，实际测试报错；没有把该路径说成可用。独立OIDN来自官方发布并已实际用于输出。没有新增npm依赖。这里不把Eevee采样和技术检查包装成高采样路径追踪或主观「电影级」认证。

## 视频与声音检查

- FFmpeg完整解码退出码 {q['full_decode']['exit']}，错误输出为空。
- Chromium连续播放至结束：{p['ended']}；总帧 {p['totalFrames']}，丢帧 {p['droppedFrames']}，媒体错误 {p['error']}。
- 音轨与预定总混音的相关系数 {q['audio']['master_correlation']:.6f}，解码峰值 {q['audio']['peak']:.6f}，没有数值削波。
- 使用用户已有音乐0–10秒；BPM为自动候选，没有宣称人工确认小节重拍。摄影机在1.1秒音乐起音附近启动，粒子到达时间对应稀疏接触声，拉紧与汇聚阶段有连续声音纹理。
- 总混音AAC实测约 −16.03 LUFS，真峰值 −4.73 dBTP（独立FFmpeg loudnorm输入测量）。
- 没有新增旁白。音效为本地合成，不冒充真实录音。
- 浏览器检查是静音自动播放，未进行真人试听，不声称音效自然度已通过人工验收。

## 可编辑性

工程包含 `.blend` 全部模型、灯光、摄影机和烘焙关键帧，Remotion字幕、音乐/音效分轨、底片以及生成脚本。普通文字/声音修改可直接重合成，不需重新计算三维。完整重建脚本在Linux运行；Windows完整重建未验证。
'''
(O/'Acceptance.md').write_text(text);print(text)
