from pathlib import Path
import subprocess,json,hashlib,wave
from PIL import Image,ImageDraw
import numpy as np
R=Path(__file__).resolve().parents[1];O=R/'output';Q=O/'review';P=O/'NewWorld-Beneath-The-Bowl-10s.mp4'
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(P)]));v=next(x for x in probe['streams'] if x['codec_type']=='video');a=next(x for x in probe['streams'] if x['codec_type']=='audio')
assert (v['width'],v['height'],v['r_frame_rate'],int(v['nb_read_frames']))==(1920,1080,'30/1',300)
assert abs(float(v['duration'])-10)<.001 and abs(float(probe['format']['duration'])-10)<.001
run=subprocess.run(['ffmpeg','-v','error','-i',str(P),'-f','null','-'],capture_output=True);assert run.returncode==0 and not run.stderr
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(P),'-vf','scale=320:180','-f','rawvideo','-pix_fmt','rgb24','-']);frames=np.frombuffer(raw,np.uint8).reshape(300,180,320,3);mean=frames.mean((1,2,3));diff=np.array([np.abs(frames[i].astype(np.int16)-frames[i-1]).mean() for i in range(1,300)]);assert mean.min()>2
pages=[]
for n in range(12):
 im=Image.new('RGB',(1600,1025),'#11171a');d=ImageDraw.Draw(im)
 for j in range(25):
  i=n*25+j;x=j%5*320;y=j//5*205;im.paste(Image.fromarray(frames[i]),(x,y));d.text((x+6,y+183),f'{i/30:.3f}s / f{i}',fill='white')
 p=Q/f'all-frames-{n:02}.jpg';im.save(p,quality=94);pages.append(p)
imgs=[Image.open(p).convert('RGB') for p in pages];imgs[0].save(O/'Beneath-The-Bowl-Keyframes.pdf',save_all=True,append_images=imgs[1:],resolution=120)
for f in [0,18,50,75,95,115,135,155,175,195,225,270,299]:
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(P),'-vf',f'select=eq(n\\,{f})','-frames:v','1',str(Q/f'actual-{f:03}.png')],check=True)
audio=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(P),'-vn','-ac','2','-ar','48000','-f','f32le','-']),np.float32).reshape(-1,2)
with wave.open(str(R/'public/audio/master.wav')) as w:master=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32).reshape(-1,2)/32768
n=min(len(master),len(audio));cor=float(np.corrcoef(master[:n].ravel(),audio[:n].ravel())[0,1]);peak=float(abs(audio).max());assert cor>.98 and peak<1
result={'video':{'codec':v['codec_name'],'width':v['width'],'height':v['height'],'fps':v['r_frame_rate'],'frames':int(v['nb_read_frames']),'duration':float(v['duration'])},'container_duration':float(probe['format']['duration']),'audio':{'codec':a['codec_name'],'sample_rate':a['sample_rate'],'channels':a['channels'],'duration':a['duration'],'peak':peak,'master_correlation':cor,'last_20ms_rms':float(np.sqrt(np.mean(audio[-960:]**2)))},'full_decode':{'exit':run.returncode,'stderr':run.stderr.decode()},'all_frames_review':{'frames':300,'pages':12,'minimum_mean_brightness':float(mean.min()),'maximum_adjacent_mean_difference':float(diff.max()),'largest_difference_frame':int(diff.argmax()+1),'particle_interval_frame_differences':diff[100:197].round(5).tolist()},'file':{'name':P.name,'bytes':P.stat().st_size,'sha256':hashlib.sha256(P.read_bytes()).hexdigest()},'voiceover':False,'human_audio_listening':False,'note':'No claim that technical metrics certify cinematic visual quality. Actual images and playback are checked separately.'}
(O/'quality-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
# Slower view to inspect release, capture and final attachment; this is a review artifact, not the finished film.
subprocess.run(['ffmpeg','-v','error','-y','-ss','3.3','-t','3.4','-i',str(P),'-vf','setpts=2*(PTS-STARTPTS)','-r','30','-an','-c:v','libx264','-crf','17',str(O/'Particle-Continuity-Review-0.5x.mp4')],check=True)
