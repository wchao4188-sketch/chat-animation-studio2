from pathlib import Path
import json,hashlib,zipfile
R=Path(__file__).resolve().parents[1];O=R/'output';dst=O/'NewWorld-Beneath-The-Bowl-Source.zip'
files=[R/x for x in ['README.md','package.json','package-lock.json','tsconfig.json']]
for folder in ['src','scripts']:
 files += [p for p in (R/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
for folder in ['public/fonts','public/audio']:
 files += [p for p in (R/folder).rglob('*') if p.is_file()]
files += [R/'public/Bowl-3D-Layer.mp4',R/'public/lookdev.png',R/'assets/Beneath-The-Bowl.blend',R/'assets/particle-mapping.json',R/'assets/Font-LICENSE.txt']
files += list((R/'assets').glob('OIDN-*'))
for name in ['Acceptance.md','quality-check.json','playback-check.json','particle-continuity.json','music-analysis.json','sound-events.json','hold-refinement.json','final-audio-measurement.log']:files.append(O/name)
assert all(p.exists() for p in files)
with zipfile.ZipFile(dst,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(set(files)):z.write(p,Path('NewWorld-Beneath-The-Bowl')/p.relative_to(R))
with zipfile.ZipFile(dst) as z:assert z.testzip() is None
manifest=[]
for p in [O/'NewWorld-Beneath-The-Bowl-10s.mp4',dst,O/'Beneath-The-Bowl-Keyframes.pdf',O/'Acceptance.md']:
 manifest.append({'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(O/'manifest.json').write_text(json.dumps(manifest,indent=2));(O/'SHA256SUMS.txt').write_text('\n'.join(x['sha256']+'  '+x['name'] for x in manifest)+'\n');print(json.dumps(manifest,indent=2))
