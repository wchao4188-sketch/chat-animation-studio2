#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [ -d public/frames ] && [ -n "$(find public/frames -maxdepth 1 -name 'frame_*.png' -print -quit)" ]; then
  cache_backup="output/frame-cache-$(date -u +%Y%m%dT%H%M%S)-$$"
  mv public/frames "$cache_backup"
  mkdir -p public/frames
fi
export MESA_SHADER_CACHE_DIR=/tmp/newworld-bowl-mesa
blender -b -t 5 --python scripts/scene.py -- production
blender -b assets/Beneath-The-Bowl.blend -t 5 --python scripts/refine-holds.py
bash scripts/render.sh
