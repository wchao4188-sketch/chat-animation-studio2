from pathlib import Path
import subprocess,sys,os,numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parents[1];BIN=Path(os.environ.get('OIDN_BIN',str(ROOT/'tools/oidn-2.3.3.x86_64.linux/bin/oidnDenoise')))
if not BIN.exists():BIN=Path('/tmp/oidn-2.3.3.x86_64.linux/bin/oidnDenoise')
def run(src,dst,frame=None):
 src,dst=Path(src),Path(dst);a=np.asarray(Image.open(src).convert('RGB'),np.float32)/255;h,w=a.shape[:2];tmp=ROOT/'output/denoise-work';tmp.mkdir(exist_ok=True)
 pf=tmp/'input.pfm';out=tmp/'output.pfm'
 with pf.open('wb') as f:f.write(f'PF\n{w} {h}\n-1.0\n'.encode());f.write(np.flipud(a).astype('<f4').tobytes())
 cmd=[str(BIN),'--device','cpu','--ldr',str(pf),'--srgb','--quality','high','--threads','4','-o',str(out)]
 if frame is not None:
  for kind,flag in [('albedo','--alb'),('normal','--nrm')]:
   exr=ROOT/f'output/aux/{kind}_{frame:04}.exr'
   raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(exr),'-f','rawvideo','-pix_fmt','gbrpf32le','-'])
   image=np.frombuffer(raw,'<f4').reshape(3,h,w)[[2,0,1]].transpose(1,2,0)
   fp=tmp/f'{kind}.pfm'
   with fp.open('wb') as f:f.write(f'PF\n{w} {h}\n-1.0\n'.encode());f.write(np.flipud(image).astype('<f4').tobytes())
   cmd.extend([flag,str(fp)])
 p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True)
 with out.open('rb') as f:
  assert f.readline().strip()==b'PF';ww,hh=map(int,f.readline().split());scale=float(f.readline());x=np.frombuffer(f.read(),'<f4').reshape(hh,ww,3);x=np.flipud(x)
 dst.parent.mkdir(exist_ok=True,parents=True);Image.fromarray(np.uint8(np.clip(x,0,1)*255+.5)).save(dst)
 return {'source':str(src),'output':str(dst),'size':[ww,hh],'method':'Official OIDN 2.3.3 CPU RT filter, high, LDR sRGB; no upscaling','tool_stdout':p.stdout.decode()}
if __name__=='__main__':print(run(sys.argv[1],sys.argv[2],int(sys.argv[3]) if len(sys.argv)>3 else None))
