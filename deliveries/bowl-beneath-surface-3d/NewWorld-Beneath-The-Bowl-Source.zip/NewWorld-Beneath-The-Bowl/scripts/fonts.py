from pathlib import Path
from fontTools import subset
R=Path(__file__).resolve().parents[1];text=''.join(x.read_text() for x in (R/'src').glob('*.tsx'))
for source,name in [('NotoSerifCJK-Bold.ttc','BowlSerif'),('NotoSansCJK-Regular.ttc','BowlSans')]:
 o=subset.Options();o.font_number=2;o.flavor='woff';f=subset.load_font('/usr/share/fonts/opentype/noto/'+source,o);s=subset.Subsetter(options=o);s.populate(text=text);s.subset(f);subset.save_font(f,R/'public/fonts'/f'{name}.woff',o)
