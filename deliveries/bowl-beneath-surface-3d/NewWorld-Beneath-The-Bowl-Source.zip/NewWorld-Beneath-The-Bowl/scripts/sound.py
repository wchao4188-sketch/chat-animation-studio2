from pathlib import Path
import numpy as np,json,subprocess,wave,hashlib
from scipy.signal import find_peaks,fftconvolve,butter,sosfilt
R=Path(__file__).resolve().parents[1];A=R/'public/audio';sr=48000;D=10;n=sr*D
m=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(A/'user-music-source.m4a'),'-t','10','-ac','2','-ar',str(sr),'-f','f32le','-']),np.float32).reshape(-1,2)[:n].copy()
x=m.mean(axis=1)[::2];hop=256;win=1024;spec=np.abs(np.fft.rfft(np.lib.stride_tricks.sliding_window_view(x,win)[::hop]*np.hanning(win)));flux=np.maximum(np.diff(np.log1p(spec*8),axis=0),0).sum(axis=1);flux=(flux-flux.mean())/(flux.std()+1e-9);pks,_=find_peaks(flux,prominence=1.2,distance=int(.30*24000/hop));times=(pks*hop+win/2)/24000
ac=fftconvolve(flux,flux[::-1],mode='full')[len(flux)-1:];lags=range(38,87);candidates=[]
for k in sorted(lags,key=lambda k:ac[k],reverse=True):
 bpm=60*24000/hop/k
 if 65<=bpm<=150 and all(abs(bpm-v['bpm'])>4 for v in candidates):candidates.append({'bpm':bpm,'score':float(ac[k]/ac[0])})
 if len(candidates)==3:break
analysis={'source_sha256':hashlib.sha256((A/'user-music-source.m4a').read_bytes()).hexdigest(),'selection_seconds':[0,10],'automatic_bpm_candidates':candidates,'onsets':[{'seconds':round(float(t),4),'frame':round(float(t)*30),'strength':float(flux[p])} for t,p in zip(times,pks)],'method':'Positive log-spectral flux with autocorrelation. Transients and tempo candidates only; meter and bar downbeats not claimed.','voiceover':'None. No narration stems or TTS are used.'};(R/'output/music-analysis.json').write_text(json.dumps(analysis,indent=2))
time=np.arange(n)/sr;m*=.115/(np.sqrt(np.mean(m*m))+1e-8);m*=np.minimum(1,time/.45)[:,None]*np.minimum(1,(10-time)/.65)[:,None]
sfx=np.zeros((n,2),np.float32);rng=np.random.default_rng(231219);events=[]
def add(at,z,pan,kind):
 j=round(at*sr);l=min(len(z),n-j)
 if j<0 or l<=0:return
 sfx[j:j+l]+=z[:l,None]*np.array([np.sqrt((1-pan)/2),np.sqrt((1+pan)/2)])[None,:];events.append({'seconds':at,'kind':kind,'pan':pan,'duration':len(z)/sr})
# A close, small ceramic resonance accompanies the first attention reveal. No imaginary speech or drop.
z=np.arange(round(.52*sr))/sr;ceramic=(np.sin(2*np.pi*1670*z)+.31*np.sin(2*np.pi*2570*z))*np.exp(-z*15)*.036;add(.58,ceramic,.25,'ceramic attention resonance')
# The camera descends as a low material movement opens the hidden space.
z=np.arange(round(1.7*sr))/sr;noise=sosfilt(butter(2,[90,950],btype='bandpass',fs=sr,output='sos'),rng.standard_normal(len(z)));move=noise*np.sin(np.pi*z/1.7)**2*.045;add(1.1,move,.25,'camera / spatial reveal texture')
# A continuously state-shaped texture follows release, acceleration and capture, rather than a fixed whoosh.
a=np.clip((time-3.45)/2.8,0,1);env=np.sin(np.pi*a)**1.7;noise=sosfilt(butter(2,[700,4300],btype='bandpass',fs=sr,output='sos'),rng.standard_normal(n));sfx[:,0]+=noise*.013*env;sfx[:,1]+=noise*.013*env
strain=np.clip((time-3.3)/(6.55-3.3),0,1);strain_deriv=30*strain**2*(1-strain)**2/(6.55-3.3);tone=(np.sin(2*np.pi*(94*time+9*time*time))+.25*np.sin(2*np.pi*183*time))*strain_deriv*.023;sfx+=tone[:,None]
# Sparse selected contacts are linked to actual individual arrivals.
rows=json.loads((R/'assets/particle-mapping.json').read_text())
for row in rows[::18]:
 at=row['departure']+row['duration'];z=np.arange(round(.16*sr))/sr;f=1100+(row['id']%7)*73;click=(np.sin(2*np.pi*f*z)+.2*np.sin(2*np.pi*f*2.31*z))*np.exp(-z*42)*.011;add(at,click,row['side']*.34,'grain contact / actual trajectory arrival')
z=np.arange(round(.9*sr))/sr;release=(np.sin(2*np.pi*78*z)+.18*np.sin(2*np.pi*156*z))*np.exp(-z*5)*.07;add(6.55,release,0,'strain settles, accumulation remains')
master=(m+sfx)*1.33;master*=min(1,.87/(float(abs(master).max())+1e-8))
for name,y in [('music.wav',m),('sfx.wav',sfx),('master.wav',master)]:
 with wave.open(str(A/name),'wb') as w:w.setparams((2,2,sr,0,'NONE','not compressed'));w.writeframes((np.clip(y,-1,1)*32767).astype('<i2').tobytes())
subprocess.run(['ffmpeg','-v','error','-y','-i',str(A/'master.wav'),'-c:a','aac','-b:a','256k',str(A/'master.m4a')],check=True)
(R/'output/sound-events.json').write_text(json.dumps(events,indent=2));print(json.dumps({'bpm_candidates':candidates,'peak':float(abs(master).max()),'narration':False,'events':len(events)},indent=2))
