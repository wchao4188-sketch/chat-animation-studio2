"""Build a fully editable Blender scene. All particles have persistent IDs and baked trajectories."""
import bpy,math,random,json,sys,os,time
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parents[1]
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
MODE=args[0] if args else 'build'
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
S=bpy.context.scene;S.frame_start=1;S.frame_end=300;S.render.fps=30
S.render.resolution_x=1920;S.render.resolution_y=1080;S.render.resolution_percentage=100
S.render.image_settings.file_format='PNG';S.render.image_settings.color_mode='RGB';S.render.image_settings.color_depth='8';S.render.film_transparent=False
S.render.engine='CYCLES';S.cycles.samples=8;S.cycles.use_denoising=False;S.cycles.use_adaptive_sampling=True;S.cycles.adaptive_threshold=.08;S.cycles.adaptive_min_samples=4
S.cycles.max_bounces=4;S.cycles.transmission_bounces=3;S.cycles.glossy_bounces=2
S.render.threads_mode='FIXED';S.render.threads=5
S.view_settings.view_transform='AgX';S.view_settings.look='AgX - Medium High Contrast';S.view_settings.exposure=-.30
S.world.use_nodes=True;S.world.node_tree.nodes['Background'].inputs[0].default_value=(.07,.085,.10,1);S.world.node_tree.nodes['Background'].inputs[1].default_value=.23
S.render.film_transparent=False
rng=random.Random(230418)
def clamp(x):return min(1,max(0,x))
def ease(x):x=clamp(x);return x*x*x*(x*(x*6-15)+10)
def ramp(t,a,b):return ease((t-a)/(b-a))
def lerp(a,b,p):return a+(b-a)*p
def vecmix(a,b,p):return Vector(a).lerp(Vector(b),p)
def look(obj,target):obj.rotation_euler=(Vector(target)-obj.location).to_track_quat('-Z','Y').to_euler()
def mat(name,col,metal=0,rough=.25,trans=0,coat=0):
 m=bpy.data.materials.new(name);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*col,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough;p.inputs['Transmission Weight'].default_value=trans;p.inputs['Coat Weight'].default_value=coat;p.inputs['Coat Roughness'].default_value=.12;return m
porcelain=mat('Cool porcelain / clear glaze',(.72,.79,.82),.08,.145,0,.5)
p=porcelain.node_tree.nodes['Principled BSDF'];p.inputs['Subsurface Weight'].default_value=0
n=porcelain.node_tree.nodes.new('ShaderNodeTexNoise');n.inputs['Scale'].default_value=175;n.inputs['Detail'].default_value=2
b=porcelain.node_tree.nodes.new('ShaderNodeBump');b.inputs['Strength'].default_value=.02;b.inputs['Distance'].default_value=.0005;porcelain.node_tree.links.new(n.outputs['Fac'],b.inputs['Height']);porcelain.node_tree.links.new(b.outputs['Normal'],p.inputs['Normal'])
metal=mat('Satin platinum',(.34,.42,.48),.93,.21,0,.25)
red=mat('Accumulated tension / oxblood lacquer',(.20,.012,.020),.35,.28,0,.35)
red2=mat('Warm chromium grains',(.48,.045,.035),.88,.23,0,.3)
carbon=mat('Graphite stage',(.018,.025,.029),.62,.28)
water=mat('Water / IOR 1.333',(.9,.97,1),0,.015,1,.1);water.node_tree.nodes['Principled BSDF'].inputs['IOR'].default_value=1.333
floor=mat('Obsidian infinite floor',(.009,.014,.018),.45,.24)
def mesh(name,verts,faces,material):
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);o.data.materials.append(material)
 for f in me.polygons:f.use_smooth=True
 return o
def catmull(ps,n=5):
 out=[]
 for j in range(len(ps)-1):
  p0=Vector(ps[max(0,j-1)]);p1=Vector(ps[j]);p2=Vector(ps[j+1]);p3=Vector(ps[min(len(ps)-1,j+2)])
  for k in range(n):
   u=k/n;out.append(.5*((2*p1)+(-p0+p2)*u+(2*p0-5*p1+4*p2-p3)*u*u+(-p0+3*p1-3*p2+p3)*u*u*u))
 out.append(Vector(ps[-1]));return out
# Closed inner/outer section: real wall thickness, rolled lip and raised foot.
section=[(0,.09),(.34,.09),(.47,.09),(.50,.035),(.53,0),(.62,0),(.65,.05),(.68,.12),(.82,.22),(1.00,.36),(1.18,.55),(1.36,.80),(1.44,.98),(1.46,1.04),(1.45,1.07),(1.42,1.08),(1.38,1.04),(1.31,.86),(1.15,.64),(.98,.46),(.80,.32),(.61,.25),(.37,.22),(0,.22)]
profile=catmull(section,4);N=192;vs=[];fs=[]
for r,z in profile:
 r=max(0,r)
 for j in range(N):
  a=j/N*math.tau;vs.append((r*math.cos(a),r*math.sin(a),z*.84))
for k in range(len(profile)-1):
 for j in range(N):a=k*N+j;b=k*N+(j+1)%N;fs.append((a,b,b+N,a+N))
bowl=mesh('Clean porcelain bowl',vs,fs,porcelain);bowl.location=(0,-.65,3.05);bowl.rotation_euler=(math.radians(5),math.radians(-7),0)
# A thin inlaid platinum lip catches the large softbox as a clean contour.
def tube(name,points,radius,material):
 cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=2;cu.bevel_depth=radius;cu.bevel_resolution=3
 sp=cu.splines.new('POLY');sp.points.add(len(points)-1)
 for p,v in zip(sp.points,points):p.co=(*v,1)
 ob=bpy.data.objects.new(name,cu);bpy.context.collection.objects.link(ob);cu.materials.append(material);return ob
lip=tube('Fine platinum lip',[(1.437*math.cos(j/256*math.tau),1.437*math.sin(j/256*math.tau),.895) for j in range(257)],.009,metal);lip.parent=bowl
# Shared smooth water-bead geometry, physically situated on the glazed outer surface.
bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=12,radius=1);template=bpy.context.object;template.name='Water bead template';template.data.materials.append(water)
for f in template.data.polygons:f.use_smooth=True
water_mesh=template.data;bpy.data.objects.remove(template,do_unlink=True)
for j in range(21):
 a=-math.pi*.8+rng.random()*math.pi*1.25;z=.57+rng.random()*.26;r=1.15+(z-.57)*.95
 o=bpy.data.objects.new(f'Adhered water bead {j:02}',water_mesh);bpy.context.collection.objects.link(o);o.parent=bowl;o.location=(r*math.cos(a),r*math.sin(a),z);s=.018+rng.random()*.025;o.scale=(s,s*.53,s*.94);o.hide_render=True
# Two continuous, slightly twisted oval ribbons: relation endpoints, not human characters.
def loop_surface(side):
 v=[];f=[];A=160;B=16
 for j in range(A):
  a=j/A*math.tau;rad=Vector((math.cos(a),0,math.sin(a)));dep=Vector((0,1,0));tw=.32*math.sin(a*2)+side*.12
  for k in range(B):
   b=k/B*math.tau;rr=.095*math.cos(b);dd=.055*math.sin(b);u=rr*math.cos(tw)-dd*math.sin(tw);w=rr*math.sin(tw)+dd*math.cos(tw);q=Vector((.63*math.cos(a),0,.83*math.sin(a)))+rad*u+dep*w;v.append(q)
 for j in range(A):
  for k in range(B):f.append((j*B+k,((j+1)%A)*B+k,((j+1)%A)*B+(k+1)%B,j*B+(k+1)%B))
 o=mesh('Left relation ribbon' if side<0 else 'Right relation ribbon',v,f,metal);return o
loops=[loop_surface(-1),loop_surface(1)]
# An already existing knot: pressure predates the water-drop trigger.
YC=1.65;ZC=1.48;strand_count=32;points_count=113
strand_meta=[]
for j in range(strand_count):strand_meta.append((j*.233,.46+(j%8)*.027,(j%7-3)*.024))
def tension(t):return ramp(t,3.3,6.55)
def anchor(side,j,s):
 a=(0 if side<0 else math.pi)+((j%16)/15-.5)*.90;tw=.32*math.sin(a*2)+side*.12;u=-.095*math.cos(tw);w=-.095*math.sin(tw)
 return Vector((side*(2.38+.40*s)+(.63+u)*math.cos(a),YC+w,ZC+(.83+u)*math.sin(a)))

def core(j,u,s):
 phase,r,zz=strand_meta[j%strand_count];a=math.pi/2+phase*.12+u*2.5*math.pi
 rr=r*(1+.19*math.cos(3*a+phase));x=math.cos(2*a)*rr*(1-.12*s);y=YC+math.sin(3*a+phase)*r*.66;z=ZC+math.sin(2*a)*rr*.92+zz
 return Vector((x,y,z))
def cubic(a,b,c,d,u):return (1-u)**3*a+3*(1-u)**2*u*b+3*(1-u)*u*u*c+u**3*d

def point_on_strand(j,u,s):
 if u<.2:
  p=core(j,0,s);a=anchor(-1,j,s);return cubic(a,a+Vector((.7,0,.03)),p-Vector((.38,0,.03)),p,u/.2)
 if u>.8:
  p=core(j,1,s);a=anchor(1,j,s);return cubic(p,p+Vector((.4,0,.02)),a-Vector((.7,0,.02)),a,(u-.8)/.2)
 return core(j,(u-.2)/.6,s)
strands=[]
for j in range(strand_count):
 ob=tube(f'Accumulated connection {j:02}',[point_on_strand(j,k/(points_count-1),0) for k in range(points_count)],.012 if j%3 else .019,red)
 ob.shape_key_add(name='Rest');key=ob.shape_key_add(name='Tension')
 for k,p in enumerate(key.data):p.co=point_on_strand(j,k/(points_count-1),1)
 strands.append((ob,key))
# Persistent grains: source ring -> transport path -> contact/slide along an existing strand.
bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=8,radius=1);tmp=bpy.context.object;tmp.data.materials.append(red2)
for p in tmp.data.polygons:p.use_smooth=True
grain_mesh=tmp.data;bpy.data.objects.remove(tmp,do_unlink=True)
particles=[];mapping=[]
for i in range(360):
 side=-1 if i%2==0 else 1;j=[6,7,14,15,22,23,30,31][i%8];a=(i*.381966)%1*math.tau;radius=.016+rng.random()*.014
 obj=bpy.data.objects.new(f'Grain {i:03} / persistent',grain_mesh);bpy.context.collection.objects.link(obj);obj.scale=(radius,)*3
 departure=3.45+(i%37)/37*1.52;duration=1.18+(i%13)/13*.52;dest_u=.23+(i*.61803398875%1)*.54
 particles.append((obj,side,j,a,departure,duration,dest_u,radius));mapping.append({'id':i,'side':side,'strand':j,'source_angle':a,'departure':departure,'duration':duration,'target_u':dest_u,'radius':radius})
def source(side,a,s):return Vector((side*(2.38+.40*s)+.63*math.cos(a),YC+.075,ZC+.83*math.sin(a)))
def target(j,u,s,rad):
 q=point_on_strand(j,u,s);v=(q-Vector((0,YC,ZC))).normalized();return q+v*(.018+rad*.85)
def particle_position(item,t):
 obj,side,j,a,dep,dur,u,rad=item;s=tension(t);p0=source(side,a,s)
 if t<=dep:return p0
 tt=clamp((t-dep)/dur)
 if tt>=1:return target(j,u,s,rad)
 # Slow release -> acceleration -> surface capture. Last portion slides along the destination curve.
 surf_u=u+(1-ease(tt))*side*.13;pt=target(j,surf_u,s,rad);tangent=Vector((-.63*math.sin(a),0,.83*math.cos(a))).normalized()
 p1=p0+tangent*.40+Vector((-side*.30,-.18,.10));p2=pt+(pt-Vector((0,YC,ZC))).normalized()*.40+Vector((0,-.22,.10))
 q=cubic(p0,p1,p2,pt,ease(tt));return q
# Stage, floor and small impact ring.
bpy.ops.mesh.primitive_cylinder_add(vertices=128,radius=4.45,depth=.18,location=(0,.7,-.08));stage=bpy.context.object;stage.name='Chamfered graphite stage';stage.data.materials.append(carbon);bev=stage.modifiers.new('Soft machined edge','BEVEL');bev.width=.075;bev.segments=4
for p in stage.data.polygons:p.use_smooth=True
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.19));bpy.context.object.name='Infinite floor';bpy.context.object.data.materials.append(floor)
drop=bpy.data.objects.new('The small trigger / water drop',water_mesh);bpy.context.collection.objects.link(drop)
ring=tube('Damped contact ripple',[(math.cos(k/160*math.tau),math.sin(k/160*math.tau),0) for k in range(161)],.007,water);ring.location=(.96,-1.55,.025)
# A continuous floor-to-wall cove removes the artificial horizon.
cv=[];cf=[]
for k in range(65):
 a=k/64*math.pi/2;y=5+8*math.sin(a);z=-.19+8*(1-math.cos(a));cv.extend([(-100,y,z),(100,y,z)])
cv.extend([(-100,13,80),(100,13,80)])
for k in range(65):cf.append((k*2,k*2+1,k*2+3,k*2+2))
mesh('Seamless cyclorama',cv,cf,floor)
drop.hide_render=True;ring.hide_render=True
# Large photographic lights produce real speculars and soft shadows.
def area(name,loc,target,power,col,size,sy=None):
 d=bpy.data.lights.new(name,'AREA');d.energy=power;d.color=col;d.shape='RECTANGLE';d.size=size;d.size_y=sy or size;o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);o.location=loc;look(o,target);return o
area('Key / large silk',(-3.5,-4.5,7),(0,0,2),800,(.82,.9,1),3.7,4)
area('Rim / tall softbox',(4.5,2.5,5),(0,1,2),1000,(.92,.96,1),2.8,5)
area('Front porcelain bounce',(0,-6,4),(0,0,3),100,(1,.98,.94),3,2)
area('Core side strip',(-4,1,2.5),(0,1.6,1.5),150,(1,.32,.27),2.5,3)
area('Core top silk',(0,2,6),(0,1.6,1.4),380,(1,.90,.85),2,3)
area('Far cool separator',(1,5,3),(0,1.6,1.5),1000,(.55,.75,1),3,4)
# One continuous camera move, held at the end. DOF focus follows the revealed explanation.
bpy.ops.object.camera_add();camera=bpy.context.object;camera.name='Continuous reveal camera';S.camera=camera
focus=bpy.data.objects.new('Focus / bowl to underlying knot',None);bpy.context.collection.objects.link(focus);camera.data.dof.use_dof=True;camera.data.dof.focus_object=focus;camera.data.dof.aperture_fstop=8;camera.data.sensor_width=36
# Bake all motion: the .blend remains editable without an external frame handler.
for f in range(1,301):
 t=(f-1)/30;move=ramp(t,1.1,3.8);s=tension(t)
 for idx,ob in enumerate(loops):
  side=-1 if idx==0 else 1;ob.location=(side*(2.38+.40*s),YC,ZC);ob.keyframe_insert(data_path='location',frame=f)
 for ob,key in strands:key.value=s;key.keyframe_insert(data_path='value',frame=f)
 for item in particles:
  item[0].location=particle_position(item,t);item[0].keyframe_insert(data_path='location',frame=f)
 # Gravitational drop, then a conserved flattened puddle on the floor.
 elapsed=max(0,t-1.3);z=max(.045,3.68-4.905*elapsed*elapsed);hit=1.3+math.sqrt((3.68-.045)/4.905);splash=ramp(t,hit,hit+.16)
 drop.location=(.96,-1.55,z);drop.scale=(lerp(.043,.14,splash),lerp(.043,.14,splash),lerp(.065,.01,splash));drop.keyframe_insert(data_path='location',frame=f);drop.keyframe_insert(data_path='scale',frame=f)
 ripple=clamp((t-hit)/2);rs=.015+3.5*ease(ripple);ring.scale=(rs,rs,max(.001,1-ripple));ring.keyframe_insert(data_path='scale',frame=f)
 camera.location=vecmix((4.4,-10.8,7.3),(5.0,-12.8,2.95),move);aim=vecmix((-.78,-.45,4.55),(-1.02,1.15,1.82),move);look(camera,aim);camera.data.lens=lerp(63,49,move)
 focus.location=vecmix((0,-.65,3.55),(0,YC,ZC),ramp(t,1.0,3.6));camera.keyframe_insert(data_path='location',frame=f);camera.keyframe_insert(data_path='rotation_euler',frame=f);camera.data.keyframe_insert(data_path='lens',frame=f);focus.keyframe_insert(data_path='location',frame=f)
# Linear between baked frame samples; trajectories themselves have analytic smooth acceleration.
for datablock in list(bpy.data.objects)+list(bpy.data.shape_keys)+list(bpy.data.cameras):
 if datablock.animation_data and datablock.animation_data.action:
  for curve in datablock.animation_data.action.fcurves:
   for key in curve.keyframe_points:key.interpolation='LINEAR'
S.render.use_motion_blur=False;S.render.motion_blur_shutter=.35
S.view_layers[0].cycles.denoising_store_passes=True
S.use_nodes=True;nodes=S.node_tree.nodes;nodes.clear();rl=nodes.new('CompositorNodeRLayers');comp=nodes.new('CompositorNodeComposite');S.node_tree.links.new(rl.outputs['Image'],comp.inputs['Image'])
for label,socket in [('normal','Denoising Normal'),('albedo','Denoising Albedo')]:
 out=nodes.new('CompositorNodeOutputFile');out.base_path=str(R/'output/aux');out.format.file_format='OPEN_EXR';out.format.color_mode='RGB';out.format.color_depth='32';out.file_slots[0].path=label+'_';S.node_tree.links.new(rl.outputs[socket],out.inputs[0])
if MODE=='production':
 S.render.engine='BLENDER_EEVEE_NEXT';S.eevee.taa_render_samples=4
 for node in list(S.node_tree.nodes):
  if node.type=='OUTPUT_FILE':S.node_tree.nodes.remove(node)
 for light in bpy.data.lights:
  if hasattr(light,'use_shadow_jitter'):light.use_shadow_jitter=False
S.frame_set(1);S.render.filepath=str(R/'public/frames/frame_')
from bpy_extras.object_utils import world_to_camera_view
projected=[]
for f in range(1,301):
 S.frame_set(f);bpy.context.view_layer.update();row={'frame':f}
 for name,point in [('knot',Vector((0,YC,ZC))),('bowl',bowl.matrix_world@Vector((0,0,.50))),('left',loops[0].matrix_world.translation.copy()),('right',loops[1].matrix_world.translation.copy())]:
  v=world_to_camera_view(S,camera,point);row[name]=[v.x*1920,(1-v.y)*1080]
 projected.append(row)
(R/'src/anchors.json').write_text(json.dumps(projected))
(R/'src/endpoints.json').write_text(json.dumps([{'left':x['left'],'right':x['right']} for x in projected]))
(R/'assets/particle-mapping.json').write_text(json.dumps(mapping,indent=2))
# Analytic continuity report checks all 360 transport histories and target contacts.
report={'particles':len(particles),'all_persistent_frames':[1,300],'minimum_departure':min(x[4] for x in particles),'maximum_arrival':max(x[4]+x[5] for x in particles),'maximum_frame_step':max((particle_position(p,(f+1)/30)-particle_position(p,f/30)).length for p in particles for f in range(299)),'maximum_position_jump_at_departure':max((particle_position(p,p[4]+1e-6)-particle_position(p,p[4]-1e-6)).length for p in particles),'maximum_position_jump_at_arrival':max((particle_position(p,p[4]+p[5]+1e-6)-particle_position(p,p[4]+p[5]-1e-6)).length for p in particles),'target_contact_offset':'0.018 scene units + 0.85 grain radius from centerline; approximate contact follows same strain, not a rigid-body solver','no_opacity_teleport':True,'render_engine':S.render.engine,'note':'Designed, deterministic force-like trajectories; conceptual particle visualization, not a claim of full fluid/rigid-body simulation.'}
(R/'output/particle-continuity.json').write_text(json.dumps(report,indent=2));print('CONTINUITY',json.dumps(report),flush=True)
bpy.ops.wm.save_as_mainfile(filepath=str(R/'assets/Beneath-The-Bowl.blend'))
if MODE=='guide-test':
 S.cycles.samples=4;S.cycles.adaptive_min_samples=1
 S.frame_set(160);S.render.filepath=str(R/'output/review/guide-160.png');begin=time.time();bpy.ops.render.render(write_still=True);print('GUIDE_SECONDS',time.time()-begin,flush=True)
elif MODE=='native-test':
 for frame in [1,160,240]:
  S.frame_set(frame);S.render.filepath=str(R/f'output/review/native-{frame:03}.png');begin=time.time();bpy.ops.render.render(write_still=True);print('NATIVE_SECONDS',frame,time.time()-begin,flush=True)
elif MODE in ['test','eevee-test']:
 S.render.resolution_percentage=50;S.cycles.samples=16
 if MODE=='eevee-test':S.render.engine='BLENDER_EEVEE_NEXT';S.eevee.taa_render_samples=32
 for frame in [1,160,240]:
  S.frame_set(frame);S.render.filepath=str(R/f'output/review/{MODE}-{frame:03}.png');begin=time.time();bpy.ops.render.render(write_still=True);print('FRAME_SECONDS',frame,time.time()-begin,flush=True)
elif MODE=='production':
 import subprocess,shutil
 raw=R/'output/raw';raw.mkdir(exist_ok=True);(R/'public/frames').mkdir(exist_ok=True)
 frames=[1]+list(range(34,200));begin=time.time();progress=[]
 for index,frame in enumerate(frames):
  dst=R/f'public/frames/frame_{frame:04}.png'
  if dst.exists():
   progress.append({'frame':frame,'seconds':0,'cached':True});(R/'output/render-progress.json').write_text(json.dumps({'completed':index+1,'unique_frames':len(frames),'current_blender_frame':frame,'elapsed':time.time()-begin,'frames':progress},indent=2));continue
  S.eevee.taa_render_samples=8 if frame>=115 else 4
  S.frame_set(frame);S.render.filepath=str(raw/f'frame_{frame:04}.png');start=time.time();bpy.ops.render.render(write_still=True)
  with (R/'output/oidn-production.log').open('a') as log:subprocess.run(['python',str(R/'scripts/denoise.py'),S.render.filepath,str(dst)],stdout=log,stderr=log,check=True)
  progress.append({'frame':frame,'seconds':time.time()-start})
  (R/'output/render-progress.json').write_text(json.dumps({'completed':index+1,'unique_frames':len(frames),'current_blender_frame':frame,'elapsed':time.time()-begin,'frames':progress},indent=2))
  print('PRODUCTION_PROGRESS',index+1,len(frames),frame,time.time()-begin,flush=True)
 for frame in range(1,301):
  dst=R/f'public/frames/frame_{frame:04}.png'
  if not dst.exists():
   src=R/f'public/frames/frame_{1 if frame<=33 else 199:04}.png';os.link(src,dst)
 subprocess.run(['ffmpeg','-v','error','-y','-framerate','30','-start_number','1','-i',str(R/'public/frames/frame_%04d.png'),'-frames:v','300','-c:v','libx264','-crf','12','-preset','medium','-pix_fmt','yuv420p','-movflags','+faststart',str(R/'public/Bowl-3D-Layer.mp4')],check=True)
 print('PRODUCTION_DONE',time.time()-begin,flush=True)
elif MODE=='render':
 bpy.ops.render.render(animation=True)
