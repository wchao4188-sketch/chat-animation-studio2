import {openBrowser} from '@remotion/renderer';
import fs from 'node:fs/promises';
const b=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium',logLevel:'error'});
try{
 const p=await b.newPage({context:()=>null,logLevel:'error',indent:false,pageIndex:0,onBrowserLog:null,onLog:()=>{}});
 await p.goto({url:'http://127.0.0.1:3133/',timeout:30000,options:{waitUntil:'load'}});
 const result=await p.evaluate(async()=>{const v=document.createElement('video');v.src='Particle-Continuity-Review-0.5x.mp4';v.muted=true;v.width=960;v.controls=true;document.body.append(v);await new Promise((r,j)=>{v.onloadedmetadata=r;v.onerror=()=>j(new Error('Metadata failed'))});await v.play();await new Promise((r,j)=>{v.onended=r;v.onerror=()=>j(new Error('Playback failed'));setTimeout(()=>j(new Error('Timeout')),30000)});const q=v.getVideoPlaybackQuality();return{duration:v.duration,ended:v.ended,currentTime:v.currentTime,totalFrames:q.totalVideoFrames,droppedFrames:q.droppedVideoFrames,error:v.error?.message||null,muted:true,human_audio_listening:false}});
 await fs.writeFile('output/slow-motion-playback.json',JSON.stringify(result,null,2));console.log(result);
}finally{await b.close({silent:true})}
