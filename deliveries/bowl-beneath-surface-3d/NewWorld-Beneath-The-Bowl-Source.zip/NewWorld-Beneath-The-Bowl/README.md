# 新世界｜碗洗了，为什么还在吵？

10秒原创三维知识可视化。1920×1080、16:9、30fps、300帧，无新增配音。主视觉是干净瓷碗、关系两端与已经存在的情绪结：摄影机下移揭示，颗粒从两端进入同一个结，最后停留在关系结构上。它是视觉隐喻，不把具体家庭矛盾诊断为某一种原因。

## 观看与编辑

成片 `NewWorld-Beneath-The-Bowl-10s.mp4` 单独交付。源工程包不重复包含最终MP4，但包含已渲染的三维底片 `public/Bowl-3D-Layer.mp4`，可直接编辑字幕、排版、音轨并再次合成。

- `npm ci` 安装锁定依赖；`npm run studio` 打开 Remotion Studio。
- `npm run typecheck` 检查 TypeScript；`npm run render` 合成新的完整MP4。
- `assets/Beneath-The-Bowl.blend` 是可编辑的真实三维工程，包含模型、程序材质、灯光、摄影机、景深及所有烘焙关键帧。
- `scripts/scene.py` 重新生成几何和确定性动画；`scripts/refine-holds.py` 精修静止姿态；`scripts/denoise.py` 调用独立OIDN；`scripts/full-render.sh` 串联整个流程，并备份旧帧缓存后重新计算；直接调用 production 只适合同一场景版本的断点续渲。
- `src/Film.tsx` 是字幕、标记与音轨；`src/anchors.json` / `endpoints.json` 来自实际摄影机投影，标记与模型共用坐标。
- `public/audio/music.wav`、`sfx.wav`、`master.wav` 为音乐、音效、总混音分轨；不存在旁白分轨。

## 三维与声音方法

瓷碗有连续内外截面、真实壁厚、卷边和圈足，192段旋转网格；釉面、铂金环与暗红线材由程序材质完成。主体不是静态截图拼接。

360颗粒具有固定编号和实际环面来源。释放、加速、曲线路径、靠近目标、沿目标曲线滑行与停稳都使用同一确定性公式；目标和关系曲线共享拉紧时间轴。粒子不是用透明度消失后再生成。轨迹是经过设计的运动学可视化，不宣称完整流体或刚体动力学模拟。

结从开场就存在，镜头运动揭示其全貌；粒子汇聚以后结仍然存在，碗保持干净。文字保留「未必」「可能」，避免把虚构视觉隐喻当作对真实关系的判断。

保留开头与结尾的静止阅读段，运动区间逐帧渲染；完全相同的静止状态复用同一画面，没有将运动段降帧。三维原生1920×1080，没有使用540p放大。Eevee镜头揭示段4次采样，粒子主体段8次采样，静止关键姿态另以48次采样精修，独立OIDN处理；因此不声称完整Cycles路径追踪或离线高采样电影制作规格。

使用用户已有音乐的0–10秒。BPM是自动候选，见音乐分析JSON；小节重拍没有人工确认。摄影机开始、结构拉紧与粒子接触采用实际时间轴；音效为本地合成，不冒充现场录音。没有新增旁白。

## 依赖与复现

已实际使用：Blender 4.3.2、Remotion 4.0.536、React 19.2.4、TypeScript 5.9.3、Chromium 154、FFmpeg 7.1.5。没有新增npm依赖。

本轮补充工具：官方 Intel Open Image Denoise 2.3.3（Linux CPU）。当前Blender构建没有内置OIDN支持，所以调用官方独立工具。Linux工具包来自：
`https://github.com/RenderKit/oidn/releases/download/v2.3.3/oidn-2.3.3.x86_64.linux.tar.gz`
SHA-256：`3c385230d9e6f63527ba72f2229594dbac5051674219d72e0044b5d0b841796f`。

完整重建三维时，可把官方工具包解压到 `tools/`，或以 `OIDN_BIN` 指定可执行文件。普通Remotion合成不需要OIDN或Blender。`Lookdev` 合成仅用于静态排版检查，正式成片合成是 `BeneathTheBowl`。Python制作脚本使用NumPy/SciPy/Pillow/fontTools。脚本在Linux实际验证，Windows完整渲染未验证。

中文字体为Noto CJK本地子集，许可在 `assets/Font-LICENSE.txt`；OIDN许可附在 `assets/`。原有项目、成片和交付包未覆盖。

## 验收

最终事实以 `output/Acceptance.md`、`quality-check.json`、`playback-check.json`、`particle-continuity.json` 为准。技术检查不能认证「电影级」的主观审美，也没有真人试听的通过声明。
