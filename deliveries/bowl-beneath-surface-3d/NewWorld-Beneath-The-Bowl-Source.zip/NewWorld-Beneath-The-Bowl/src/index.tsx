import React from 'react';
import {Composition,registerRoot} from 'remotion';
import {Film} from './Film';
const Root=()=> <>
 <Composition id="BeneathTheBowl" component={Film} durationInFrames={300} fps={30} width={1920} height={1080}/>
 <Composition id="Lookdev" component={Film} defaultProps={{lookdev:'lookdev.png'}} durationInFrames={300} fps={30} width={1920} height={1080}/>
</>;
registerRoot(Root);
