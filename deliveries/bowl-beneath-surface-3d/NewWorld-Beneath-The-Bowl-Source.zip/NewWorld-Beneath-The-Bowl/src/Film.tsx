import React,{useEffect,useState} from 'react';
import {AbsoluteFill,continueRender,delayRender,staticFile,useCurrentFrame,useVideoConfig,interpolate,Easing,Img} from 'remotion';
import {Video,Audio} from '@remotion/media';
import endpoints from './endpoints.json';
import anchors from './anchors.json';
const ease=(x:number)=>{x=Math.max(0,Math.min(1,x));return 1-Math.pow(1-x,4)};
const band=(t:number,a:number,b:number,c:number,d:number)=>ease((t-a)/(b-a))*(1-ease((t-c)/(d-c)));
export const Film=({lookdev}:{lookdev?:string})=>{
 const frame=useCurrentFrame(),{fps}=useVideoConfig(),t=frame/fps;const [h]=useState(()=>delayRender('Load film typography'));useEffect(()=>{Promise.all(['BowlSerif','BowlSans'].map(n=>new FontFace(n,`url(${staticFile(`fonts/${n}.woff`)})`).load())).then(fs=>{fs.forEach(f=>(document.fonts as FontFaceSet & {add:(f:FontFace)=>void}).add(f));continueRender(h)})},[h]);
 const positions=endpoints[Math.min(frame,299)],core=anchors[Math.min(frame,299)].knot;
 const intro=band(t,0,.6,2.35,2.95),middle=band(t,2.65,3.3,6.0,6.6),end=ease((t-6.7)/.7),note=ease((t-4.1)/.7);
 return <AbsoluteFill style={{background:'#050708',color:'#e5e8e7',fontFamily:'BowlSans'}}>
  {lookdev?<Img src={staticFile(lookdev)} style={{width:'100%',height:'100%'}}/>:<Video src={staticFile('Bowl-3D-Layer.mp4')} style={{width:'100%',height:'100%'}} muted/>}
  <div style={{position:'absolute',left:0,top:0,bottom:0,width:620,background:'linear-gradient(90deg,rgba(3,6,8,.22),transparent)'}}/>
  <div style={{position:'absolute',left:86,top:62,fontSize:21,letterSpacing:4,color:'#8e999e'}}>新世界 <span style={{marginLeft:22,fontSize:13,letterSpacing:3}}>BENEATH THE SURFACE</span></div>
  <div style={{position:'absolute',left:85,top:245,opacity:intro,translate:`0px ${25*(1-ease(t/.6))}px`,fontFamily:'BowlSerif',fontSize:63,lineHeight:1.47,whiteSpace:'pre',letterSpacing:-1}}>{'碗明明洗了，\n为什么还在吵？'}</div>
  <div style={{position:'absolute',left:90,top:477,opacity:intro,fontSize:21,letterSpacing:4,color:'#869296'}}>眼前的事 / 关系里的事</div>
  <div style={{position:'absolute',left:88,top:335,opacity:middle,fontSize:40,lineHeight:1.7}}>
    <div>眼前的事，结束了。</div>
    <div style={{fontSize:27,color:'#91a2aa',marginTop:22}}>但关系里的积累，<br/>并没有随之消失。</div>
  </div>
  <div style={{position:'absolute',left:88,top:260,opacity:end,fontFamily:'BowlSerif',fontSize:65,lineHeight:1.5,whiteSpace:'pre'}}>{'碗干净了。\n矛盾未必结束。'}</div>
  <div style={{position:'absolute',left:92,top:517,opacity:end,width:440,fontSize:29,lineHeight:1.6,color:'#a3afb4'}}>争吵，可能不只为了<br/>眼前这一件事。</div>
  <div style={{position:'absolute',left:positions.left[0],top:positions.left[1]-12,translate:'-50% -50%',fontSize:23,letterSpacing:4,color:'#a5b3ba',opacity:note}}>你</div>
  <div style={{position:'absolute',left:positions.right[0],top:positions.right[1]-12,translate:'-50% -50%',fontSize:23,letterSpacing:4,color:'#a5b3ba',opacity:note}}>对方</div>
  <div style={{position:'absolute',left:core[0],top:core[1]-8,translate:'-50% -50%',fontSize:25,letterSpacing:5,color:'#c8b8b5',opacity:note}}>积累</div>
  <div style={{position:'absolute',left:88,bottom:110,opacity:note,fontSize:20,letterSpacing:2,color:'#a0adb2',borderLeft:'2px solid #a35050',paddingLeft:17}}>长期积累的情绪与关系矛盾</div>
  <Audio src={staticFile('audio/master.m4a')} muted={Boolean(lookdev)}/>
 </AbsoluteFill>
};
