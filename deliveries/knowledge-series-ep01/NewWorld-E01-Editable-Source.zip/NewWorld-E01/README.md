# 新世界 · 知识大赏 01

《你想帮忙，为什么越说越火？》

90秒，1920×1080，16:9，30fps，无新增配音。冷白、石墨与荧光黄；字幕承担完整讲解，观点、方法和案例有不同字号、颜色与字重。

## 预览与编辑

```sh
npm ci
npm run studio
```

Studio主片：`Support`。`Scenes`目录中的9个分镜各有独立时间轴，`src/scenes/`可逐镜修改。所有运动由帧计算，无CSS时间动画或每帧随机数。

## 独立渲染

```sh
npx remotion render src/index.tsx Support output/NewWorld-E01-Support-90s.mp4 --codec=h264 --crf=17 --pixel-format=yuv420p --audio-codec=aac --audio-bitrate=256k --concurrency=4
```

当前环境渲染使用已安装Chromium，附加`--browser-executable=/usr/bin/chromium`；其他机器按当地浏览器路径调整。

`npm run render`是独立Remotion入口。`npm run render:integrated`是当前工作区集成入口，需要已有Open Montage适配层与`config.json`里的本机路径；上面的独立Remotion命令不需要Open Montage。跨机器`npm ci`未在此环境外实测。

## 素材与内容

- 音乐：用户已上传`mmexport1792300994359.mp3`，实际探测为含AAC音轨的媒体容器。仅提取6.1—96.1秒的音频；包内保留选段和最终混音，不使用原始容器内的视频画面。
- 音效：本地确定性合成，非现场录音。`public/audio/sfx.wav`。
- 字体：系统Noto Sans CJK SC经过字形子集化；许可见`public/fonts/LICENSE.txt`。
- 内容：根据上传《高级男人手册》正文69—71、192—195页相关讨论改编。复述核实、询问支持方式等为延伸方法。案例为原创虚构；没有使用90%比例、性别决定论或结果承诺。
- 模型：接收门、信息轨道是沟通示意，不是真实心理机制或脑结构。
- 画面：本片为自制SVG矢量及层次、材质、路径动画，没有使用库存场景或声称三维光追。

## 已复用与新增依赖

沿用工作区Remotion4.0.536、React19.2.4、TypeScript5.9.3，以及已有fonts/media组件。没有新增npm依赖。Open Montage用于实际素材探测、混音、合成预检和最终抽帧；主画面由锁定版本Remotion渲染。

完整来源区分与知识审核在`artifacts/knowledge-distillation.md`；文字脚本及时间轴在`artifacts/script.json`、`artifacts/scene_plan.json`。
