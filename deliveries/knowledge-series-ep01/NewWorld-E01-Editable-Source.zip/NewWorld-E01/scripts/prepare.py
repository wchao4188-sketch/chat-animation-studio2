from pathlib import Path
import json,sys,subprocess,hashlib
R=Path(__file__).resolve().parents[1]
scenes=[('Hook',0,5,'你越安慰，\n对方越生气？','一句建议，为什么没被接住？'),('Case',5,17,'“今天又被临时加活，累死了。”','“那你就换工作啊。”\n“我只是想先说说……”'),('Mismatch',17,28,'你急着解决的，\n可能不是此刻的问题。','你听见“加活”，立刻给方案。\n对方说“累”，也许想先被理解。'),('Channels',28,39,'同一句抱怨，\n可能需要不同的支持。','听我说完 / 陪我一会 / 一起想办法'),('Reflect',39,51,'先复述，再核实。','“听起来，临时加活让你很累。”\n“我理解得对吗？”'),('Ask',51,64,'别急着猜，直接问。','“你想先说说、让我陪会儿，\n还是一起想办法？”'),('Adjust',64,77,'跟着回应，调整帮法。','想说说 → 先听，少打断\n想办法 → 问清限制，再提建议\n想静静 → 尊重空间，约好再聊'),('Boundary',77,84,'理解情绪，\n不等于同意所有要求。','情绪可以被理解，具体事情仍要协商。'),('Close',84,90,'先对齐，再帮忙。','听清 → 问清 → 再行动')]
rows=[dict(id=x,start=a,end=b,start_frame=round(a*30),end_frame=round(b*30),headline=c,support=d) for x,a,b,c,d in scenes]
(R/'artifacts/script.json').write_text(json.dumps({'title':'你想帮忙，为什么越说越火？','episode':1,'duration_seconds':90,'fps':30,'width':1920,'height':1080,'voiceover':False,'case_type':'原创虚构情境','sections':rows,'source':{'file':'《高级男人手册》 .pdf','body_pages':[69,70,71,192,193,194,195],'pdf_pages':[73,74,75,196,197,198,199]},'provenance':'基于原书“关心与分析可能错位”的讨论改编；复述核实、询问支持偏好、跟随反馈属于延伸方法，不冒充原书已有流程。','not_used':['90%的比例','女性不能分析的性别概括','爱解决一切的保证','未经同意的身体接触'],'review':{'absolute_promises':False,'fiction_identified':True,'medical_claims':False,'mind_reading_claims':False,'chapter_closure':'本集完整演示方法和边界，不依赖下一集补全。'}},ensure_ascii=False,indent=2))
(R/'artifacts/scene_plan.json').write_text(json.dumps({'scenes':rows,'style':'冷白／石墨黑／荧光黄。实体感路径与通道隐喻；每段改变模型解释不同信息，不是统计或脑机制。','motion':'字形裁切揭示；提案流在错误轨道停住；三个支持路径分流；询问令选择门对齐；沿回应进入不同路径；末段收敛为行动顺序。','reading':'主要标题80—112px；方法强调92px；对话46—52px；正文40—48px；来源25px。固定断行。每个主要句至少稳定2秒。'},ensure_ascii=False,indent=2))
(R/'artifacts/knowledge-distillation.md').write_text('''# 第一期知识提炼与内容审核

## 来源
上传版本正文p69—71、192—195（PDF第73—75、196—199页）。作者主张：有些时刻关心与在场比立刻分析更贴近伴侣需求。原文将其按性别概括，并使用未提供可复核统计来源的90%说法，本片不采用这些部分。

## 八项提炼
1. 核心观点（改编解释）：帮忙前，先确认对方当下需要什么支持。
2. 底层逻辑（可能解释）：建议面向改变事情；倾听面向表达经历。两者可能错位，不能只从一句话断定。
3. 关键技能（延伸）：复述具体感受、核实理解、询问偏好、跟随回应调整。
4. 操作方法（延伸）：用试探语气复述；问理解是否准确；给出倾听、陪伴、共同想办法等选择；听到纠正就修改；对方想暂停则尊重并协商再聊。
5. 案例：临时加活后想诉说，一方立即建议辞职。原创虚构，不是原书真实事件。
6. 误区：把所有抱怨当成索取安慰；反复机械套句；未经邀请不断提出方案；认为听懂意味着同意所有要求。
7. 边界：支持偏好会变化；实际困难仍需处理；双方权利与意愿保留；不承诺消除情绪或修复所有关系。
8. 一句话总结：先对齐，再帮忙。

## 价值与去重
选K07：日常困境具体，方法可演示，适合习惯迅速给建议的人。不同时制作其他知识点；本片自身包含问题、解释、演示、反馈和边界。

## 内容审核
逐句核对来源归属。无疗效、幸福、吸引力或关系结果保证；无原书数字，无男女定律。三个通道是帮助理解的视觉隐喻，并非心理分类全集或真实脑机制。
''')
(R/'artifacts/decision_log.json').write_text(json.dumps([{'category':'scope','subject':'First complete episode','selected':'90s; 1920x1080; 30fps; no voiceover; only episode 1','authorization':'用户要求单条2分钟内、横屏、逐条交付；最新要求明确无配音并突出字幕层级。沿用自主创作授权，不请求已明确的创作选择。'},{'category':'render_runtime_selection','subject':'Episode rendering','selected':'Remotion','options_considered':{'Remotion':'现有稳定React帧驱动动画与本地字体，易逐镜修改；需要手写动态图形。','HyperFrames':'适合HTML/GSAP动排；本工作区尚无相同级别的正式渲染验证，不因工具存在更换既定Remotion路径。','FFmpeg':'适合混音封装与检测，不承担主体动画。'}},{'category':'composition_mode','subject':'Visual authoring','selected':'atelier; project-specific vector depth and optical-channel model; no stock scenes'},{'category':'tool_reuse','subject':'Open Montage','selected':'素材探测、音乐裁切、混音、合成预检、最终抽帧；动画由项目独立Remotion源码制作。','limits':'复用已验证适配层，不声称满足上游所有通用研究schema或审美自动验收。'}],ensure_ascii=False,indent=2))
# Cover complete on-screen copy in embedded font subsets.
text=''.join(x['headline']+x['support'] for x in rows)+'''新世界知识大赏第一期沟通示意原创情境不代表所有关系提炼依据高级男人手册相关章节方法为延伸不作结果保证不是读心也不是给好感评分你可能需要的三种支持并非全部类型先听再问对齐帮忙对话方案感受理解需要临时加活累死了也许先被看见反馈不是评判按对方回答修改判断不必硬聊尊重对方的停顿建议有用也要看时机同意协商想静静本片无配音请阅读字幕听我说完陪我一会一起想办法你想解决工作问题对方可能正在表达疲惫此刻优先不合适调整你听见了什么直接询问更可靠不是所有抱怨都要安慰也可能就是想要建议先听清再问清最后一起做情绪与事实都值得认真对待内容根据上传资料改编案例原创方法延伸不构成普遍定律01020304CHAPTERSIGNALCONTEXTSUPPORTRESETUNDERSTANDBEFOREYOUSOLVEABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,!?，。！？：“”／→—·《》%()+-'''
text += ''.join(q.read_text() for q in (R/'src').rglob('*.tsx'))
(R/'artifacts/font-characters.txt').write_text(text)
from fontTools.ttLib import TTCollection
from fontTools import subset
for weight,src in [('Regular','/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'),('Bold','/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc')]:
 fonts=TTCollection(src).fonts;font=next(f for f in fonts if any(n.toUnicode()=='Noto Sans CJK SC' for n in f['name'].names if n.nameID in [1,16]))
 opt=subset.Options();opt.flavor='woff';s=subset.Subsetter(options=opt);s.populate(text=text);s.subset(font);font.flavor='woff';font.save(R/'public/fonts'/f'NotoSansSC-{weight}.woff')
# New adapter configuration; old project untouched.
sys.path.insert(0,'/workspace/-/knowledge-production-system')
from orchestrator.dispatch import Dispatcher,Request
D=Dispatcher(json.loads((R/'config.json').read_text()))
music=Path('/workspace/attachments/e0ebc65e-d848-4388-bb8b-30e2e6bd107a/mmexport1792300994359.mp3')
r=D.run(Request('source_music_probe','media.probe',{'input_path':str(music)},[str(music)],allow_fallback=True));assert r['success'],r
# It is a video container despite extension; trim tool can extract audio only.
p={'input_path':str(music),'start_time':6.1,'end_time':96.1,'output_path':str(R/'public/audio/music-excerpt.m4a')}
# Native tool schema is inspected first; operation documented in prior integration.
import sys as _sys
_sys.path.insert(0,'/workspace/tools/OpenMontage')
# trim in audio-only extraction via FFmpeg so embedded video is not copied as music.
if not (R/'public/audio/music-excerpt.m4a').exists():
 subprocess.run(['ffmpeg','-v','error','-n','-ss','6.1','-i',str(music),'-t','90','-vn','-c:a','aac','-b:a','256k',str(R/'public/audio/music-excerpt.m4a')],check=True)
events=[{'time':t,'label':name} for name,t in [('hook arrival',.6),('first reply',9.2),('wrong lane stopped',19.8),('three channels expand',29.2),('reflect contact',42.0),('question branches',55.0),('listening selection',64.8),('advice selection',69.0),('pause selection',73.0),('boundary aperture',77.6),('recap resolves',85.4)]]
r=D.run(Request('music_rhythm','audio.rhythm',{'input_path':str(R/'public/audio/music-excerpt.m4a'),'output_path':str(R/'artifacts/music-rhythm.json'),'events':events},[str(R/'public/audio/music-excerpt.m4a')]));assert r['success'],r
r=D.run(Request('sound_synthesis','audio.sfx',{'duration':90,'events':events,'output_path':str(R/'public/audio/sfx.wav')}));assert r['success'],r
r=D.run(Request('mix_master','audio.mix',{'operation':'full_mix','tracks':[{'path':str(R/'public/audio/music-excerpt.m4a'),'role':'music','volume':.44,'fade_in_seconds':.3,'fade_out_seconds':2},{'path':str(R/'public/audio/sfx.wav'),'role':'sfx','volume':.85}],'normalize':True,'loudnorm_target':-17,'target_duration':90,'ducking':{'enabled':False},'output_path':str(R/'public/audio/master.wav')},[str(R/'public/audio/music-excerpt.m4a'),str(R/'public/audio/sfx.wav')],cache=True));assert r['success'],r
print('PREPARED',len(rows),'scenes; audio:',r['tool'])
