from pathlib import Path
import subprocess,json,numpy as np,hashlib
R=Path(__file__).resolve().parents[1];v=R/'output/NewWorld-E01-Support-90s.mp4'
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(v)]))
(R/'artifacts/ffprobe-final.json').write_text(json.dumps(probe,indent=2))
vs=next(s for s in probe['streams'] if s['codec_type']=='video');au=next(s for s in probe['streams'] if s['codec_type']=='audio')
assert (vs['width'],vs['height'],vs['avg_frame_rate'],int(vs['nb_frames']))==(1920,1080,'30/1',2700)
assert abs(float(probe['format']['duration'])-90)<.04
r=subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(v),'-f','null','-'],capture_output=True,text=True);assert r.returncode==0,r.stderr
(R/'artifacts/full-decode.txt').write_text(r.stderr or 'Full video and audio decode completed with exit code 0; no FFmpeg decode errors.\n')
p=subprocess.Popen(['ffmpeg','-v','error','-i',str(v),'-an','-vf','scale=160:90,format=gray','-f','rawvideo','-'],stdout=subprocess.PIPE)
means=[];motion=[];prev=None;N=160*90
while True:
 b=p.stdout.read(N)
 if not b:break
 assert len(b)==N
 a=np.frombuffer(b,np.uint8).astype(float);means.append(float(a.mean()));motion.append(float(np.abs(a-prev).mean()) if prev is not None else 0);prev=a
assert p.wait()==0 and len(means)==2700
black=[i for i,m in enumerate(means) if m<4];assert not black
r=subprocess.run(['ffmpeg','-hide_banner','-i',str(v),'-af','ebur128=peak=true','-vn','-f','null','-'],capture_output=True,text=True);(R/'artifacts/final-loudness.txt').write_text(r.stderr)
rows=json.loads((R/'artifacts/script.json').read_text())['sections'];cuts={x['start_frame'] for x in rows};unexpected=[{'frame':i,'difference':m} for i,m in enumerate(motion) if m>24 and all(abs(i-c)>1 for c in cuts)]
result={'duration_seconds':float(probe['format']['duration']),'frames':2700,'resolution':[1920,1080],'fps':'30/1','audio_codec':au['codec_name'],'channels':au['channels'],'decode_errors':0,'black_frames':black,'all_frames_analyzed':len(means),'minimum_mean_luma':min(means),'unexpected_large_frame_differences':unexpected,'note':'Global frame differences can locate anomalies but do not prove semantic smoothness. Text/geometry were also inspected in rendered keyframes. No human listening claimed.','bytes':v.stat().st_size,'sha256':hashlib.sha256(v.read_bytes()).hexdigest()}
(R/'artifacts/technical-review.json').write_text(json.dumps(result,indent=2));(R/'artifacts/frame-metrics.json').write_text(json.dumps({'mean_luma':means,'frame_differences':motion}))
print(json.dumps(result,ensure_ascii=False,indent=2))
