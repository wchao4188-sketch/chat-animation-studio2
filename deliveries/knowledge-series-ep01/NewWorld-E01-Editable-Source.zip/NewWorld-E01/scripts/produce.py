from pathlib import Path
import sys,json,subprocess,time,hashlib
R=Path(__file__).resolve().parents[1];sys.path.insert(0,'/workspace/-/knowledge-production-system')
from orchestrator.dispatch import Dispatcher,Request
D=Dispatcher(json.loads((R/'config.json').read_text()))
rows=json.loads((R/'artifacts/script.json').read_text())['sections']
composition={'render_runtime':'remotion','cuts':[{'id':x['id'],'in_seconds':x['start'],'out_seconds':x['end'],'type':'generated'} for x in rows],'audio':{'music':{'src':str(R/'public/audio/master.wav')}}}
(R/'artifacts/composition-preflight.json').write_text(json.dumps(composition,indent=2))
for req in [Request('validate_composition','timeline.validate',{'composition_path':str(R/'artifacts/composition-preflight.json'),'assets_root':str(R),'render_runtime':'remotion'},[str(R/'artifacts/composition-preflight.json'),str(R/'public/audio/master.wav')]),Request('validate_integer_timeline','timeline.frames',{'fps':30,'frames':2700,'clips':[{'id':x['id'],'start_frame':x['start_frame'],'end_frame':x['end_frame']} for x in rows]})]:
 r=D.run(req);assert r['success'],r
out=R/'output/NewWorld-E01-Support-90s.mp4'
if out.exists():raise RuntimeError('Final output already exists; use an explicit new version name instead of overwriting')
cmd=['node','node_modules/@remotion/cli/remotion-cli.js','render','src/index.tsx','Support',str(out),'--browser-executable=/usr/bin/chromium','--codec=h264','--crf=17','--pixel-format=yuv420p','--audio-codec=aac','--audio-bitrate=256k','--concurrency=4','--log=info']
(R/'artifacts/render-command.json').write_text(json.dumps({'command':cmd,'runtime':'Remotion 4.0.536','reason':'project-pinned existing dependency version; Open Montage reused for preflight, audio and sampling','start_time_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())},indent=2))
with (R/'artifacts/render.log').open('w') as log:subprocess.run(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=1800)
r=D.run(Request('probe_final','media.probe',{'input_path':str(out)},[str(out)],allow_fallback=True));assert r['success'],r
r=D.run(Request('sample_final','media.sample',{'input_path':str(out),'strategy':'timestamps','timestamps':[0,.6,2.5,5,8.5,13.2,17.5,20.8,25.5,29.5,34,38,40.2,44.5,49.8,52,57,62.5,65,69,73,76.5,79,83.5,85,89.966],'output_dir':str(R/'output/keyframes'),'format':'png'},[str(out)]));assert r['success'],r
(R/'artifacts/render-result.json').write_text(json.dumps({'output':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'renderer':'Remotion 4.0.536','completed_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())},indent=2))
print('RENDER COMPLETE',out,flush=True)
