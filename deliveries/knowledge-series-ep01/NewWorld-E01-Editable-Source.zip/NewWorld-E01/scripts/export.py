from pathlib import Path
import json,zipfile,hashlib,shutil
R=Path(__file__).resolve().parents[1];O=R/'output';D=Path('/workspace/knowledge-ep01-delivery/deliveries/knowledge-series-ep01');D.mkdir(parents=True,exist_ok=True)
t=json.loads((R/'artifacts/technical-review.json').read_text());browser=R/'artifacts/browser-playback.json';b=json.loads(browser.read_text()) if browser.exists() else None
report=f'''# 第一期实际制作与验收

片名：《你想帮忙，为什么越说越火？》

- 画面：1920×1080，16:9，30fps，2700帧，视频流90秒；MP4容器时长{t['duration_seconds']}秒（含AAC边界填充）。
- 无新增配音；使用用户已上传音乐的实际选段及本地合成音效。
- 字幕主标题90—125px、对话42—49px、解释43px、来源25px；重点文字用字重、字号和荧光黄／深绿区分，主要句有阅读停顿。
- 内容自身闭合：案例→可能的沟通错位→复述核实→询问支持偏好→根据回应调整→应用边界→总结。只制作本集。
- 原书依据：上传版本正文69—71、192—195页。去除原书90%比例及性别概括；方法是明确标注的延伸建议，案例为原创虚构。
- 画面为手写SVG矢量层次、路径与材质动画，没有将其称为三维光追或真实脑机制。

## 实际完成的检查

- Remotion4.0.536完整渲染成功；TypeScript类型检查通过。
- FFmpeg对完整视频和音轨解码，退出码0，无解码错误。
- 扫描全部2700帧，无接近黑场的帧；非计划切点未检测到异常全局大幅跳变。帧差指标不能代替审美判断。
- 从最终MP4实际抽取26帧，检查九段内容、开头揭示、路径形成、反馈分支及最终总结。另在Studio检查三个反馈状态的文字边界。
- 修正了预加载场景的SVG渐变ID冲突，修正信息点与贝塞尔曲线的坐标关系。
- 所有实际使用的中文字形均存在于内嵌字体子集中。
- 音乐与音效为立体声音轨；原始混音约−16.8 LUFS，真峰值约−4.1 dBFS。最终AAC响度检测日志随工程保留。
- BPM为算法候选：75、115.385、56.604等，不声称已由人耳确认重拍。事件时间、帧号及起音距离保留在music-rhythm.json。
- 未进行人耳试听，不将技术音轨检查冒充自然度或听感认证。

## 浏览器完整播放

{('Chromium实际播放至结尾，2700帧，丢帧0、损坏帧0，无播放错误；记录保留在工程中。' if b and b.get('completed') else '播放检查正在运行，记录完成后更新。')}

## 文件校验

MP4：{t['bytes']:,}字节。
SHA-256：`{t['sha256']}`。

## 工具与源码

Remotion、React、TypeScript沿用现有版本，无新增npm依赖。Open Montage实际参与素材探测、混音、合成预检、最终媒体探测与抽帧；动画使用独立的Remotion源码。工程ZIP不包含原书PDF或全文OCR。

已知边界：本片是情境化沟通建议，不是经过临床验证的干预；接收门与路径仅为视觉隐喻。没有效果、感情结果或普遍适用承诺。工程ZIP已通过CRC检查；解压后实际渲染第60帧，与原工程同帧PNG的SHA-256一致。跨机器重装尚未实测。
'''
(O/'Checks.md').write_text(report)
files=[]
for name in ['README.md','package.json','package-lock.json','tsconfig.json'] :files.append(R/name)
for folder in ['src','public','scripts']:
 files.extend(x for x in (R/folder).rglob('*') if x.is_file() and '__pycache__' not in x.parts)
for name in ['script.json','scene_plan.json','knowledge-distillation.md','decision_log.json','editorial-review.json','technical-review.json','browser-playback.json','music-rhythm.json','final-loudness.txt','full-decode.txt','render-command.json','ffprobe-final.json','layout-review.json','source-export-check.json']:
 if (R/'artifacts'/name).exists():files.append(R/'artifacts'/name)
z=O/'NewWorld-E01-Editable-Source.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as f:
 for x in sorted(set(files)):f.write(x,Path('NewWorld-E01')/x.relative_to(R))
 f.write(O/'Checks.md','NewWorld-E01/Checks.md')
with zipfile.ZipFile(z) as f:
 assert f.testzip() is None
 assert not any('ocr-full' in n or n.lower().endswith('.pdf') for n in f.namelist())
for name in ['NewWorld-E01-Support-90s.mp4','NewWorld-E01-Editable-Source.zip','Checks.md','Keyframes.pdf']:
 shutil.copy2(O/name,D/name)
manifest={x.name:{'bytes':x.stat().st_size,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in D.iterdir() if x.is_file() and x.name!='SHA256.json'}
(D/'SHA256.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(manifest,indent=2))
