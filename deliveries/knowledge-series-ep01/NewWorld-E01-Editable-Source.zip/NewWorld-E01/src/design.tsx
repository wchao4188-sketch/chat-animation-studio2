import React, {createContext,useContext,useId} from 'react';
const GradientPrefix=createContext('');
const ref=(name:string,prefix:string)=>`url(#${prefix}-${name})`; 
import {AbsoluteFill,Easing,interpolate,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import {loadFont} from '@remotion/fonts';
loadFont({family:'NW',url:staticFile('fonts/NotoSansSC-Regular.woff'),weight:'400'});
loadFont({family:'NW',url:staticFile('fonts/NotoSansSC-Bold.woff'),weight:'700'});
export const C={paper:'#e9edeb',ink:'#18221f',muted:'#5b6861',acid:'#d8fa52',green:'#37765c',line:'#a7b4ab',white:'#fafcf9',rose:'#b24b59'};
export const ease=Easing.bezier(.16,1,.3,1);
export const p=(f:number,a:number,b:number)=>interpolate(f,[a,b],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:ease});
export const smooth=(f:number,a:number,b:number)=>{const q=Math.max(0,Math.min(1,(f-a)/(b-a)));return q*q*(3-2*q)};
export const mix=(a:number,b:number,t:number)=>a+(b-a)*t;
export const Head:React.FC<{a:string;b?:string;dark?:boolean;size?:number;f:number;at?:number}>=({a,b,dark=false,size=94,f,at=0})=><div data-copy="headline" style={{position:'absolute',left:100,top:152,color:dark?C.white:C.ink,fontSize:size,fontWeight:700,lineHeight:1.26,letterSpacing:-3,whiteSpace:'pre',clipPath:`inset(0 0 ${100*(1-p(f,at,at+17))}% 0)`,translate:`0 ${28*(1-p(f,at,at+22))}px`}}>{a}{b&&<><br/><span style={{color:dark?C.acid:C.green}}>{b}</span></>}</div>;
export const Caption:React.FC<{children:React.ReactNode;dark?:boolean;f:number;at?:number}>=({children,dark,f,at=0})=><div data-copy="body" style={{position:'absolute',left:100,bottom:91,fontSize:43,lineHeight:1.4,fontWeight:400,color:dark?C.white:C.ink,opacity:p(f,at,at+14),translate:`0 ${14*(1-p(f,at,at+20))}px`,whiteSpace:'pre'}}>{children}</div>;
export const Badge:React.FC<{x:number;y:number;text:string;dark?:boolean;accent?:boolean}>=({x,y,text,dark,accent})=><g transform={`translate(${x} ${y})`}><rect x={0} y={-27} width={text.length*31+45} height={55} rx={27} fill={accent?C.acid:dark?'#2a3731':'#d8dfda'}/><text x={23} y={11} fill={accent?C.ink:dark?C.white:C.ink} fontSize={29} fontWeight={700}>{text}</text></g>;
export const Svg:React.FC<{children:React.ReactNode}>=({children})=>{const gid=useId().replace(/:/g,'_');return <GradientPrefix.Provider value={gid}><svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position:'absolute',inset:0,overflow:'hidden'}}><defs>
<linearGradient id={`${gid}-metal`} x1="0" y1="0" x2="1" y2="1"><stop stopColor="#fafff7"/><stop offset=".33" stopColor="#cbd6cf"/><stop offset=".6" stopColor="#879a8e"/><stop offset="1" stopColor="#ecf2ec"/></linearGradient>
<linearGradient id={`${gid}-rim`} x1="0" y1="0" x2="1" y2=".35"><stop stopColor="#081711"/><stop offset=".4" stopColor="#435e4e"/><stop offset=".85" stopColor="#13251b"/><stop offset="1" stopColor="#99aa90"/></linearGradient>
<linearGradient id={`${gid}-yellow`} x1="0" y1="0" x2="1" y2="1"><stop stopColor="#eeff95"/><stop offset=".55" stopColor={C.acid}/><stop offset="1" stopColor="#91b323"/></linearGradient>
<linearGradient id={`${gid}-glass`} x1="0" y1="0" x2="1" y2="1"><stop stopColor="#fff" stopOpacity=".78"/><stop offset=".5" stopColor="#a1b8a8" stopOpacity=".1"/><stop offset="1" stopColor="#fff" stopOpacity=".5"/></linearGradient>
<linearGradient id={`${gid}-beam`} x1="0" y1="0" x2="1" y2="0"><stop stopColor={C.acid} stopOpacity="0"/><stop offset=".65" stopColor={C.acid} stopOpacity=".38"/><stop offset="1" stopColor={C.acid} stopOpacity=".7"/></linearGradient>
<filter id={`${gid}-shadow`} x="-40%" y="-70%" width="200%" height="260%"><feDropShadow dx="5" dy="21" stdDeviation="17" floodColor="#13231a" floodOpacity=".2"/></filter>
</defs>{children}</svg></GradientPrefix.Provider>};
export const Lens:React.FC<{x:number;y:number;scale?:number;open?:number;dark?:boolean;label?:string}>=({x,y,scale=1,open=0,dark,label})=>{const gid=useContext(GradientPrefix);return <g transform={`translate(${x} ${y}) scale(${scale})`}>
<ellipse cx={12} cy={202} rx={170} ry={21} fill={dark?'#000':'#718275'} opacity={.14}/>
<ellipse cx={28} cy={0} rx={148} ry={194} fill={ref('rim',gid)}/>
<path d="M 0 -194 L28 -194 A148 194 0 0 1 28 194 L0 194Z" fill="#192c20"/>
<ellipse rx={148} ry={194} fill={ref('metal',gid)} stroke={dark?'#7d9282':'#eff7ee'} strokeWidth={2}/>
<ellipse rx={113} ry={151} fill={dark?'#12251a':'#344d3d'} stroke="#f1f8e9" strokeWidth={3}/>
<ellipse rx={96} ry={135} fill={ref('glass',gid)}/>
{Array.from({length:7},(_,i)=>{const a=i*Math.PI*2/7;const x1=Math.cos(a)*58*(1-open*.7),y1=Math.sin(a)*85*(1-open*.7);return <path key={i} d={`M${x1} ${y1} L${Math.cos(a+.2)*96} ${Math.sin(a+.2)*135} L${Math.cos(a+.8)*96} ${Math.sin(a+.8)*135}Z`} fill={i%2?'#a9b8a2':'#dce7cf'} opacity={.45}/>})}
<ellipse rx={mix(17,79,open)} ry={mix(23,112,open)} fill={dark?'#06110b':'#152c1d'} stroke={C.acid} strokeWidth={2}/>
<path d="M-67 -122 Q-107 -63 -80 4" stroke="#fff" strokeWidth={6} fill="none" opacity={.5}/>
{label&&<text x={0} y={258} fill={dark?C.white:C.ink} fontSize={34} textAnchor="middle" fontWeight={700}>{label}</text>}
</g>};
export const Packet:React.FC<{x:number;y:number;text:string;scale?:number;yellow?:boolean;opacity?:number;rotate?:number}>=({x,y,text,scale=1,yellow=false,opacity=1,rotate=0})=>{const gid=useContext(GradientPrefix);const w=text.length*42+72;return <g transform={`translate(${x} ${y}) rotate(${rotate}) scale(${scale})`} opacity={opacity}>
<path d={`M0 0 L${w} 0 L${w+15} 14 L15 14 Z`} fill={yellow?'#8fab25':'#aabbb0'} transform="translate(0 62)"/>
<path d={`M${w} 0 L${w+15} 14 V76 L${w} 62Z`} fill={yellow?'#7a9823':'#a2b1a6'}/>
<rect width={w} height={62} rx={10} fill={yellow?ref('yellow',gid):C.white} stroke={yellow?'#eaff81':'#a6b3a8'} strokeWidth={1.3}/>
<text x={36} y={45} fill={C.ink} fontSize={38} fontWeight={700}>{text}</text></g>};
export const Track:React.FC<{d:string;progress:number;accent?:boolean;wide?:boolean}>=({d,progress,accent,wide})=><><path d={d} fill="none" stroke={accent?C.acid:'#718479'} strokeWidth={wide?8:3} opacity={accent?1:.4} pathLength={1} strokeDasharray={1} strokeDashoffset={1-progress} strokeLinecap="round"/>{accent&&<path d={d} fill="none" stroke="#eaffab" strokeWidth={1.5} pathLength={1} strokeDasharray={1} strokeDashoffset={1-progress}/>}</>;
export const Wave:React.FC<{x:number;y:number;width?:number;phase:number;amplitude?:number;dark?:boolean}>=({x,y,width=460,phase,amplitude=1,dark=false})=>{let d='';for(let i=0;i<=90;i++){const q=i/90;const e=Math.sin(q*Math.PI)**.7;const yy=Math.sin(q*25-phase)*e*34*amplitude+Math.sin(q*59-phase*.6)*e*7*amplitude;d+=`${i?'L':'M'}${x+q*width} ${y+yy} `}return <path d={d} fill="none" stroke={dark?C.acid:C.green} strokeWidth={3.5} strokeLinecap="round"/>};
export const Frame:React.FC<{children:React.ReactNode;dark?:boolean;label:string;episode?:boolean}>=({children,dark=false,label})=>{const f=useCurrentFrame();const {fps}=useVideoConfig();return <AbsoluteFill style={{background:dark?'#101c17':C.paper,fontFamily:'NW',color:dark?C.white:C.ink,overflow:'hidden'}}>
<div style={{position:'absolute',inset:0,backgroundImage:dark?'radial-gradient(ellipse at 80% 70%,#2a403220,transparent 62%)':'radial-gradient(ellipse at 74% 66%,#fbfff9,transparent 64%)'}}/>
<div style={{position:'absolute',top:62,left:100,right:100,display:'flex',justifyContent:'space-between',alignItems:'center',fontSize:26,letterSpacing:3,color:dark?'#a9bcad':C.muted}}><b style={{letterSpacing:8}}>新世界</b><span>知识大赏　/　01　{label}</span></div>
{children}
<div style={{position:'absolute',left:100,right:100,bottom:43,height:1,background:dark?'#526653':'#a9b6ac'}}/>
<div style={{position:'absolute',left:100,bottom:12,fontSize:23,color:dark?'#a7b8aa':C.muted}}>沟通示意 · 非心理机制模型</div><div style={{position:'absolute',right:100,bottom:12,fontSize:23,color:dark?'#a7b8aa':C.muted}}>无配音 · 阅读重点文字</div>
</AbsoluteFill>};
