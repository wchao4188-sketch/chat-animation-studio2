import React from 'react';import{Series,useVideoConfig}from'remotion';import{Audio}from'@remotion/media';import{staticFile}from'remotion';
import{Hook}from'./scenes/Hook';import{Case}from'./scenes/Case';import{Mismatch}from'./scenes/Mismatch';import{Channels}from'./scenes/Channels';import{Reflect}from'./scenes/Reflect';import{Ask}from'./scenes/Ask';import{Adjust}from'./scenes/Adjust';import{Boundary}from'./scenes/Boundary';import{Close}from'./scenes/Close';
export const Film=()=>{const{fps}=useVideoConfig();return <><Series>
<Series.Sequence name="Hook" durationInFrames={5*fps} premountFor={fps}><Hook/></Series.Sequence>
<Series.Sequence name="Case" durationInFrames={12*fps} premountFor={fps}><Case/></Series.Sequence>
<Series.Sequence name="Mismatch" durationInFrames={11*fps} premountFor={fps}><Mismatch/></Series.Sequence>
<Series.Sequence name="Channels" durationInFrames={11*fps} premountFor={fps}><Channels/></Series.Sequence>
<Series.Sequence name="Reflect" durationInFrames={12*fps} premountFor={fps}><Reflect/></Series.Sequence>
<Series.Sequence name="Ask" durationInFrames={13*fps} premountFor={fps}><Ask/></Series.Sequence>
<Series.Sequence name="Adjust" durationInFrames={13*fps} premountFor={fps}><Adjust/></Series.Sequence>
<Series.Sequence name="Boundary" durationInFrames={7*fps} premountFor={fps}><Boundary/></Series.Sequence>
<Series.Sequence name="Close" durationInFrames={6*fps} premountFor={fps}><Close/></Series.Sequence>
</Series><Audio src={staticFile('audio/master.wav')} premountFor={fps}/></>};
