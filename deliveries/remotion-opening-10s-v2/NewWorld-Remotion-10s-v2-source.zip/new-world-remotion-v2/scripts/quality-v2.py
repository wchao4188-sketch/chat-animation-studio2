from pathlib import Path
import subprocess,json,hashlib,math,wave
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from scipy.signal import correlate
R=Path(__file__).resolve().parents[1];o=R/'output/v2';video=o/'NewWorld-Remotion-10s-v2.mp4'
p=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(video)]));(o/'probe.json').write_text(json.dumps(p,indent=2));v=next(x for x in p['streams'] if x['codec_type']=='video');a=next(x for x in p['streams'] if x['codec_type']=='audio');assert (v['width'],v['height'],v['r_frame_rate'],int(v['nb_frames']))==(2560,1440,'30/1',300)
proc=subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(video),'-f','null','-'],capture_output=True,text=True);assert proc.returncode==0;(o/'decode.log').write_text(proc.stderr)
# Decode every frame, compare frame-to-frame motion and view every tenth frame.
data=subprocess.check_output(['ffmpeg','-v','error','-i',str(video),'-an','-vf','scale=640:360','-pix_fmt','rgb24','-f','rawvideo','-']);arr=np.frombuffer(data,np.uint8).reshape(-1,360,640,3);assert len(arr)==300
motion=np.abs(np.diff(arr.astype(np.int16),axis=0)).mean(axis=(1,2,3));(o/'motion.json').write_text(json.dumps({'frame_mean_absolute_differences':motion.tolist(),'max':float(motion.max()),'median':float(np.median(motion))},indent=2))
font_path=Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc');font=ImageFont.truetype(str(font_path),21) if font_path.exists() else ImageFont.load_default(size=21)
# 60 samples cover the full 10 seconds at 5-frame intervals, plus the final frame.
indices=list(range(0,300,5))+[299];folder=o/'review';folder.mkdir(exist_ok=True)
for page in range(math.ceil(len(indices)/12)):
 canvas=Image.new('RGB',(1920,1560),'#e9e2d4');d=ImageDraw.Draw(canvas)
 for j,n in enumerate(indices[page*12:(page+1)*12]):
  x=j%3*640;y=j//3*390;canvas.paste(Image.fromarray(arr[n]),(x,y));d.text((x+12,y+362),f'{n:03} / {n/30:.3f}s',font=font,fill='#211e1a')
 canvas.save(folder/f'{page+1:02}.jpg',quality=92)
# Audio presence and timeline alignment, independently decoded from the actual MP4.
source=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(R/'public/music-opening.wav'),'-ac','1','-ar','16000','-f','f32le','-']),np.float32)
actual=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(video),'-vn','-ac','1','-ar','16000','-f','f32le','-']),np.float32)
n=min(len(source),len(actual));corr=float(np.corrcoef(source[:n],actual[:n])[0,1]);c=correlate(actual,source,method='fft');lag=int(c.argmax()-(len(source)-1));assert corr>.98 and abs(lag)<800
r=subprocess.run(['ffmpeg','-hide_banner','-i',str(video),'-af','ebur128=peak=true','-vn','-f','null','-'],capture_output=True,text=True);assert r.returncode==0;(o/'audio-check.log').write_text(r.stderr)
prior=json.loads((R/'prior-artifacts.sha256.json').read_text());prior_available=all((R.parent/k).is_file() for k in prior)
if prior_available:assert all(hashlib.sha256((R.parent/k).read_bytes()).hexdigest()==sha for k,sha in prior.items())
pres=json.loads((o/'v1-preservation.json').read_text());assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==sha for k,sha in pres.items())
import re
rows=[json.loads(m) for m in re.findall(r'V2_GEOMETRY (\{[^\n]+\})',(o/'render.log').read_text())]
frames={row['frame'] for row in rows};assert frames==set(range(300)),len(frames)
geometry={'frames_checked':len(frames),'max_port_error_px':max(x['maxPortError'] for x in rows),'max_tip_error_px':max(x['maxTipError'] for x in rows)}
assert max(geometry['max_port_error_px'],geometry['max_tip_error_px'])<.25
q={'geometry_browser_measurements':geometry,'v1_files_unchanged':True,'final_hold_decoded_max_mean_difference':float(motion[249:].max()),'resolution':[2560,1440],'fps':30,'video_frames':300,'duration':p['format']['duration'],'bytes':video.stat().st_size,'sha256':hashlib.sha256(video.read_bytes()).hexdigest(),'audio_codec':a['codec_name'],'audio_sample_rate':a['sample_rate'],'full_decode_exit_code':proc.returncode,'all_frames_decoded':len(arr),'visual_review_samples':len(indices),'music_waveform_correlation':corr,'music_lag_ms':lag/16,'prior_artifacts_unchanged':True if prior_available else None,'added_narration':False,'human_audio_listening':False};(o/'quality.json').write_text(json.dumps(q,indent=2));print(json.dumps(q,indent=2))
