#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
npx remotion render src/index.tsx NewWorldKnowledge output/NewWorld-Knowledge-2K30.mp4 --browser-executable=/usr/bin/chromium --concurrency=3 --codec=h264 --crf=17 --pixel-format=yuv420p
