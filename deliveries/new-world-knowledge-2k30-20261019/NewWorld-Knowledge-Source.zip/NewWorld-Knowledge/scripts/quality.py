from pathlib import Path
import subprocess,json,hashlib,math,re
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from fontTools.ttLib import TTFont
R=Path(__file__).resolve().parents[1];o=R/'output';v=o/'NewWorld-Knowledge-2K30.mp4';cfg=json.loads((R/'src/settings.json').read_text());N=cfg['frames'];duration=cfg['duration']
p=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(v)]));s=next(x for x in p['streams'] if x['codec_type']=='video');a=next(x for x in p['streams'] if x['codec_type']=='audio');assert(s['width'],s['height'],s['r_frame_rate'],int(s['nb_frames']))==(2560,1440,'30/1',N);assert abs(float(s['duration'])-duration)<.005;(o/'probe.json').write_text(json.dumps(p,indent=2));print('probe passed',flush=True)
r=subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(v),'-f','null','-'],capture_output=True,text=True);assert r.returncode==0;(o/'decode.log').write_text(r.stderr);print('full strict decode passed',flush=True)
rows=json.loads((R/'src/timeline.json').read_text());old=json.loads((R.parent/'assets/timeline.json').read_text()) if (R.parent/'assets/timeline.json').exists() else json.loads((R/'assets/original-timeline.json').read_text());assert [x['text'] for x in rows]==[x['text'] for x in old]
idx=set(range(0,N,15))|{N-1}
# Denser actual video samples through subject moves, photo lift, branch growth and boundary.
for start,end in [(3.5,8.3),(8.3,9.8),(18.4,20.4),(31.2,34),(37.3,40),(55.3,56.8),(66.3,67.4),(74.1,75.6),(77,79.5),(91.5,93.2),(100.6,102.2),(115.1,116.5),(124.6,126.4)]:idx.update(range(round(start*30),round(end*30)+1,4))
proc=subprocess.Popen(['ffmpeg','-v','error','-i',str(v),'-an','-vf','scale=480:270','-pix_fmt','rgb24','-f','rawvideo','-'],stdout=subprocess.PIPE);frames={};last=None;diff=[];luma=[];n=0
while True:
 b=proc.stdout.read(480*270*3)
 if not b:break
 assert len(b)==480*270*3;x=np.frombuffer(b,np.uint8).reshape(270,480,3);luma.append(float(x.mean()))
 if last is not None:diff.append(float(np.abs(x.astype(np.int16)-last).mean()))
 if n in idx:frames[n]=Image.fromarray(x.copy())
 last=x.astype(np.int16);n+=1
assert proc.wait()==0 and n==N and min(luma)>6 and max(luma)<240
review=o/'review-final';review.mkdir(exist_ok=True);font=ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',20);images=[];indices=sorted(frames)
for k in range(math.ceil(len(indices)/16)):
 page=Image.new('RGB',(1920,1216),'#34373c');d=ImageDraw.Draw(page)
 for j,f in enumerate(indices[k*16:(k+1)*16]):
  x=j%4*480;y=j//4*304;page.paste(frames[f],(x,y));d.text((x+12,y+274),f'{f:04} / {f/30:.2f}s',font=font,fill='#e5e8ed')
 page.save(review/f'{k+1:02}.jpg',quality=90);images.append(page)
images[0].save(o/'NewWorld-Knowledge-Keyframes.pdf',save_all=True,append_images=images[1:],resolution=130)
(o/'motion.json').write_text(json.dumps({'frames':n,'frame_mean_changes':diff,'minimum_frame_mean_luma':min(luma),'maximum_frame_mean_change':max(diff),'largest_frame_changes':sorted(enumerate(diff),key=lambda x:x[1],reverse=True)[:20]},indent=2));print('all frame scan passed; overview',len(indices),len(images),flush=True)
def sound(path):return np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-vn','-ac','1','-ar','16000','-f','f32le','-']),np.float32)
x=sound(v);y=sound(R/'public/audio/master.m4a');m=min(len(x),len(y));corr=float(np.corrcoef(x[:m],y[:m])[0,1]);assert corr>.99
r=subprocess.run(['ffmpeg','-hide_banner','-i',str(v),'-af','ebur128=peak=true,silencedetect=noise=-60dB:d=0.25','-vn','-f','null','-'],capture_output=True,text=True);assert r.returncode==0;(o/'audio-check.log').write_text(r.stderr);print(r.stderr[-650:],flush=True)
cn={ord(c) for c in ''.join(x.read_text() for x in (R/'src').glob('*') if x.suffix in {'.tsx','.ts','.json'}) if '\u4e00'<=c<='\u9fff'}
for name in ['FilmSans','FilmSerif']:assert not cn-set(TTFont(R/f'public/fonts/{name}.woff').getBestCmap())
assert all(a['end']<b['start'] for a,b in zip(rows,rows[1:]));assert rows[-1]['end']+5.4<duration
preservation_verified=False
if (o/'preserved-before.json').exists():
 for prev in json.loads((o/'preserved-before.json').read_text()):assert hashlib.sha256(Path(prev['path']).read_bytes()).hexdigest()==prev['sha256']
 preservation_verified=True
q={'title':'新世界｜从答案到线索','duration_seconds':duration,'resolution':[2560,1440],'aspect_ratio':'16:9','fps':30,'frames':N,'bytes':v.stat().st_size,'sha256':hashlib.sha256(v.read_bytes()).hexdigest(),'strict_decode_exit_code':0,'decoded_frames':n,'overview_samples':len(indices),'overview_pages':len(images),'minimum_frame_mean_luma':min(luma),'maximum_frame_mean_luma':max(luma),'maximum_frame_mean_change':max(diff),'audio_codec':a['codec_name'],'audio_sample_rate':a['sample_rate'],'audio_master_correlation':corr,'narration_overlap':False,'original_48_paragraphs_and_order_preserved':True,'font_chinese_glyph_coverage':True,'music':'User uploaded mmexport1792300994359.mp3, same audio, first 140.8667 seconds','narration':'Original takes with pitch-preserving variable tempo; line 04 reread with the same words and same duration','human_audio_listening':False,'old_artifacts_sha256_unchanged':preservation_verified,'full_render_connector_assertion_limit_pixels':.2};(o/'quality.json').write_text(json.dumps(q,ensure_ascii=False,indent=2));print(json.dumps(q,ensure_ascii=False,indent=2),flush=True)
