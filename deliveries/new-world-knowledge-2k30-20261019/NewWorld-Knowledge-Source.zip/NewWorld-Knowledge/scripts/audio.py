from pathlib import Path
import subprocess,json,wave,math,hashlib,shutil
import numpy as np
from scipy.signal import find_peaks,fftconvolve
R=Path(__file__).resolve().parents[1];A=R/'public/audio';rows=json.loads((R/'assets/original-timeline.json').read_text());cursor=.15;sr=48000
important={0,12,24,34,35,42};new=[]
for row in rows:
 i=row['id'];speed=1.30 if i in important else 1.35 if i==27 else 1.55
 dst=A/f'voice-{i:02}.wav';subprocess.run(['ffmpeg','-v','error','-y','-i',str(R/f'assets/original-voice/voice_{i:02}.wav'),'-af',f'atempo={speed},highpass=f=75','-ar',str(sr),'-ac','1',str(dst)],check=True)
 retake=R/f'assets/retakes/voice-{i:02}.wav'
 if retake.exists():shutil.copy(retake,dst)
 with wave.open(str(dst)) as w:duration=w.getnframes()/sr
 startframe=math.ceil(cursor*30);start=startframe/30;end=start+duration;gap=.42 if i in {0,7,12,22,24,27,31,34,35,40,42,46} else .12
 new.append({'id':i,'text':row['text'],'start':start,'duration':duration,'end':end,'speed':speed,'frame':startframe});cursor=end+gap
N=math.ceil((new[-1]['end']+5.5)*30);duration=N/30;assert duration<150
(R/'src/timeline.json').write_text(json.dumps(new,ensure_ascii=False,indent=2));(R/'src/settings.json').write_text(json.dumps({'frames':N,'fps':30,'width':2560,'height':1440,'duration':duration}));print('TIMELINE',duration,N,flush=True)
music=R/'public/audio/user-music-source.m4a';assert music.exists()
subprocess.run(['ffmpeg','-v','error','-y','-i',str(music),'-t',str(duration),'-vn','-ac','2','-ar',str(sr),str(A/'music-selected.wav')],check=True)
x=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(music),'-t',str(duration),'-vn','-ac','1','-ar','22050','-f','f32le','-']),np.float32)
win=1024;hop=256;spec=np.abs(np.fft.rfft(np.lib.stride_tricks.sliding_window_view(x,win)[::hop]*np.hanning(win)));flux=np.maximum(np.diff(np.log1p(spec),axis=0),0).sum(axis=1);flux=(flux-flux.mean())/(flux.std()+1e-8);peaks,_=find_peaks(flux,prominence=1.45,distance=int(.32*22050/hop));times=(peaks*hop+win/2)/22050;ac=fftconvolve(flux,flux[::-1],mode='full')[len(flux)-1:];lags=np.arange(int(22050/hop*60/145),int(22050/hop*60/65));cand=[]
for k in sorted(lags,key=lambda k:ac[k],reverse=True):
 bpm=60*22050/hop/k
 if all(abs(bpm-v['bpm'])>4 for v in cand):cand.append({'bpm':float(bpm),'score':float(ac[k]/ac[0])})
 if len(cand)==3:break
analysis={'source_sha256':hashlib.sha256(music.read_bytes()).hexdigest(),'original_upload_sha256':'db48cd3ab748abce4a643dae03e1366602eb95c7826ee32268a5c49331839eb2','selected_seconds':[0,duration],'bpm_candidates':cand,'method':'log-spectral flux, autocorrelation, local energy peaks. Candidate tempos and accents; bar downbeats are not confirmed.','accents':[{'time':round(float(t),4),'frame':round(float(t)*30),'strength':round(float(flux[k]),3)} for t,k in zip(times,peaks)],'energy_1s_rms':[float(np.sqrt(np.mean(x[k:k+22050]**2))) for k in range(0,len(x),22050)]};(R/'output/music-analysis.json').write_text(json.dumps(analysis,ensure_ascii=False,indent=2))
def event(i,delay=0):
 target=new[i]['start']+delay;j=int(np.argmin(abs(times-target)))
 return round((float(times[j]) if abs(times[j]-target)<=.14 else target)*30)/30
E={str(i):event(i) for i in range(48)};(R/'src/events.json').write_text(json.dumps(E,indent=2))
n=N*1600;voice=np.zeros(n,np.float32);active=np.zeros(n,np.float32)
for row in new:
 with wave.open(str(A/f"voice-{row['id']:02}.wav")) as w:v=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32)/32768
 j=row['frame']*1600;voice[j:j+len(v)]+=v;active[max(0,j-6000):min(n,j+len(v)+6000)]=1
# Smooth sidechain envelope without introducing abrupt steps.
k=np.ones(12001,np.float32)/12001;duck=fftconvolve(active,k,mode='same');voice*=.18/max(np.sqrt(np.mean(voice[active>.5]**2)),1e-6)
with wave.open(str(A/'music-selected.wav')) as w:m=np.frombuffer(w.readframes(w.getnframes()),'<i2').reshape(-1,2).astype(np.float32)/32768
m=m[:n];m=np.pad(m,((0,n-len(m)),(0,0)));gain=.060/(np.sqrt(np.mean(m**2))+1e-8);env=(1-.77*duck)
time=np.arange(n)/sr
# Reserve a quieter span around the explicit logical boundary.
b=new[34]['start'];boundary=1-.42*np.exp(-((time-(b+1))/2.0)**4);env*=boundary
m*=gain*env[:,None];sfx=np.zeros((n,2),np.float32);rng=np.random.default_rng(4188)
for i,offset,kind in [(1,.75,'connection'),(3,.42,'message'),(4,.35,'message'),(5,.55,'message'),(14,1.0,'reveal'),(24,1.1,'connection'),(28,.7,'connection'),(29,.9,'connection'),(37,.75,'message'),(38,.75,'message'),(39,.75,'message'),(46,.4,'message')]:
 at=event(i)+offset;l=int(sr*(.13 if kind!='reveal' else .34));z=np.arange(l)/sr
 if kind=='reveal':s=rng.normal(0,1,l)*np.sin(np.pi*np.arange(l)/l)**2*.009
 else:s=(np.sin(2*np.pi*(460 if kind=='connection' else 680)*z)+.25*np.sin(2*np.pi*1140*z))*np.exp(-z*40)*.022
 j=round(at*sr);sfx[j:j+l,0]+=s;sfx[j:j+l,1]+=s
mix=voice[:,None]+m+sfx;fade=np.minimum(1,time/.15)*np.minimum(1,(duration-time)/1.2);mix*=fade[:,None];peak=float(abs(mix).max());mix*=min(1,.88/(peak+1e-8))
for name,s in [('narration.wav',voice),('music-ducked.wav',m),('sfx.wav',sfx),('master.wav',mix)]:
 with wave.open(str(A/name),'wb') as w:w.setparams((1 if s.ndim==1 else 2,2,sr,0,'NONE','not compressed'));w.writeframes((np.clip(s,-1,1)*32767).astype('<i2').tobytes())
subprocess.run(['ffmpeg','-v','error','-y','-i',str(A/'master.wav'),'-c:a','aac','-b:a','192k',str(A/'master.m4a')],check=True)
(R/'output/audio-provenance.json').write_text(json.dumps({'music_sha256':analysis['source_sha256'],'source_narration':'Original voice files; line 04 is a same-word Melo reread to address ambiguous short-phrase recognition; no new spoken words','text_order_matches_original':all(a['text']==b['text'] for a,b in zip(rows,new)),'tempo_changes':[{'id':x['id'],'speed':x['speed']} for x in new],'music_effect':'continuous source audio from 0s, smooth ducking, boundary dip, final fade','sfx':'locally synthesized, sparse message/connection/reveal accents','human_audio_listening':False},ensure_ascii=False,indent=2));print(cand,flush=True)
