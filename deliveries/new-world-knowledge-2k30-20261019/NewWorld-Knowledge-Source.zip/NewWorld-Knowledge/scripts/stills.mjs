import {bundle} from '@remotion/bundler';
import {openBrowser,selectComposition,renderStill} from '@remotion/renderer';
import fs from 'node:fs/promises';
const url=await bundle({entryPoint:'src/index.tsx'});const b=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium',logLevel:'error'});
try{const c=await selectComposition({serveUrl:url,id:'NewWorldKnowledge',puppeteerInstance:b});
const times=[0,2.5,5.5,7.5,9.5,10.6,12.7,15.5,17.5,18.7,20.2,22.2,27.5,31.3,31.9,32.5,33.3,36.5,38.8,41.9,46.8,49.5,52.5,55.5,58.8,61.5,66.8,69.8,73,74.4,75.3,78.2,80.5,83.5,87.5,91.6,92.3,93.5,94.5,98.5,101.1,102.3,105,107.3,110,113.5,115.4,116.3,120,123.5,126,129.5,133,137,140.8];
for(let i=0;i<times.length;i++){await renderStill({serveUrl:url,composition:c,puppeteerInstance:b,frame:Math.round(times[i]*30),output:`output/review/still-${String(i).padStart(2,'0')}.jpg`,imageFormat:'jpeg',scale:.5,jpegQuality:88});console.log(i,times[i]);}
await fs.writeFile('output/review/times.json',JSON.stringify(times));}finally{await b.close({silent:true})}
