from pathlib import Path
import zipfile,json,hashlib
R=Path(__file__).resolve().parents[1];o=R/'output';dst=o/'NewWorld-Knowledge-Source.zip';items=[]
for directory in ['src','scripts','assets','licenses','public/fonts']:
 items.extend(p for p in (R/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name not in {'assemble.py','assemble-final.py'})
items += [p for p in (R/'public/audio').glob('voice-*.wav')]
items += [R/'public/audio/master.m4a',R/'public/audio/user-music-source.m4a']
items += [R/x for x in ['package.json','package-lock.json','tsconfig.json','.gitignore','README.md','原文.md','参考对齐与边界.md','requirements-tools.txt']]
for name in ['验收记录.md','quality.json','music-analysis.json','audio-provenance.json','voice-asr.json','voice-context-asr.json','frame-cues.json','caption-equivalence.json','source-smoke.json','music-extraction-check.json','playback-check.json','NewWorld-Knowledge.srt','phone-motion-check.json','preservation-check.json']:
 if (o/name).exists():items.append(o/name)
with zipfile.ZipFile(dst,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(set(items)):z.write(p,'NewWorld-Knowledge/'+str(p.relative_to(R)))
with zipfile.ZipFile(dst) as z:assert z.testzip() is None;assert not any('/node_modules/' in n for n in z.namelist());assert 'NewWorld-Knowledge/src/Film.tsx' in z.namelist();assert 'NewWorld-Knowledge/public/audio/master.m4a' in z.namelist()
print({'bytes':dst.stat().st_size,'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'files':len(items)},flush=True)
