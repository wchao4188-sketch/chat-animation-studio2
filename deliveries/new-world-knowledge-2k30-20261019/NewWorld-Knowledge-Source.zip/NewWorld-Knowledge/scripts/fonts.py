from pathlib import Path
from fontTools import subset
from fontTools.ttLib import TTFont
R=Path(__file__).resolve().parents[1];text=''.join(p.read_text() for p in (R/'src').glob('*') if p.suffix in {'.tsx','.ts','.json'})+'0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz → ≠？：“”'
for name,file in [('FilmSans','NotoSansCJK-Regular.ttc'),('FilmSerif','NotoSerifCJK-Bold.ttc')]:
 font=TTFont('/usr/share/fonts/opentype/noto/'+file,fontNumber=2);opt=subset.Options();opt.flavor='woff';s=subset.Subsetter(options=opt);s.populate(text=text);s.subset(font);font.flavor='woff';font.save(R/f'public/fonts/{name}.woff')
