from pathlib import Path
import sherpa_onnx,numpy as np,json,subprocess,re,difflib,argparse
R=Path(__file__).resolve().parents[1];parser=argparse.ArgumentParser();parser.add_argument('--model-dir',default=str(R.parent/'assets/models/sherpa-onnx-paraformer-zh-small-2024-03-09'));p=Path(parser.parse_args().model_dir)
a=sherpa_onnx.OfflineRecognizer.from_paraformer(paraformer=str(p/'model.int8.onnx'),tokens=str(p/'tokens.txt'),num_threads=1);rows=json.loads((R/'src/timeline.json').read_text());out=[]
for row in rows:
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(R/f"public/audio/voice-{row['id']:02}.wav"),'-ar','16000','-ac','1','-f','f32le','-']);s=a.create_stream();s.accept_waveform(16000,np.frombuffer(raw,np.float32));a.decode_stream(s);norm=lambda t:re.sub(r'[^\u4e00-\u9fff]','',t);ratio=difflib.SequenceMatcher(None,norm(row['text']),norm(s.result.text)).ratio();out.append({'id':row['id'],'script':row['text'],'asr':s.result.text,'similarity':ratio});print(out[-1],flush=True)
(R/'output/voice-asr.json').write_text(json.dumps({'method':'Automatic speech recognition only; not a human pronunciation check','mean_similarity':float(np.mean([x['similarity'] for x in out])),'rows':out},ensure_ascii=False,indent=2))
