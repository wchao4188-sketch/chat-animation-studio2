import fs from 'node:fs';
const rows=JSON.parse(fs.readFileSync('src/timeline.json','utf8'));
const out=[];
function chunksFor(row){const words=row.text.match(/[^，。？！：]+[，。？！：”]?/g)||[row.text];const chunks=[];let cur='';for(const w of words){if(cur.length+w.length>33&&cur){chunks.push(cur);cur=''}cur+=w}if(cur)chunks.push(cur);return chunks}
for(const row of rows){if(row.id===0)continue;const chunks=chunksFor(row),n=chunks.reduce((a,b)=>a+b.length,0);let sum=0;for(let i=0;i<chunks.length;i++){const text=chunks[i];out.push({text,startMs:(row.start+row.duration*sum/n)*1000,endMs:i===chunks.length-1?(row.end+.08)*1000:(row.start+row.duration*(sum+text.length)/n)*1000,timestampMs:null,confidence:null});sum+=text.length}}
fs.writeFileSync('src/captions.json',JSON.stringify(out,null,2));let checked=0;
for(let f=0;f<4226;f++){const t=f/30,row=rows.find(x=>t>=x.start&&t<x.end+.08);let old='';if(row&&row.id!==0){const chunks=chunksFor(row);let sum=0;const n=chunks.reduce((a,b)=>a+b.length,0);const u=Math.max(0,Math.min(1,(t-row.start)/row.duration))*n;for(const c of chunks){old=c;sum+=c.length;if(u<=sum)break}}
const current=out.find(x=>t*1000>=x.startMs&&t*1000<x.endMs)?.text||'';if(current!==old)throw Error(`Caption mismatch ${f}: ${old}/${current}`);checked++}
fs.writeFileSync('output/caption-equivalence.json',JSON.stringify({checkedFrames:checked,identicalToRenderedCaptionStrings:true,captions:out.length},null,2));console.log('Captions identical for all '+checked+' frames; JSON entries '+out.length);
