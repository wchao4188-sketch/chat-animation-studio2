import React from 'react';
import {Pose,P,css,mix,route,path,cubic,phase} from './motion';
export const C={paper:'#101114',ink:'#e8e9e9',soft:'#979ca4',orange:'#ed5155',gold:'#bcc3cd',cream:'#f0f2f3',green:'#96b5ae',line:'#555b65'};
export const T=({x,y,children,size=40,color=C.ink,anchor='start',serif=false,opacity=1}:{x:number;y:number;children:React.ReactNode;size?:number;color?:string;anchor?:'start'|'middle'|'end';serif?:boolean;opacity?:number})=><text data-readable="true" x={x} y={y} fontFamily={serif?'FilmSerif':'FilmSans'} fontSize={size} fill={color} textAnchor={anchor} opacity={opacity}>{children}</text>;
export const Avatar=({female=false,color=C.cream}:{female?:boolean;color?:string})=><g fill="none" stroke={color} strokeWidth="3.5" strokeLinecap="round"><path d="M-43 50C-43 2 43 2 43 50"/><circle cy="-16" r="24"/>{female?<path d="M-33 0C-57-77 60-83 34-1M-29-34Q-2-66 28-33"/>:<path d="M-22-27Q-8-51 22-30"/>}</g>;
export function Phone({p,id,label,female=false,children,muted=0}:{p:Pose;id:string;label:string;female?:boolean;children?:React.ReactNode;muted?:number}){return <g data-phone={id} transform={css(p)} opacity={1-muted}>
 <g filter="url(#phoneShadow)"><rect x="-172" y="-309" width="360" height="640" rx="48" fill="#26282d"/><rect x="-180" y="-320" width="360" height="640" rx="48" fill="url(#metal)"/><rect x="-174" y="-314" width="348" height="628" rx="44" fill="url(#screen)"/></g>
 <rect x="-162" y="-301" width="324" height="602" rx="34" fill="none" stroke="#747c88" strokeWidth=".8" opacity=".65"/>
 <rect x="-51" y="-301" width="102" height="13" rx="7" fill="#08090b"/>
 <path d="M-183-202v40M-183-141v61M183-158v80" stroke="#6a7380" strokeWidth="4"/>
 <g transform="translate(0 -191)"><circle r="65" stroke={female?C.gold:C.orange} fill={female?'#bcc3cd13':'#ed515513'} strokeWidth="1.5"/><Avatar female={female}/></g>
 <T x={0} y={-83} size={33} color={C.cream} anchor="middle" serif>{label}</T><path d="M-137-52H137" stroke="#595e67" strokeWidth="1"/>
 {children}
 <g opacity="0">{[-180,180].flatMap((x,side)=>[32,101,170,70,220].map((y,j)=><circle data-port={`${id}-${side===0?'left':'right'}-${j}`} key={`${side}-${j}`} cx={x} cy={y} r=".01"/>))}</g>
 <path d="M-36 292H36" stroke="#bfc6cf" strokeWidth="4" strokeLinecap="round"/>
 </g>}
export const Row=({y,text,p=1,color=C.orange,secondary=false}:{y:number;text:string;p?:number;color?:string;secondary?:boolean})=><g opacity={p*(secondary?.38:1)}><rect x="-139" y={y} width={278*p} height="52" rx="13" fill="#ffffff06" stroke={color} strokeWidth="1.5"/><g opacity={phase(p,.5,1)}><T x={0} y={y+34} size={23} color={C.cream} anchor="middle">{text}</T></g></g>;
export const Socket=({p,color=C.orange}:{p:P;color?:string})=><circle cx={p.x} cy={p.y} r="6" fill={color} stroke={C.paper} strokeWidth="2"/>;
export function Wire({a,b,p,color=C.orange,dashed=false,tip=false,width=4,source,target,bend=0}:{a:P;b:P;p:number;color?:string;dashed?:boolean;tip?:boolean;width?:number;source?:string;target?:string;bend?:number}){const base=route(a,b);const r=[base[0],{...base[1],y:base[1].y+bend},{...base[2],y:base[2].y+bend},base[3]] as const;const pt=cubic(r,p);const mask=React.useId().replace(/:/g,'');return <g data-wire="true">
 {dashed?<defs><mask id={mask} maskUnits="userSpaceOnUse" x="-1000" y="-1000" width="7000" height="5000"><path d={path(r)} fill="none" stroke="white" strokeWidth={width+12} pathLength="1" strokeDasharray="1" strokeDashoffset={1-p}/></mask></defs>:null}
 <path d={path(r)} stroke={C.paper} strokeWidth={width+5} fill="none" pathLength="1" strokeDasharray="1" strokeDashoffset={1-p}/>
 <path data-route="true" data-source={source} data-target={target} d={path(r)} stroke={color} strokeWidth={width} fill="none" pathLength="1" strokeDasharray={dashed?'0.012 0.011':'1'} strokeDashoffset={dashed?0:1-p} mask={dashed?`url(#${mask})`:undefined}/>
 <Socket p={a} color={color}/>{p>.99?<Socket p={b} color={color}/>:null}
 {tip&&p>0&&p<1?<circle cx={pt.x} cy={pt.y} r="7" fill={color}/>:null}
 </g>}
export function Tag({x,y,children,p=1,color=C.green,question=false,w=430}:{x:number;y:number;children:React.ReactNode;p?:number;color?:string;question?:boolean;w?:number}){return <g transform={`translate(${x} ${y})`} opacity={p}>
 <path d={`M${-w/2} 33H${-w/2+w*p}`} stroke={color} strokeWidth="2"/>
 <T x={0} y={7} size={43} color={color} anchor="middle">{children}</T>{question?<T x={0} y={69} size={23} color={C.soft} anchor="middle">待验证</T>:null}</g>}
export function Seaside({p,frame=true,opacity=1}:{p:Pose;frame?:boolean;opacity?:number}){return <g data-photo="true" transform={css(p)} opacity={opacity}>
 {frame?<rect x="-159" y="-104" width="318" height="215" rx="5" fill="#b9bec5" filter="url(#photoShadow)"/>:null}
 <svg x="-150" y="-95" width="300" height="190" viewBox="0 0 600 380"><defs><linearGradient id="sky" x2="0" y2="1"><stop stopColor="#a9bec4"/><stop offset="1" stopColor="#d5dfe0"/></linearGradient><linearGradient id="sea" x2="0" y2="1"><stop stopColor="#467d87"/><stop offset="1" stopColor="#91afb6"/></linearGradient><linearGradient id="sand" x2="0" y2="1"><stop stopColor="#b4b6b6"/><stop offset="1" stopColor="#909697"/></linearGradient></defs>
 <rect width="600" height="380" fill="url(#sky)"/><circle cx="430" cy="76" r="27" fill="#edf1ed"/>
 <path d="M0 152L70 139 132 146 185 132 242 151 318 144 382 150 461 132 535 146 600 138V210H0Z" fill="#859ca3" opacity=".5"/>
 <path d="M0 159C150 150 386 164 600 150V380H0Z" fill="url(#sea)"/>
 {Array.from({length:14},(_,i)=><path key={i} d={`M${(i*79)%120-35} ${176+i*9}q90 -3 165 0t195 1t290 -1`} fill="none" stroke={i%3?'#c7dbdf':'#6b9aa4'} opacity={.2+(i%4)*.06} strokeWidth={i>8?2:1}/>)}
 <path d="M-30 336C60 314 124 243 266 265S472 298 650 237V400H-30Z" fill="url(#sand)"/>
 <path d="M-30 325C60 303 124 233 266 255S472 288 650 227" fill="none" stroke="#e2e8e9" strokeWidth="7" opacity=".9"/>
 <path d="M-30 340C60 318 124 248 266 270S472 303 650 242" fill="none" stroke="#9cacae" strokeWidth="2"/>
 <path d="M483 345l48-23 52 9-13 49H467Z" fill="#6b777c"/><path d="M490 344l39-14 40 5M483 345l18 35" fill="none" stroke="#8e9a9f" strokeWidth="2"/>
 {Array.from({length:40},(_,i)=><circle key={i} cx={(i*113)%590} cy={326+(i*17)%52} r={.6+(i%3)*.2} fill="#656e73" opacity=".25"/>)}
 <path d="M78 63q8-7 16 0q8-7 16 0" stroke="#7f949d" strokeWidth="1.5" fill="none"/>
 </svg>
 </g>}
export const CameraIcon=({x,y,p=1}:{x:number;y:number;p?:number})=><g transform={`translate(${x} ${y})`} opacity={p} fill="none" stroke={C.orange} strokeWidth="4"><rect x="-68" y="-45" width="136" height="92" rx="15"/><path d="M-37-45l13-19h48l13 19"/><circle r="29"/><circle cx="46" cy="-24" r="4" fill={C.orange}/></g>;
export const Compass=({x,y,p=1}:{x:number;y:number;p?:number})=><g transform={`translate(${x} ${y})`} opacity={p} fill="none" stroke={C.green} strokeWidth="3"><circle r="64"/><path d="M-12 12L-28 35 10-12 29-36Z" fill={C.green+'33'}/><path d="M0-75v15M0 60v15M-75 0h15M60 0h15"/></g>;
