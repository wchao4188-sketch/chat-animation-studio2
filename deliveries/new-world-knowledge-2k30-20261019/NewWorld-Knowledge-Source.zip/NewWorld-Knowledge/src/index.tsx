import React from 'react';
import {Composition,registerRoot} from 'remotion';
import {Film} from './Film';
import settings from './settings.json';
const Root=()=> <Composition id="NewWorldKnowledge" component={Film} durationInFrames={settings.frames} width={2560} height={1440} fps={30}/>;
registerRoot(Root);
