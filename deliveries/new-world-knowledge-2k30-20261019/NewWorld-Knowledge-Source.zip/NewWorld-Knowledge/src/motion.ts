import rows from './timeline.json';
import events from './events.json';
export const S=(i:number)=>rows[i].start;
export const E=(i:number)=>(events as Record<string,number>)[String(i)];
export const mix=(a:number,b:number,p:number)=>a+(b-a)*p;
export const clamp=(x:number)=>Math.max(0,Math.min(1,x));
export const phase=(t:number,a:number,b:number)=>{const p=clamp((t-a)/(b-a));return p*p*p*(p*(p*6-15)+10)};
export type Pose={x:number;y:number;s:number;r:number};
export const lerp=(a:Pose,b:Pose,p:number):Pose=>({x:mix(a.x,b.x,p),y:mix(a.y,b.y,p),s:mix(a.s,b.s,p),r:mix(a.r,b.r,p)});
const pose=(x:number,y:number,s=1,r=0):Pose=>({x,y,s,r});
export const point=(p:Pose,x:number,y:number)=>({x:p.x+p.s*(x*Math.cos(p.r*Math.PI/180)-y*Math.sin(p.r*Math.PI/180)),y:p.y+p.s*(x*Math.sin(p.r*Math.PI/180)+y*Math.cos(p.r*Math.PI/180))});
export const css=(p:Pose)=>`translate(${p.x} ${p.y}) rotate(${p.r}) scale(${p.s})`;
export function rig(t:number){
 let girl=lerp(pose(1840,720,1.32,-7),pose(1280,700,1.03,0),phase(t,S(1)-.4,S(1)+1.4));
 let one=lerp(pose(-450,940,.85,-12),pose(540,780,.96,-6),phase(t,S(1),S(1)+1.5));
 let two=lerp(pose(3020,940,.85,12),pose(2020,780,.96,6),phase(t,S(1)+.6,S(1)+2.4));
 girl=lerp(girl,pose(1800,700,1.08,0),phase(t,S(2),S(2)+1));one=lerp(one,pose(710,700,1.08,0),phase(t,S(2),S(2)+1));two=lerp(two,pose(3020,850,.9,8),phase(t,S(2),S(2)+1));
 // Camera-like lateral reveal: keep the woman, make room for the second observer.
 girl=lerp(girl,pose(830,700,1.07,0),phase(t,S(8),S(8)+1.1));one=lerp(one,pose(-500,820,.95,-9),phase(t,S(8),S(8)+1.1));two=lerp(two,pose(1810,700,1.07,0),phase(t,S(8),S(8)+1.1));
 girl=lerp(girl,pose(445,700,1.06,0),phase(t,S(14),S(14)+1.3));two=lerp(two,pose(2950,700,.95,7),phase(t,S(14),S(14)+1.3));
 girl=lerp(girl,pose(410,700,1.03,0),phase(t,S(23),S(23)+1));
 girl=lerp(girl,pose(1280,710,.98,0),phase(t,S(28),S(28)+1.05));
 girl=lerp(girl,pose(1960,710,.9,0),phase(t,S(33),S(33)+1.15));if(t>=S(33))two=lerp(pose(-450,850,.8,-7),pose(600,710,.9,0),phase(t,S(33),S(33)+1.15));
 girl=lerp(girl,pose(1960,710,1.08,0),phase(t,S(36),S(36)+1.1));two=lerp(two,pose(600,710,1.08,0),phase(t,S(36),S(36)+1.1));
 girl=lerp(girl,pose(1280,700,1.02,0),phase(t,S(41),S(41)+1));two=lerp(two,pose(-500,820,.9,-5),phase(t,S(41),S(41)+1));
 girl=lerp(girl,pose(790,725,1.23,-3),phase(t,S(43),S(43)+1.3));
 const pin=point(girl,0,65);const embedded=pose(pin.x,pin.y,girl.s,girl.r);
 let photo=lerp(embedded,pose(1120,680,2.0,0),phase(t,S(14)+.6,S(14)+2.1));
 photo=lerp(photo,pose(1040,650,1.72,-2),phase(t,S(23),S(23)+1.1));
 photo=lerp(photo,pose(1280,735,1.68,0),phase(t,S(28),S(28)+1.05));
 photo=lerp(photo,embedded,phase(t,S(33),S(33)+1.15));
 return {girl,one,two,photo};
}
export type P={x:number;y:number};
export const route=(a:P,b:P)=>{const dx=b.x-a.x;return [a,{x:a.x+dx*.46,y:a.y},{x:b.x-dx*.46,y:b.y},b] as const};
export const path=(r:ReturnType<typeof route>)=>`M${r[0].x},${r[0].y}C${r[1].x},${r[1].y} ${r[2].x},${r[2].y} ${r[3].x},${r[3].y}`;
export const cubic=(r:ReturnType<typeof route>,u:number)=>{const q=1-u;return{x:q*q*q*r[0].x+3*q*q*u*r[1].x+3*q*u*u*r[2].x+u*u*u*r[3].x,y:q*q*q*r[0].y+3*q*q*u*r[1].y+3*q*u*u*r[2].y+u*u*u*r[3].y}};
