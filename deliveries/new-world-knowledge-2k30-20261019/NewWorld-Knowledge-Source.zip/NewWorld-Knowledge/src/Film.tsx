import React,{useLayoutEffect} from 'react';
import {AbsoluteFill,staticFile,useCurrentFrame,delayRender,continueRender,cancelRender} from 'remotion';
import {Audio} from '@remotion/media';
import {loadFont} from '@remotion/fonts';
import rows from './timeline.json';
import captionData from './captions.json';
type Caption={text:string;startMs:number;endMs:number;timestampMs:number|null;confidence:number|null;pageBreakAfter?:boolean};
const captions:Caption[]=captionData;
import {S,E,phase,mix,rig,point,Pose,clamp} from './motion';
import {C,T,Phone,Row,Wire,Tag,Seaside,CameraIcon,Compass} from './Objects';
const fontReady=delayRender('Bundled Noto CJK fonts');Promise.all([loadFont({family:'FilmSans',url:staticFile('fonts/FilmSans.woff'),weight:'400'}),loadFont({family:'FilmSerif',url:staticFile('fonts/FilmSerif.woff'),weight:'700'})]).then(()=>continueRender(fontReady)).catch(cancelRender);
const Head=({children,small}:{children:React.ReactNode;small?:string})=><><T x={1280} y={225} anchor="middle" size={76} serif>{children}</T>{small?<T x={1280} y={292} anchor="middle" size={28} color={C.soft}>{small}</T>:null}</>;
const at=(p:Pose,x:number,y:number)=>point(p,x,y);
function Subtitle({t}:{t:number}){const caption=captions.find(c=>t*1000>=c.startMs&&t*1000<c.endMs);if(!caption)return null;
 return <div data-subtitle="true" style={{position:'absolute',left:110,right:110,bottom:83,height:91,display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'FilmSans',fontSize:43,color:C.ink,whiteSpace:'nowrap',textShadow:'0 1px 0 #0008'}}>{caption.text}</div>}

function DeviceContent({t,role}:{t:number;role:'girl'|'one'|'two'}){
 if(role==='one')return <>{['你多大了？','哪里人？','平时喜欢干嘛？'].map((q,i)=><Row key={q} y={6+i*69} text={q} p={phase(t,E(3+i),E(3+i)+.42)} color={C.orange} secondary={t>S(7)}/>)}</>;
 if(role==='two')return <>{t<S(33)?<>{['观察信息','发现线索','等待验证'].map((q,i)=><Row key={q} y={6+i*69} text={q} color={C.green} p={phase(t,E(9)+i*.58,E(9)+i*.58+.55)}/>)}</>:<><Row y={35} text={t<S(36)?'了解对方':t<S(37)?'双向观察':t<S(39)?'接收信息':'发起话题'} color={C.green}/><path d="M-100 154H100M-100 173H60" stroke="#636b76" strokeWidth="2"/></>}</>;
 if(t>=S(43))return <g opacity={phase(t,S(43)+.2,S(43)+1)}><T x={0} y={15} color={C.cream} anchor="middle" size={28}>朋友圈</T><path d="M-110 43H110" stroke="#545c67"/><T x={0} y={105} color={C.gold} anchor="middle" size={27}>三天可见</T><T x={0} y={158} color="#abb1b8" anchor="middle" size={23}>暂无可见内容</T><rect x="-134" y="201" width="268" height="44" rx="10" fill="none" stroke={C.gold}/></g>;
 if(t>=S(36))return <><Row y={32} text={t<S(37)?'也了解你？':t<S(38)?'主动询问？':t<S(39)?'主动分享？':'回答话题'} color={C.gold}/><path d="M-100 154H100M-100 173H60" stroke="#636b76" strokeWidth="2"/></>;
 if(t>=S(14))return <><rect x="-150" y="-30" width="300" height="190" rx="4" fill="#bdc6d109" stroke="#657080" strokeWidth="1"/><g opacity={phase(t,S(14)+3,S(14)+3.5)}><circle cx="-116" cy="220" r="21" stroke={C.gold} fill="none"/><path d="M-121 229V212l14-3v16" stroke={C.cream} fill="none" strokeWidth="2"/><T x={-74} y={227} size={21} color={C.cream}>一首伤感的歌</T></g></>;
 const browse=phase(t,S(8)+.1,S(8)+.9);
 return <g><defs><clipPath id="girl-browse-screen"><rect x="-150" y="-15" width="300" height="260"/></clipPath></defs><g clipPath="url(#girl-browse-screen)">
 <g transform={`translate(${-320*browse} 0)`}>{['已回答','已回答','已回答'].map((q,i)=><Row key={i} y={6+i*69} text={q} color={C.gold} p={phase(t,E(6)+i*.18,E(6)+i*.18+.36)}/>)}</g>
 <g transform={`translate(${320*(1-browse)} 0)`}>{['朋友圈','可见信息','待观察'].map((q,i)=><Row key={q} y={6+i*69} text={q} color={C.gold}/>)}</g>
 </g></g>;
}
function Questioning({t}:{t:number}){const {girl,one}=rig(t);return <>
 <Head>{t<S(7)?'问题，一个接一个':'答案都收到了，然后呢？'}</Head>
 {[0,1,2].map(i=>{const a=at(one,180,32+i*69),b=at(girl,-180,32+i*69);const p=phase(t,E(3+i)+.17,E(3+i)+.72);return <g key={i} opacity={1-.84*phase(t,S(7),S(7)+.4)}><Wire a={a} b={b} p={p} color={C.orange} tip source={`one-right-${i}`} target={`girl-left-${i}`}/></g>})}
 {t>S(7)?<g opacity={phase(t,S(7),S(7)+.5)}><circle cx="1280" cy="625" r="67" fill={C.paper} stroke={C.line} strokeWidth="2"/><path d="M1280 578v49l28 13" stroke={C.orange} strokeWidth="4" fill="none"/><T x={1280} y={763} anchor="middle" size={35} color={C.orange}>半小时后</T><T x={1280} y={858} anchor="middle" size={59} serif>下一句？</T></g>:null}
 </>}
function SecondObserver({t}:{t:number}){const {girl,two}=rig(t);const p=phase(t,E(9),E(9)+1.1);return <>
 <Head>{t<S(12)?'还没开聊，先看到什么？':'一个收集答案，一个收集线索'}</Head>
 {[0,1,2].map(i=><Wire key={i} a={at(girl,180,32+i*69)} b={at(two,-180,32+i*69)} p={phase(t,E(9)+i*.6,E(9)+i*.6+.85)} color={C.green} tip source={`girl-right-${i}`} target={`two-left-${i}`}/>)}
 <g opacity={p}><T x={830} y={1130} anchor="middle" size={33} color={C.soft}>对方已经透露的信息</T><T x={1810} y={1130} anchor="middle" size={33} color={C.green}>可能展开的话题</T></g>
 </>}
function Hypotheses({t}:{t:number}){const {photo,girl}=rig(t);const edge=at(photo,159,0);const p=phase(t,S(14)+.5,S(14)+2.2);const caution=phase(t,S(18),S(18)+.6);const rethink=phase(t,S(22),S(22)+.55);return <>
 <Head small="同一份信息，可以支持不止一种解释">{t<S(18)?'一张照片，能说明什么？':t<S(22)?'“可能”，怎么变成了“肯定”？':'也可能，只是歌好听、朋友约着拍照'}</Head>
 <g opacity={p}><T x={1120} y={960} anchor="middle" size={33} color={C.soft}>海边照片 · 示意图</T></g>
 {['喜欢旅游？','喜欢大海？','最近心情不好？'].map((q,i)=><g key={q} opacity={1-.45*rethink}><Wire a={i===2?at(girl,180,220):edge} b={{x:1760,y:480+i*180}} p={phase(t,E(16)+i*.53,E(16)+i*.53+.8)} color={C.green} dashed bend={i===2?200:0} source={i===2?'girl-right-4':undefined}/><Tag x={2040} y={480+i*180} p={phase(t,E(16)+i*.53+.5,E(16)+i*.53+.95)} question>{q}</Tag></g>)}
 <g opacity={caution*(1-rethink)}><path d="M1690 995H2360" stroke={C.orange} strokeWidth="2"/><T x={2025} y={1065} anchor="middle" size={45} color={C.orange}>{t<S(20)?'未经验证，不急于下结论':t<S(21)?'“她刚失恋” → 未经验证':'“她喜欢到处玩” → 未经验证'}</T></g>
 <g opacity={rethink}><T x={1810} y={1060} anchor="middle" size={48} color={C.orange}>信息相同，解释仍未确定。</T></g>
 </>}
function Verify({t}:{t:number}){const {photo}=rig(t);const process=phase(t,S(23),S(23)+1.2);const q=phase(t,S(27),S(27)+.5);return <>
 <Head>{t<S(27)?'先观察，再判断，通过聊天验证':'把判断，变成一个可以回答的问题'}</Head>
 <g opacity={process}>{['观察','初步判断','聊天验证'].map((label,i)=><g key={label}>
 <T x={1430+i*390} y={445} anchor="middle" size={43} color={i===2?C.orange:C.green}>{label}</T><T x={1430+i*390} y={500} anchor="middle" size={24} color={C.soft}>{['看到了什么','存在什么可能','听她怎样回答'][i]}</T>
 {i<2?<Wire a={{x:1530+i*390,y:430}} b={{x:1690+i*390,y:430}} p={phase(t,E(24)+i*1.1,E(24)+i*1.1+.75)} color={C.green}/>:null}</g>)}</g>
 <Wire a={at(photo,159,25)} b={{x:1395,y:690}} p={phase(t,E(27)-.15,E(27)+.5)} color={C.orange} tip/>
 <g opacity={q}><path d="M1390 632Q1360 632 1360 662V983Q1360 1008 1390 1008H2370Q2400 1008 2400 978V662Q2400 632 2370 632Z" fill="#1a1d22" stroke={C.line} strokeWidth="2"/>
 <T x={1410} y={710} size={42}>你那几张海边照片拍得挺好看的，</T>
 <T x={1410} y={785} size={42}>我之前也想去海边待几天。</T>
 <T x={1410} y={875} size={44} color={C.orange}>你是比较喜欢大海，</T>
 <T x={1410} y={950} size={44} color={C.orange}>还是单纯喜欢拍照？</T></g>
 <g opacity={process*(1-phase(t,S(27)-.4,S(27)))}><T x={1870} y={790} size={89} anchor="middle" serif>不急着下结论</T><path d="M1510 840H2230" stroke={C.orange} strokeWidth="4" pathLength="1" strokeDasharray="1" strokeDashoffset={1-phase(t,S(24),S(24)+1)}/></g>
 <T x={photo.x} y={1020} anchor="middle" size={30} color={C.soft}>照片始终是起点，聊天用于验证。</T>
 </>}
function Branches({t}:{t:number}){const {photo}=rig(t);const a=phase(t,S(28)+1.05,S(28)+1.8),b=phase(t,E(29),E(29)+1.05),deep=phase(t,S(32),S(32)+.65);return <>
 <Head small="以下是条件分支，不是替她给出的回答">她怎样回答，话题就往哪里展开</Head>
 <Wire a={at(photo,-159,0)} b={{x:588,y:595}} p={a} color={C.orange}/><Wire a={at(photo,159,0)} b={{x:1996,y:595}} p={b} color={C.green}/>
 <g opacity={a}><T x={520} y={435} anchor="middle" size={44} color={C.orange}>如果她喜欢拍照</T><CameraIcon x={520} y={595}/><T x={520} y={765} anchor="middle" size={67} serif>摄影</T></g>
 <g opacity={b}><T x={2060} y={435} anchor="middle" size={44} color={C.green}>如果她喜欢大海</T><Compass x={2060} y={595}/>{['旅行','风景','环境偏好'].map((q,i)=><g key={q}><path d={`M2060 666V704H${1760+i*280}V770`} fill="none" stroke={C.green} strokeWidth="2" pathLength="1" strokeDasharray="1" strokeDashoffset={1-phase(t,E(29)+1.2+i*.4,E(29)+1.8+i*.4)}/><T x={1760+i*280} y={840} anchor="middle" size={38} color={C.green} opacity={phase(t,E(29)+1.7+i*.4,E(29)+2.1+i*.4)}>{q}</T></g>)}</g>
 <g opacity={deep}><path d="M900 1105H1660" stroke={C.gold} strokeWidth="2"/><T x={1280} y={1077} anchor="middle" size={37} color={C.soft}>随着聊天深入，逐步了解</T><T x={1280} y={1170} anchor="middle" size={45}>性格　·　生活习惯　·　恋爱观</T></g>
 </>}
function Boundary({t}:{t:number}){const p=phase(t,S(34)-.15,S(34)+.35);return <>
 <Head>但这里，有一条重要的逻辑边界</Head>
 <g opacity={p}><T x={1280} y={530} anchor="middle" size={100} serif>你了解她</T><T x={1280} y={735} anchor="middle" size={180} color={C.orange}>≠</T><T x={1280} y={900} anchor="middle" size={96} serif>{t<S(35)?'她就喜欢你':'你们就一定合适'}</T></g>
 <path d="M840 1030H1720" stroke={C.orange} strokeWidth="3" pathLength="1" strokeDasharray="1" strokeDashoffset={1-phase(t,S(34)+.5,S(34)+1.1)}/>
 <T x={1280} y={1130} anchor="middle" size={43} color={C.orange} opacity={p}>你了解她，不代表她就喜欢你。</T>
 </>}
function Reciprocity({t}:{t:number}){const {girl,two}=rig(t);const mode=t<S(38)?0:t<S(39)?1:2;const start=mode===0?E(37):mode===1?E(38):E(39);const p=phase(t,start+.1,start+.95);const a=mode===2?at(two,180,70):at(girl,-180,70),b=mode===2?at(girl,-180,70):at(two,180,70);const tipx=mix(a.x,b.x,p);return <>
 <Head small="信息的方向，不等于好感的分数">{t<S(37)?'也看看，她是否愿意了解你':mode===0?'她会主动问你的事情吗？':mode===1?'她会主动分享生活吗？':'还是，每次都由你发起？'}</Head>
 <g opacity={phase(t,S(37),S(37)+.5)}><Wire a={a} b={b} p={p} color={C.orange} tip source={mode===2?'two-right-3':'girl-left-3'} target={mode===2?'girl-left-3':'two-right-3'}/>{p>.98?<path d={`M${b.x+(mode===2?-18:18)} ${b.y-13}L${b.x} ${b.y}L${b.x+(mode===2?-18:18)} ${b.y+13}`} stroke={C.orange} strokeWidth="4" fill="none"/>:null}
 <T x={1280} y={680} anchor="middle" size={43} color={C.orange}>{mode===0?'她 → 关于你的问题':mode===1?'她 → 自己的生活':'你 → 话题　　她 → 回答'}</T>
 <T x={1280} y={1000} anchor="middle" size={34} color={C.soft}>观察发起与回应，结合情境判断。</T></g>
 {t>=S(40)?<T x={1280} y={1130} anchor="middle" size={41} color={C.green}>这些信息，同样需要结合具体情况。</T>:null}
 </>}
function Summary({t}:{t:number}){const {girl}=rig(t);const p=phase(t,S(41)+1,S(41)+1.4);return <>
 <Head>了解一个人，是持续验证的过程</Head>
 <g opacity={p}>{[{label:'观察',sub:'找到线索',x:560,y:590,a:at(girl,-180,10),b:{x:760,y:590}},{label:'聊天',sub:'验证判断',x:2000,y:590,a:at(girl,180,10),b:{x:1800,y:590}},{label:'相处',sub:'了解真实',x:1280,y:1110,a:at(girl,0,320),b:{x:1280,y:1050}}].map((n,i)=><g key={n.label}>
 <Wire a={n.a} b={n.b} p={phase(t,E(42)+i*1.55,E(42)+i*1.55+1)} color={i===1?C.orange:C.green}/><T x={n.x} y={n.y} anchor="middle" size={64} serif>{n.label}</T><T x={n.x} y={n.y+61} anchor="middle" size={34} color={C.soft}>{n.sub}</T></g>)}</g>
 </>}
function Ending({t}:{t:number}){const p=phase(t,S(43)+1.3,S(43)+1.7);return <>
 <Head>{t<S(47)?'最后，轮到你发第一句话':'你会怎么发？'}</Head>
 <g opacity={p}><T x={1260} y={490} size={59} serif>刚加了一位新朋友</T><T x={1260} y={595} size={43}>头像是自拍</T><T x={1260} y={680} size={43}>朋友圈三天可见</T><T x={1260} y={765} size={38} color={C.soft}>没有可见内容</T></g>
 <g opacity={phase(t,S(46),S(46)+.6)}><T x={1260} y={930} size={38} color={C.orange}>现在，你必须发第一句话。</T><rect x="1250" y="980" width="1000" height="115" rx="24" fill="#1a1d22" stroke={C.line} strokeWidth="2"/><path d="M1298 1011V1064" stroke={C.orange} strokeWidth="3"/><path d="M2150 1015l46 22-46 22 10-22Z" fill="none" stroke={C.line} strokeWidth="3"/></g>
 </>}
export function Film(){const f=useCurrentFrame();const t=f/30;const {girl,one,two,photo}=rig(t);const girlLabel=t>=S(43)?'新朋友':'女生';
 useLayoutEffect(()=>{
  for(const el of Array.from(document.querySelectorAll('text[data-readable]'))){const b=(el as SVGGraphicsElement).getBBox();if(!Number.isFinite(b.width))cancelRender(new Error('Nonfinite text at '+f));}
  let maxError=0;
  for(const el of Array.from(document.querySelectorAll('path[data-route][data-source]'))){
   const path=el as SVGPathElement;const m=path.getScreenCTM();if(!m)continue;
   for(const [key,len] of [['source',0],['target',path.getTotalLength()]] as const){const id=path.dataset[key];if(!id)continue;const port=document.querySelector(`[data-port="${id}"]`) as SVGCircleElement|null;if(!port)cancelRender(new Error('Missing port '+id));if(!port)continue;
    const n=port.getScreenCTM();if(!n)continue;const q=path.getPointAtLength(len),a=new DOMPoint(q.x,q.y).matrixTransform(m),b=new DOMPoint(port.cx.baseVal.value,port.cy.baseVal.value).matrixTransform(n);maxError=Math.max(maxError,Math.hypot(a.x-b.x,a.y-b.y));}
  }
  if(maxError>.2)cancelRender(new Error('Detached connector at frame '+f+': '+maxError));
  (window as unknown as {filmQA:unknown}).filmQA={frame:f,maxPortError:maxError};
 },[f]);
 const girlMuted=t>=S(33)&&t<S(36)?.45:0;
 let overlay:React.ReactNode;
 if(t<S(1))overlay=<g><T x={175} y={420} size={35} color={C.soft}>为什么会聊天的人</T><T x={175} y={570} size={108} serif>大多数的开场</T><T x={175} y={725} size={108} serif>不是询问信息？</T><path d="M175 790H1180" stroke={C.orange} strokeWidth="4" pathLength="1" strokeDasharray="1" strokeDashoffset={1-phase(t,.3,1.7)}/></g>;
 else if(t<S(2))overlay=<><Head>假如你是她，你会怎么选？</Head><Wire a={at(one,180,32)} b={at(girl,-180,32)} p={phase(t,E(1)+.8,E(1)+1.8)} color={C.orange} tip/><Wire a={at(girl,180,32)} b={at(two,-180,32)} p={phase(t,E(1)+1.9,E(1)+2.9)} color={C.green} tip/></>;
 else if(t<S(8))overlay=<Questioning t={t}/>;else if(t<S(14))overlay=<SecondObserver t={t}/>;else if(t<S(23))overlay=<Hypotheses t={t}/>;else if(t<S(28))overlay=<Verify t={t}/>;else if(t<S(33))overlay=<Branches t={t}/>;else if(t<S(36))overlay=<Boundary t={t}/>;else if(t<S(41))overlay=<Reciprocity t={t}/>;else if(t<S(43))overlay=<Summary t={t}/>;else overlay=<Ending t={t}/>;
 return <AbsoluteFill style={{background:C.paper,fontFamily:'FilmSans',overflow:'hidden'}}>
 <Audio name="Original narration, user music, restrained synchronized effects" src={staticFile('audio/master.m4a')}/>
 <svg width="2560" height="1440" viewBox="0 0 2560 1440">
 <defs><radialGradient id="paper" cx=".5" cy=".35" r=".8"><stop stopColor="#202227"/><stop offset="1" stopColor="#0b0c0f"/></radialGradient><linearGradient id="metal" x2="1" y2="1"><stop stopColor="#e2e5e8"/><stop offset=".35" stopColor="#747c88"/><stop offset=".75" stopColor="#c8cdd4"/><stop offset="1" stopColor="#56606d"/></linearGradient><linearGradient id="screen" x2=".4" y2="1"><stop stopColor="#292c32"/><stop offset="1" stopColor="#121418"/></linearGradient><filter id="phoneShadow" x="-60%" y="-50%" width="240%" height="220%"><feDropShadow dx="12" dy="26" stdDeviation="18" floodColor="#000000" floodOpacity=".20"/></filter><filter id="photoShadow" x="-30%" y="-30%" width="170%" height="190%"><feDropShadow dx="2" dy="11" stdDeviation="9" floodColor="#000000" floodOpacity=".17"/></filter><pattern id="grain" width="23" height="23" patternUnits="userSpaceOnUse"><circle cx="3" cy="4" r=".65" fill="#aab2bc" opacity=".13"/><circle cx="15" cy="19" r=".4" fill="#aab2bc" opacity=".1"/></pattern></defs>
 <rect width="2560" height="1440" fill="url(#paper)"/><rect width="2560" height="1440" fill="url(#grain)"/>
 <T x={100} y={90} size={24} color={C.soft}>新世界 / 从答案到线索</T>
 <path d="M-120 1190C640 1100 1770 1280 2700 1120" stroke="#41464f" strokeWidth="1" opacity=".7" fill="none"/>
 {[girl,one,two].map((p,i)=><ellipse key={i} cx={p.x} cy={p.y+330*p.s} rx={170*p.s} ry={20*p.s} fill="#000000" opacity=".09"/>)}
 <Phone id="one" p={one} label="男生 01"><DeviceContent t={t} role="one"/></Phone>
 <Phone id="two" p={two} label={t>=S(33)?'你':'男生 02'} muted={girlMuted}><DeviceContent t={t} role="two"/></Phone>
 <Phone id="girl" p={girl} label={girlLabel} female muted={girlMuted}><DeviceContent t={t} role="girl"/></Phone>
 {t>=S(14)&&t<S(43)?<Seaside p={photo} opacity={t>=S(36)?1-phase(t,S(36),S(36)+.7):1}/>:null}
 {overlay}
 <path d="M100 1377H2460" stroke="#3f454e" strokeWidth="1"/>
 </svg>
 <Subtitle t={t}/>
 </AbsoluteFill>
}
