from pathlib import Path
import json,zipfile,hashlib,shutil,re
R=Path(__file__).resolve().parents[1];O=R/'output';D=Path('/workspace/knowledge-ep02-delivery/deliveries/knowledge-series-ep02');D.mkdir(parents=True,exist_ok=True)
t=json.loads((R/'artifacts/technical-review.json').read_text());b=json.loads((R/'artifacts/browser-playback.json').read_text());sfile=R/'artifacts/source-export-check.json';s=json.loads(sfile.read_text()) if sfile.exists() else None
assert b['completed'] and not b['errors']
loud=(R/'artifacts/final-loudness.txt').read_text();L=re.findall(r'I:\s+(-?[\d.]+) LUFS',loud)[-1];P=re.findall(r'Peak:\s+(-?[\d.]+) dBFS',loud)[-1]
text=f'''# 第2条实际制作与验收

《事情补做了，为什么对方还没消气？》

96秒，1920×1080横屏，30fps，2880帧，无新增配音。视频自身完整讲清“任务完成”和“影响需要回应”的区别，并演示承认偏差、核对影响、重订约定，不依赖下一集补完方法。

## 内容与字幕

- 根据上传《高级男人手册》正文117—121、126—127页相关讨论改编。去除性别定律和读心式断言。
- 饭后收拾、一小时后仍需催促的情境为原创虚构，不冒充书中真实事件。三步方法为延伸建议，不是原书现成流程或验证过的关系干预。
- 30分钟为可协商的示例时间，不是统一标准。没有保证立刻消气、恢复信任或改善关系。
- 保留边界：分工没说清时先约定；回应不满不等于接受羞辱；对方不必立刻原谅。
- 观点标题92—112px；案例与方法40—62px；普通说明42px；来源25px。重点用字重和荧光黄／深绿区分。固定断行，关键句有阅读停顿。
- 图形是餐盘、时间带和关系示意，不是情绪量表、好感评分或真实心理机制。

## 实际完成的检查

- Remotion4.0.536完整渲染成功，TypeScript检查通过。
- 视频流96秒，容器时长{t['duration_seconds']}秒（含AAC边界填充），分辨率1920×1080，30fps，2880帧。
- 完整视频和音轨通过FFmpeg解码，退出码0，无解码错误。
- 全部2880帧扫描，近黑帧{len(t['black_frames'])}；非计划切点异常全局大幅帧差{len(t['unexpected_large_frame_differences'])}。该技术指标不能替代审美评价。
- 从最终MP4实际提取31帧，检查开头、案例、两层问题、历史付出、三步方法、边界及最终总结；另检查Studio中的文字边界。
- Chromium完整播放至结尾，丢帧{b['quality']['droppedVideoFrames']}、损坏帧{b['quality']['corruptedVideoFrames']}，无播放错误。
- 最终AAC实测约{L} LUFS，真峰值{P} dBFS；没有输出峰值过载。没有进行人耳试听，不把技术音轨检查说成人工听感通过。
- 音乐节奏报告为BPM候选（75、56.604、115.385等）与起音位置，不是人耳确认的完整重拍标注。
- 音效为本地确定性合成，配合落位、时钟、图层展开和约定形成，不是现场录音。
- 所有使用的中文字形均在内嵌字体子集中。
- {'工程ZIP通过CRC检查，解压后的实际渲染第60帧与原工程同帧PNG一致；渲染输入已核对。' if s and s.get('matches_original_frame') else '工程渲染复现检查待最后打包后执行，尚不标为通过。'}

## 文件与工具

MP4：{t['bytes']:,}字节。
SHA-256：`{t['sha256']}`。

Open Montage实际参与素材探测、混音、合成预检、成片媒体探测与抽帧；本地适配器补充帧时间轴、节奏分析；动画由项目独立Remotion源码制作。沿用既有依赖，没有新增npm包、升级全局依赖或调用付费生成接口。

工程包不含原书PDF或全文OCR。来源与延伸方法的区分、脚本、帧时间轴和检查记录均随源码保留。独立Remotion入口可编辑；跨机器重新安装依赖尚未实测。

第1条及此前作品未修改，本轮只交付第2条。
'''
(O/'Checks.md').write_text(text)
files=[]
for name in ['README.md','package.json','package-lock.json','tsconfig.json','config.json']:files.append(R/name)
for name in ['src','public','scripts']:files.extend(x for x in (R/name).rglob('*') if x.is_file() and '__pycache__' not in x.parts)
for name in ['script.json','scene_plan.json','knowledge-distillation.md','decision_log.json','editorial-review.json','technical-review.json','browser-playback.json','music-rhythm.json','sfx-events.json','final-loudness.txt','full-decode.txt','render-command.json','ffprobe-final.json','layout-review.json','source-export-check.json','published-copy.json','tool-integration-summary.json','asset-manifest.json','visual-review.json','source-render-inputs.json']:
 if (R/'artifacts'/name).exists():files.append(R/'artifacts'/name)
z=O/'NewWorld-E02-Editable-Source.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as f:
 for x in sorted(set(files)):f.write(x,Path('NewWorld-E02')/x.relative_to(R))
 f.write(O/'Checks.md','NewWorld-E02/Checks.md')
with zipfile.ZipFile(z) as f:
 assert f.testzip() is None
 assert not any('ocr-full' in n or n.lower().endswith('.pdf') for n in f.namelist())
for name in ['NewWorld-E02-Repair-96s.mp4','NewWorld-E02-Editable-Source.zip','Checks.md','Keyframes.pdf']:shutil.copy2(O/name,D/name)
manifest={n:{'bytes':(D/n).stat().st_size,'sha256':hashlib.sha256((D/n).read_bytes()).hexdigest()} for n in ['NewWorld-E02-Repair-96s.mp4','NewWorld-E02-Editable-Source.zip','Checks.md','Keyframes.pdf']}
(D/'SHA256.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(manifest,indent=2))
