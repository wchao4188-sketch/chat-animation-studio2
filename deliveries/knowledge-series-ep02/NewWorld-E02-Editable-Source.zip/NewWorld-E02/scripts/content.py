from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
beats=[('Hook',0,5,'碗已经洗了，','为什么还在吵？','洗净的是碗，没说清的可能是这次失约。'),('Promise',5,17,'说好的分工，','为什么又变成了提醒？','原创情境：约好饭后收拾，却拖到一小时后。'),('Layers',17,29,'补做解决了任务，','不一定回应了影响。','等待、提醒、安排变化，可能还需要说清。'),('Past',29,38,'过去的付出，','不能直接抵消这次失约。','过去值得被看见，这次也要单独处理。'),('Admit',38,51,'先承认，','这次哪里没做到。','“我答应饭后收拾，但没有按时做。”'),('Impact',51,64,'再核对，','具体影响了什么。','“刚才让你反复提醒了，还有什么受影响？”'),('Agree',64,79,'把“以后注意”，','换成可以协商的约定。','何时做、谁来做、做不到时怎么办。'),('Boundary',79,88,'回应失望，','也保留边界。','不必立刻原谅，也不接受羞辱。'),('Close',88,96,'补做事情，','也回应影响。','承认偏差 → 核对影响 → 重订约定')]
sections=[{'id':n,'start':a,'end':b,'start_frame':int(a*30),'end_frame':int(b*30),'headline':[h1,h2],'caption':cap} for n,a,b,h1,h2,cap in beats]
(R/'artifacts/script.json').write_text(json.dumps({'title':'事情补做了，为什么对方还没消气？','episode':2,'fps':30,'frames':2880,'duration_seconds':96,'width':1920,'height':1080,'voiceover':False,'sections':sections,'case_type':'原创虚构情境；非书中真实事件','source':{'book':'上传《高级男人手册》版本','body_pages':[117,118,119,120,121,126,127],'pdf_pages':[121,122,123,124,125,130,131]},'claim_boundary':'任务完成与信任、影响的区分为情境化解释；不认定每次争执都来自长期积怨。三步方法是延伸，不冒充原书原话或验证过的疗法。','case_dialogue':['“饭后我来收拾。”','一小时后，仍需要提醒。','“我不是已经洗完了吗？”','“可刚才还是我在催。”'],'method_dialogue':['“我答应饭后收拾，但没有按时做。”','“刚才让你反复提醒了，还有什么受影响？”','“下次饭后半小时内收好。如果来不及，提前说，我们一起改安排。你看这样行吗？”'],'boundaries':['如果分工从未说清，先重新约定。','不需要用一次失约判断整个人；回应不等于必须立刻原谅。','新约定仍要看后续行动，不保证立即恢复信任。'],'review':{'absolute_promises':False,'gender_generalizations':False,'fiction_identified':True,'methods_labeled_as_extensions':True,'next_episode_required_to_complete_lesson':False}},ensure_ascii=False,indent=2))
(R/'artifacts/scene_plan.json').write_text(json.dumps({'sections':sections,'visual_system':'冷白、石墨、荧光黄的系列视觉；洗净餐盘、延迟时间带、双层进度与可移动约定游标。','animation':'餐盘转体成为任务节点；两条时间线分离，已完成与未回应同屏；过去的付出停在历史区域；明确承认、核对、协商逐步改变同一约定结构。','knowledge_role':'两条进度是视觉隐喻，不是心理量表或好感评分。','typography':'重点标题94—112px，方法／对话44—54px，普通解释40—44px，来源25px。固定断行，重要内容至少稳定2秒。','scope':'本集独立完整；与第1集方法相接，但观看本集不依赖第1集。'},ensure_ascii=False,indent=2))
(R/'artifacts/knowledge-distillation.md').write_text('''# 第2条知识提炼与内容审核

来源：上传版本正文117—121、126—127页，对应PDF121—125、130—131页。原书讨论拖延承诺可能影响信任，以及过去表现不能直接平息当下失望。原书将其按男女定律概括，并有转移注意力和强势亲密互动建议；本片不采用这些部分。

1. 核心观点（改编解释）：补做一件事，不一定回应了未按约完成带来的影响。
2. 底层逻辑（情境解释）：结果只说明任务现在完成；等待、提醒、改安排已经发生，是否仍重要要向对方核对，不能直接读心。
3. 技能（延伸）：说清具体偏差、询问实际影响、协商可执行的新约定。
4. 方法（延伸）：确认约定确实存在→承认这次未按时完成→核对造成的影响→协商时间、责任与变更通知→用后续行动检验。判断错了就修正，不替对方编情绪原因。
5. 案例：两人约好饭后收拾，拖到一小时后并需要催促；任务补做后仍有不满。原创虚构，不是原书真实事件；一小时只是情境时间，不是统计数字。
6. 误区：把补做当成必须立刻消气的交换；只列过去功劳；用这次偏差判定对方整个人；只许下更大的新保证。
7. 边界：没有明确约定时先澄清；不满可能来自当次分工等其他原因；双方都可表达并协商；承认偏差不等于接受羞辱，对方也不必立刻原谅。不对修复结果、幸福或感情作保证。
8. 总结：补做事情，也回应影响。

本片不使用性别概括、原书未经核实的情绪比例、医学或神经解释。所有演示方法明确属于延伸建议，不代表验证过的关系干预。
''')
(R/'artifacts/decision_log.json').write_text(json.dumps([{'category':'scope','selected':'Only episode2; 96s;1920x1080;30fps;no voiceover','authorization':'用户“继续下一条”，沿用每条2分钟内、横屏、逐条交付和突出字幕要求。'},{'category':'runtime','selected':'Existing Remotion4.0.536,React19.2.4; no new npm dependencies','open_montage':'Reuse installed integration adapter for probe,mix,validation,sampling; project-specific animation rendered with pinned Remotion CLI.'},{'category':'narrative','selected':'Completed chore versus unaddressed impact; no gender claims, score or guarantee','source':'Uploaded book chapters mapped to PDF121–125,130–131.'},{'category':'preservation','selected':'New ep02-repair directory; no edits to episode1 or older deliverables.'}],ensure_ascii=False,indent=2))
print('Episode2 content and knowledge audit written; 9 sequences,96s.')
