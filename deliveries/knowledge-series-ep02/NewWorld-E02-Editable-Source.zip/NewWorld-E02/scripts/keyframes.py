from pathlib import Path
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[1];files=sorted((R/'output/keyframes').glob('*.png'));pages=[]
for start in range(0,len(files),8):
 page=Image.new('RGB',(1600,4*480),'#bccabd');d=ImageDraw.Draw(page)
 for k,f in enumerate(files[start:start+8]):
  im=Image.open(f).convert('RGB').resize((780,439));x=k%2*800+10;y=k//2*480+30;page.paste(im,(x,y));d.text((x,y-20),f.stem,fill='black')
 pages.append(page)
assert len(files)==31,len(files)
pages[0].save(R/'output/Keyframes.pdf',save_all=True,append_images=pages[1:],resolution=150)
for i,p in enumerate(pages):p.resize((1120,1344)).save(R/'output'/f'review-sheet-{i+1}.jpg',quality=91)
print('Final MP4 frames in overview:',len(files))
