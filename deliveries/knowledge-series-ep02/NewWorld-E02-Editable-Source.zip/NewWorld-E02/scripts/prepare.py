from pathlib import Path
import json,sys,subprocess,hashlib,wave
import numpy as np
from fontTools.ttLib import TTCollection
from fontTools import subset
R=Path(__file__).resolve().parents[1];text=''.join(p.read_text() for p in (R/'src').rglob('*.tsx'))
for weight in ['Regular','Bold']:
 fonts=TTCollection(f'/usr/share/fonts/opentype/noto/NotoSansCJK-{weight}.ttc').fonts;f=next(f for f in fonts if any(n.toUnicode()=='Noto Sans CJK SC' for n in f['name'].names if n.nameID in [1,16]));s=subset.Subsetter();s.populate(text=text);s.subset(f);f.flavor='woff';f.save(R/'public/fonts'/f'NotoSansSC-{weight}.woff')
 assert not {ord(c) for c in text if ord(c)>=0x2e80 and not c.isspace()}-set(f.getBestCmap())
sys.path.insert(0,'/workspace/-/knowledge-production-system')
from orchestrator.dispatch import Dispatcher,Request
D=Dispatcher(json.loads((R/'config.json').read_text()))
music=Path('/workspace/attachments/e0ebc65e-d848-4388-bb8b-30e2e6bd107a/mmexport1792300994359.mp3')
r=D.run(Request('source_music_probe','media.probe',{'input_path':str(music)},[str(music)],allow_fallback=True));assert r['success'],r
if not (R/'public/audio/music-excerpt.m4a').exists():subprocess.run(['ffmpeg','-v','error','-n','-ss','18.1','-i',str(music),'-t','96','-vn','-c:a','aac','-b:a','256k',str(R/'public/audio/music-excerpt.m4a')],check=True)
events=[{'time':.95,'label':'ceramic arrives','kind':'ceramic'},{'time':8.0,'label':'clock delay','kind':'clock'},{'time':18.6,'label':'two layers separate','kind':'ribbon'},{'time':40.6,'label':'deviation bracket settles','kind':'touch'},{'time':69.1,'label':'concrete agreement marker','kind':'touch'},{'time':91.1,'label':'three-step close','kind':'settle'}]
r=D.run(Request('music_rhythm','audio.rhythm',{'input_path':str(R/'public/audio/music-excerpt.m4a'),'output_path':str(R/'artifacts/music-rhythm.json'),'events':events},[str(R/'public/audio/music-excerpt.m4a')]));assert r['success'],r
# Material-related, deterministic synthesis. No fixed chime for every text entrance.
sr=48000;n=int(96*sr);a=np.zeros((n,2),dtype=np.float64);rng=np.random.default_rng(20261024)
for ev in events:
 at=round(ev['time']*sr);N=int(sr*(1.15 if ev['kind'] in ['ribbon','settle'] else .65));q=np.arange(N)/sr
 if ev['kind']=='ceramic':
  sig=sum(np.sin(2*np.pi*hz*q)*np.exp(-q*decay)*amp for hz,decay,amp in [(790,7,.045),(1573,12,.018),(2363,20,.012)])*(1-np.exp(-q*900))
 elif ev['kind']=='clock':sig=np.sin(2*np.pi*1050*q)*np.exp(-q*70)*.024
 elif ev['kind']=='ribbon':
  noise=rng.normal(0,1,N);noise=np.convolve(noise,np.ones(36)/36,'same');sig=noise*np.sin(np.pi*np.minimum(q/1.15,1))**2*.11
 elif ev['kind']=='settle':sig=(np.sin(2*np.pi*295*q)+.35*np.sin(2*np.pi*442.5*q))*(1-np.exp(-q*30))*np.exp(-q*5)*.025
 else:sig=np.sin(2*np.pi*(480*q-95*q*q))*np.exp(-q*14)*(1-np.exp(-q*230))*.025
 size=min(N,n-at);a[at:at+size,0]+=sig[:size]*.93;a[at:at+size,1]+=sig[:size]
with wave.open(str(R/'public/audio/sfx.wav'),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((np.clip(a,-.95,.95)*32767).astype('<i2').tobytes())
(R/'artifacts/sfx-events.json').write_text(json.dumps({'seed':20261024,'method':'local deterministic synthesis, not recorded foley','events':events},indent=2))
r=D.run(Request('mix_master','audio.mix',{'operation':'full_mix','tracks':[{'path':str(R/'public/audio/music-excerpt.m4a'),'role':'music','volume':.44,'fade_in_seconds':.3,'fade_out_seconds':2.4},{'path':str(R/'public/audio/sfx.wav'),'role':'sfx','volume':.85}],'normalize':True,'loudnorm_target':-17,'target_duration':96,'ducking':{'enabled':False},'output_path':str(R/'public/audio/master.wav')},[str(R/'public/audio/music-excerpt.m4a'),str(R/'public/audio/sfx.wav')],cache=True));assert r['success'],r
(R/'artifacts/asset-manifest.json').write_text(json.dumps({'music_source':str(music),'source_sha256':hashlib.sha256(music.read_bytes()).hexdigest(),'excerpt_start':18.1,'excerpt_end':114.1,'voiceover':False,'new_dependencies':[],'render_fonts':'embedded subset Noto Sans CJK SC','sfx':'procedural synthesis','audio_mix_tool':r['tool'],'source_book_not_redistributed':True},ensure_ascii=False,indent=2))
print('Fonts glyph coverage verified; music read, rhythm estimated, SFX synthesized, Open Montage mix passed.')
