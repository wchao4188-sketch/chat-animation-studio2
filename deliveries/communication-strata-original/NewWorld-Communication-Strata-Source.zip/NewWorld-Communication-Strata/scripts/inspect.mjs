import fs from 'node:fs';
import {openBrowser,selectComposition,renderStill} from '@remotion/renderer';
import {bundle} from '@remotion/bundler';
const url=await bundle({entryPoint:'src/index.tsx'});
const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium',logLevel:'error'});
const comp=await selectComposition({serveUrl:url,id:'CommunicationStrata',puppeteerInstance:browser});
const page=await browser.newPage({context:()=>null,logLevel:'error',indent:false,pageIndex:0,onBrowserLog:null,onLog:()=>{}});
await page.goto({url:'http://127.0.0.1:3130/',timeout:30000,options:{waitUntil:'load'}});
console.log(JSON.stringify({studioStatus:'opened in Chromium',studioTitle:await page.evaluate(()=>document.title),composition:comp},null,2));
for(const frame of JSON.parse(fs.readFileSync("src/chapters.json","utf8")).map(x=>x.frame)){
 await renderStill({serveUrl:url,composition:comp,frame,output:`output/review/boundary-${frame}.png`,imageFormat:'png',puppeteerInstance:browser});
}
await browser.close({silent:true});
