import {openBrowser} from '@remotion/renderer';
import fs from 'node:fs/promises';
const b=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium',logLevel:'error'});
try{
 const p=await b.newPage({context:()=>null,logLevel:'error',indent:false,pageIndex:0,onBrowserLog:null,onLog:()=>{}});
 await p.goto({url:'http://127.0.0.1:3131/',timeout:30000,options:{waitUntil:'load'}});
 const r=await p.evaluate(async()=>{const v=document.createElement('video');v.src='NewWorld-Communication-Strata.mp4';v.muted=true;v.controls=true;v.width=960;document.body.append(v);await new Promise((r,j)=>{v.onloadedmetadata=r;v.onerror=()=>j(new Error('Video load failed'))});await v.play();await new Promise((r,j)=>{v.onended=r;v.onerror=()=>j(new Error('Playback failed'));setTimeout(()=>j(new Error('Playback timeout')),180000)});const q=v.getVideoPlaybackQuality();return{duration:v.duration,currentTime:v.currentTime,ended:v.ended,decodedFrames:q.totalVideoFrames,droppedFrames:q.droppedVideoFrames,error:v.error?.message||null,muted:v.muted,human_listening:false}});
 await fs.writeFile('output/playback-check.json',JSON.stringify(r,null,2));console.log(r);
}finally{await b.close({silent:true})}
