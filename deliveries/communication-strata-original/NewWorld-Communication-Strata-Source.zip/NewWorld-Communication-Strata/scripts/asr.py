from pathlib import Path
import sherpa_onnx,subprocess,json,re,difflib
import numpy as np
R=Path(__file__).resolve().parents[1];P=Path('/workspace/-/assets/models/sherpa-onnx-paraformer-zh-small-2024-03-09')
a=sherpa_onnx.OfflineRecognizer.from_paraformer(paraformer=str(P/'model.int8.onnx'),tokens=str(P/'tokens.txt'),num_threads=2)
rows=json.loads((R/'src/timeline.json').read_text());out=[]
for row in rows:
 z=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(R/f"public/audio/voice-{row['id']:02}.wav"),'-ar','16000','-ac','1','-f','f32le','-']),np.float32)
 s=a.create_stream();s.accept_waveform(16000,z);a.decode_stream(s);text=s.result.text;clean=lambda x:re.sub(r'[^\u4e00-\u9fff]','',x)
 score=difflib.SequenceMatcher(None,clean(row['text']),clean(text)).ratio();out.append({'id':row['id'],'expected':row['text'],'recognized':text,'similarity':score});print(row['id'],round(score,3),text,flush=True)
(R/'output/narration-asr.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
