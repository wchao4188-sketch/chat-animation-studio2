from pathlib import Path
import re,json
R=Path(__file__).resolve().parents[1];rows=json.loads((R/'src/timeline.json').read_text())
def tc(t):
 ms=round(t*1000);s,ms=divmod(ms,1000);m,s=divmod(s,60);h,m=divmod(m,60);return f'{h:02}:{m:02}:{s:02},{ms:03}'
out=[]
for row in rows:
 parts=re.findall(r'[^，。；？！：]+[，。；？！：]?',row['text']);chunks=[];buf=''
 for p in parts:
  if len(buf+p)>25 and buf:chunks.append(buf);buf=''
  buf+=p
 if buf:chunks.append(buf)
 consumed=0
 for text in chunks:
  start=row['start']+row['duration']*consumed/len(row['text']);consumed+=len(text);end=row['start']+row['duration']*consumed/len(row['text']);out.append(f"{len(out)+1}\n{tc(start)} --> {tc(end)}\n{re.sub(r'[，；：]$','',text)}")
(R/'output/Narration.srt').write_text('\n\n'.join(out),encoding='utf8');print(len(out),'subtitle cues exported')
