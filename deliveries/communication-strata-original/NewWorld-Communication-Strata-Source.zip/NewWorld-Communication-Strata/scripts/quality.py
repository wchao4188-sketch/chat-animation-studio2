from pathlib import Path
import json,subprocess,hashlib,wave
from PIL import Image,ImageDraw
import numpy as np
R=Path(__file__).resolve().parents[1];O=R/'output';P=O/'NewWorld-Communication-Strata.mp4';S=json.loads((R/'src/settings.json').read_text());N=S['frames'];D=S['duration'];Q=O/'review';Q.mkdir(exist_ok=True)
p=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(P)]));v=next(x for x in p['streams'] if x['codec_type']=='video');a=next(x for x in p['streams'] if x['codec_type']=='audio')
assert(v['width'],v['height'],v['r_frame_rate'],int(v['nb_read_frames']))==(1920,1080,'30/1',N)
assert abs(float(v['duration'])-D)<.002 and abs(float(p['format']['duration'])-D)<.002
q=subprocess.run(['ffmpeg','-v','error','-i',str(P),'-f','null','-'],capture_output=True);assert q.returncode==0 and not q.stderr
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(P),'-vf','scale=320:180','-f','rawvideo','-pix_fmt','rgb24','-']);f=np.frombuffer(raw,np.uint8).reshape(N,180,320,3)
means=f.mean(axis=(1,2,3));diff=np.array([np.abs(f[i].astype(np.int16)-f[i-1]).mean() for i in range(1,N)]);assert means.min()>5
# Full decoded stream inspected computationally. Visual contact pages sample every 15 frames (0.5s).
indices=list(range(0,N,15))+[N-1];pages=[]
for k in range(0,len(indices),24):
 im=Image.new('RGB',(1600,838),'#15201b');dr=ImageDraw.Draw(im)
 for j,i in enumerate(indices[k:k+24]):
  x=j%5*320;y=j//5*166;im.paste(Image.fromarray(f[i]).resize((284,160)),(x,y));dr.text((x+3,y+147),f'{i/30:.2f}s / {i}',fill='white')
 dst=Q/f'overview-{k//24:02}.jpg';im.save(dst,quality=92);pages.append(dst)
ims=[Image.open(p).convert('RGB') for p in pages];ims[0].save(O/'Communication-Strata-Keyframes.pdf',save_all=True,append_images=ims[1:],resolution=110)
# Audio is independently decoded and compared against the intended master.
x=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(P),'-vn','-ac','2','-ar','48000','-f','f32le','-']),np.float32).reshape(-1,2)
with wave.open(str(R/'public/audio/master.wav')) as w:y=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32).reshape(-1,2)/32768
n=min(len(x),len(y));corr=float(np.corrcoef(x[:n].ravel(),y[:n].ravel())[0,1]);peak=float(abs(x).max());assert corr>.98 and peak<1
result={'video':{'codec':v['codec_name'],'width':v['width'],'height':v['height'],'fps':v['r_frame_rate'],'frames':int(v['nb_read_frames']),'duration':float(v['duration'])},'container_duration':float(p['format']['duration']),'audio':{'codec':a['codec_name'],'sample_rate':a['sample_rate'],'channels':a['channels'],'duration':a['duration'],'peak':peak,'correlation_with_master':corr},'full_decode':{'exit_code':q.returncode,'errors':q.stderr.decode()},'frame_analysis':{'decoded_frames':N,'minimum_mean_brightness':float(means.min()),'max_adjacent_mean_difference':float(diff.max()),'largest_difference_frame':int(diff.argmax()+1),'overview_samples':len(indices),'overview_interval_seconds':.5,'pages':len(pages)},'file':{'bytes':P.stat().st_size,'sha256':hashlib.sha256(P.read_bytes()).hexdigest()},'human_listening':False,'visual_review_note':'Contact sheets and full-size selected frames are inspected separately. Metrics do not certify aesthetics.'}
(O/'quality-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
# Poster and exact milestone frames from the actual MP4, not a different render.
for sec in [2,14,23,30,39,48,60,70,80,90,D-1]:
 sec=min(sec,D-.05);subprocess.run(['ffmpeg','-v','error','-y','-ss',str(sec),'-i',str(P),'-frames:v','1',str(Q/f'actual-{sec:.2f}.png')],check=True)
# Denser samples around every real chapter transition, so a clean still cannot hide a bad transition.
chapters=json.loads((R/'src/chapters.json').read_text())
for k,e in enumerate(chapters[1:],1):
 start=e['time']-.95
 data=subprocess.check_output(['ffmpeg','-v','error','-ss',str(start),'-i',str(P),'-t','1.9','-vf','fps=8,scale=480:270','-f','rawvideo','-pix_fmt','rgb24','-'])
 ff=np.frombuffer(data,np.uint8).reshape(-1,270,480,3);im=Image.new('RGB',(1920,1184),'#15201b');dr=ImageDraw.Draw(im)
 for j,frame in enumerate(ff[:16]):
  xx=j%4*480;yy=j//4*296;im.paste(Image.fromarray(frame),(xx,yy));dr.text((xx+7,yy+272),f'{start+j/8:.3f}s',fill='white')
 im.save(Q/f'transition-{k}.jpg',quality=94)
print('Dense transition review images generated.')
