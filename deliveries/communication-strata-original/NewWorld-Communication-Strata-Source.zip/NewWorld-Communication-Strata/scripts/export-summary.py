from pathlib import Path
import json,statistics
R=Path(__file__).resolve().parents[1];O=R/'output';q=json.loads((O/'quality-check.json').read_text());b=json.loads((O/'playback-check.json').read_text());d=json.loads((O/'determinism-check.json').read_text());a=json.loads((O/'narration-asr.json').read_text());m=json.loads((O/'music-analysis.json').read_text())
text=f'''# 实际验收记录｜别把所有问题，都叫「不会聊天」

## 实际输出

- Remotion + React + TypeScript 代码动画，1920×1080，16:9，30 fps。
- 视频 {q['video']['duration']:.6f} 秒，{q['video']['frames']} 帧，{q['file']['bytes']:,} 字节。
- H.264 / yuv420p，AAC / 48 kHz / 双声道。
- 视频 SHA-256：`{q['file']['sha256']}`。
- 新建独立工程，没有覆盖此前作品。

## 已执行的技术检查

- TypeScript 类型检查通过；Chromium 实际打开 Studio 并取得整片合成元数据。
- FFmpeg 完整解码退出码 {q['full_decode']['exit_code']}，错误输出为空。
- 全部 {q['video']['frames']} 帧计算亮度及相邻帧差异；最低平均亮度 {q['frame_analysis']['minimum_mean_brightness']:.3f}，未检测到全黑帧。
- Chromium 从开始播放到 ended：{b['ended']}；总视频帧 {b['decodedFrames']}，丢帧 {b['droppedFrames']}，媒体错误 {b['error']}。浏览器静音运行，不等于人工试听。
- 总混音与视频解码音轨相关系数 {q['audio']['correlation_with_master']:.6f}；解码峰值 {q['audio']['peak']:.6f}，没有数值削波。
- 第 {d['frame']} 帧独立渲染两次，PNG SHA-256 相同：{d['identical']}。

## 实际视觉检查

全片按每0.5秒提取总览，共 {q['frame_analysis']['overview_samples']} 张，另检查高清关键帧与章节转场。开场有整体拆分和局部推进；两扇门区分意愿与勇气；信息间距变化后返回路径出现；同一照片展开假设与回应分支；两张参数曲面保留不同形状；结尾停留供阅读。

制作中修复：照片回应标签和「摄影」重叠；人物位置名称与匹配条件重叠；层板名称被其他层遮盖。最终以实际 MP4 抽帧复核。

## 声音检查与明确限制

- 使用用户已有音乐的0–{q['video']['duration']:.6f}秒；自动速度候选 {m['bpm_candidates'][0]['bpm']:.1f} / {m['bpm_candidates'][1]['bpm']:.1f} BPM，没有宣称人工确认小节重拍。
- 配音为本地 Kokoro `zm_yunjian` 合成；为识别偏差较大的句子进行多次重读与措辞调整。
- 独立中文 ASR 逐句检查18段，文字相似度平均 {statistics.mean(x['similarity'] for x in a):.4f}。有同音字及少量识别差异，未把识别率声称为100%正确；原文和识别结果均附在 narration-asr.json。
- 未进行真人试听，不能声称自然度或咬字已通过人工验收。
- 音乐压低、转场和动作音效由实际时间轴制作。声音来源与音效事件可在工程中检查。

- 每句旁白相对背景音乐的实际均方根电平差至少17.25 dB；这项数值检查不代替主观听感判断。

## 内容与工程

- 用户图片的四类共23个分项都有对应表达，详见 assets/content-map.json。
- 这套分类是观察框架，不是经过验证的心理分级；图形不代表好感、价值或成功率。
- 没有新增 npm 依赖。复用固定版本 Remotion/React；新下载并实际使用官方 Kokoro 模型。源工程含可直接渲染的音轨，不需模型即可重新渲染。
- Python分析/声音重制脚本需 NumPy/SciPy/Pillow/fontTools；语音重制另需 sherpa-onnx 与官方模型。日常视觉修改与重渲染不依赖这些 Python 步骤。
- 尚未验证 Windows 环境的工程渲染；MP4 为标准H.264/AAC。
'''
(O/'Acceptance.md').write_text(text);print(text)
