from pathlib import Path
from fontTools import subset
R=Path(__file__).resolve().parents[1]
text=''.join(p.read_text() for p in list((R/'src').glob('*.*'))+list((R/'assets').glob('*.json')))+'0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz，。？！：；「」“”·—/→＋−×＝？%'
for source,name in [('NotoSansCJK-Regular.ttc','StrataSans'),('NotoSansCJK-Bold.ttc','StrataBold'),('NotoSerifCJK-Bold.ttc','StrataSerif')]:
 o=subset.Options();o.font_number=2;o.flavor='woff'
 f=subset.load_font('/usr/share/fonts/opentype/noto/'+source,o);s=subset.Subsetter(options=o);s.populate(text=text);s.subset(f);subset.save_font(f,R/'public/fonts'/f'{name}.woff',o)
