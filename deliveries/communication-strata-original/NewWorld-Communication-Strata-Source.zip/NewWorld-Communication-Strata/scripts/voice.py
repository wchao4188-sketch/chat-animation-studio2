from pathlib import Path
import json,wave,subprocess,math
import numpy as np
import sherpa_onnx
R=Path(__file__).resolve().parents[1];A=R/'public/audio';P=Path('/workspace/-/assets/models/kokoro-multi-lang-v1_0')
c=sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(kokoro=sherpa_onnx.OfflineTtsKokoroModelConfig(model=str(P/'model.onnx'),voices=str(P/'voices.bin'),tokens=str(P/'tokens.txt'),lexicon=str(P/'lexicon-zh.txt'),data_dir=str(P/'espeak-ng-data'),dict_dir=str(P/'dict'),lang='zh'),num_threads=2),max_num_sentences=1)
tts=sherpa_onnx.OfflineTts(c);rows=json.loads((R/'assets/script.json').read_text());cursor=.5
for row in rows:
 dst=A/f"voice-{row['id']:02}.wav"
 if not dst.exists():
  z=tts.generate(row['text'],sid=49,speed=1.08)
  tmp=A/'raw.wav'
  with wave.open(str(tmp),'wb') as w:w.setparams((1,2,z.sample_rate,0,'NONE','not compressed'));w.writeframes((np.clip(z.samples,-1,1)*32767).astype('<i2').tobytes())
  subprocess.run(['ffmpeg','-v','error','-y','-i',str(tmp),'-af','highpass=f=75,loudnorm=I=-17:TP=-2:LRA=7','-ar','48000','-ac','1',str(dst)],check=True);tmp.unlink()
 with wave.open(str(dst)) as w:d=w.getnframes()/w.getframerate()
 row.update(frame=math.ceil(cursor*30),duration=d);row['start']=row['frame']/30;row['end']=row['start']+d
 gap=.68 if row['key'] in ['reveal','choice','pace','initiative','boundary','conclusion'] else .3
 cursor=row['end']+gap;print(row['key'],round(row['start'],2),round(d,2),flush=True)
frames=math.ceil((rows[-1]['end']+3.2)*30);assert frames/30<=150
(R/'src/timeline.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));(R/'src/settings.json').write_text(json.dumps({'frames':frames,'fps':30,'width':1920,'height':1080,'duration':frames/30}));print('Total',frames/30,flush=True)
