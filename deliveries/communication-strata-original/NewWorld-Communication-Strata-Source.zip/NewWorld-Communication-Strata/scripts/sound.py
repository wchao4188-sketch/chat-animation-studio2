from pathlib import Path
import numpy as np
from scipy.signal import find_peaks,fftconvolve,butter,sosfilt
import json,subprocess,wave,hashlib
R=Path(__file__).resolve().parents[1];A=R/'public/audio';O=R/'output';rows=json.loads((R/'src/timeline.json').read_text());settings=json.loads((R/'src/settings.json').read_text());D=settings['duration'];sr=48000;n=settings['frames']*1600
m=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(A/'user-music-source.m4a'),'-t',str(D),'-ac','2','-ar',str(sr),'-f','f32le','-']),np.float32).reshape(-1,2)[:n];m=np.pad(m,((0,n-len(m)),(0,0)))
x=m.mean(axis=1)[::2];analysis_sr=24000;hop=256;win=1024
sp=np.abs(np.fft.rfft(np.lib.stride_tricks.sliding_window_view(x,win)[::hop]*np.hanning(win)))
flux=np.maximum(np.diff(np.log1p(sp*8),axis=0),0).sum(axis=1);flux=(flux-flux.mean())/(flux.std()+1e-8);pks,_=find_peaks(flux,prominence=1.25,distance=int(.30*analysis_sr/hop));times=(pks*hop+win/2)/analysis_sr
ac=fftconvolve(flux,flux[::-1],mode='full')[len(flux)-1:];lags=range(int(analysis_sr/hop*60/150),int(analysis_sr/hop*60/65));cand=[]
for k in sorted(lags,key=lambda k:ac[k],reverse=True):
 bpm=60*analysis_sr/hop/k
 if all(abs(bpm-v['bpm'])>4 for v in cand):cand.append({'bpm':bpm,'score':float(ac[k]/ac[0])})
 if len(cand)==3:break
chapters=[{'key':'opening','time':0,'label':'看清卡点'},{'key':'start','time':rows[3]['start']-.55,'label':'开始'},{'key':'expression','time':rows[5]['start']-.55,'label':'表达'},{'key':'skill','time':rows[8]['start']-.55,'label':'能力'},{'key':'match','time':rows[13]['start']-.55,'label':'匹配'},{'key':'end','time':rows[16]['start']-.55,'label':'选择'}]
for e in chapters[1:]:
 nearest=float(times[np.argmin(abs(times-e['time']))]);e['time']=round((nearest if abs(nearest-e['time'])<.2 else e['time'])*30)/30
for e in chapters:e['frame']=round(e['time']*30)
analysis={'duration':D,'music_file':'user-music-source.m4a','sha256':hashlib.sha256((A/'user-music-source.m4a').read_bytes()).hexdigest(),'selected_seconds':[0,D],'bpm_candidates':cand,'method':'Positive log spectral flux; autocorrelation over 65-150 BPM; transient peaks. Automatic candidates, not manually confirmed meter/downbeats.','transients':[{'seconds':round(float(t),4),'frame':round(float(t)*30),'strength':round(float(flux[p]),3)} for t,p in zip(times,pks)],'energy_1s_rms':[float(np.sqrt(np.mean(x[j:j+analysis_sr]**2))) for j in range(0,len(x),analysis_sr)],'chapter_events':chapters}
(O/'music-analysis.json').write_text(json.dumps(analysis,ensure_ascii=False,indent=2));(R/'src/chapters.json').write_text(json.dumps(chapters,ensure_ascii=False,indent=2))
voice=np.zeros(n,np.float32);activity=np.zeros(n,np.float32)
for row in rows:
 with wave.open(str(A/f"voice-{row['id']:02}.wav")) as w:z=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32)/32768
 j=row['frame']*1600;voice[j:j+len(z)]+=z;activity[max(0,j-5000):min(n,j+len(z)+7000)]=1
activity=np.clip(fftconvolve(activity,np.ones(16001)/16001,mode='same'),0,1).astype(np.float32)
# Music is continuous; sidechain, no edits to spoken timing.
m*=.086/(np.sqrt(np.mean(m*m))+1e-9);m*=((1-.82*activity)*np.minimum(1,np.arange(n)/sr/1.0)*np.minimum(1,(D-np.arange(n)/sr)/2.4))[:,None]
sfx=np.zeros((n,2),np.float32);rng=np.random.default_rng(3382);events=[]
def add(at,kind,dur=.55,gain=.04,pan=0):
 l=round(sr*dur);t=np.arange(l)/sr;u=np.arange(l)/max(1,l-1)
 noise=rng.standard_normal(l);noise=sosfilt(butter(2,[220,3800],fs=sr,btype='bandpass',output='sos'),noise)
 if kind=='split':z=noise*np.sin(np.pi*u)**1.7*.28+np.sin(2*np.pi*(68*t+40*t*t))*np.exp(-t*7)*.45
 elif kind=='gate':z=noise*np.sin(np.pi*u)**2*.22+np.sin(2*np.pi*(120*t-30*t*t))*np.sin(np.pi*u)**2*.24
 elif kind=='arrival':z=(np.sin(2*np.pi*510*t)+.4*np.sin(2*np.pi*820*t))*np.exp(-t*22)
 elif kind=='trace':z=noise*np.sin(np.pi*u)**2*.16+np.sin(2*np.pi*(220*t+190*t*t))*np.sin(np.pi*u)**2*.2
 else:z=np.sin(2*np.pi*74*t)*np.exp(-t*5)+noise*np.exp(-t*16)*.3
 z*=gain;idx=round(at*sr);end=min(n,idx+l)
 if idx>=0 and idx<n:sfx[idx:end]+=z[:end-idx,None]*np.array([np.sqrt((1-pan)/2),np.sqrt((1+pan)/2)])[None,:]
 events.append({'time':round(at,4),'kind':kind,'duration':dur,'pan':pan})
T={r['key']:r['start'] for r in rows}
for e in chapters[1:]:add(e['time']-.3,'split',.85,.048)
for at in [1.08,2.17,3.24,T['reveal']+.5]:add(at,'arrival',.35,.021)
add(T['choice']+1.8,'gate',1.2,.055,.45)
add(T['expression']+1.1,'trace',1.7,.035,-.3)
add(T['pace']+.3,'gate',1.2,.04,.2)
for off,pan in [(1.1,-.5),(2.4,.5)]:add(T['question']+off,'trace',.9,.03,pan)
add(T['response']+.8,'arrival',.65,.032,.5)
add(T['compatibility']+1,'gate',1.5,.035)
add(T['conclusion']+.7,'trace',1.8,.045)
add(T['end']+.2,'arrival',.8,.03)
mix=voice[:,None]+m+sfx;time=np.arange(n)/sr;mix*=np.minimum(1,time/.12)[:,None]*np.minimum(1,(D-time)/.7)[:,None];maxpeak=float(abs(mix).max());mix*=min(1,.89/maxpeak)
for name,z in [('narration.wav',voice),('music-ducked.wav',m),('sfx.wav',sfx),('master.wav',mix)]:
 with wave.open(str(A/name),'wb') as w:w.setparams((1 if z.ndim==1 else 2,2,sr,0,'NONE','not compressed'));w.writeframes((np.clip(z,-1,1)*32767).astype('<i2').tobytes())
subprocess.run(['ffmpeg','-v','error','-y','-i',str(A/'master.wav'),'-c:a','aac','-b:a','224k',str(A/'master.m4a')],check=True)
(O/'sound-events.json').write_text(json.dumps(events,indent=2));print(json.dumps({'duration':D,'bpm_candidates':cand,'chapters':chapters,'mix_peak_before_limit':maxpeak},ensure_ascii=False,indent=2))
