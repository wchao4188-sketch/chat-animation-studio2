import {bundle} from '@remotion/bundler';
import {openBrowser,selectComposition,renderStill} from '@remotion/renderer';
import fs from 'node:fs/promises';import crypto from 'node:crypto';
const url=await bundle({entryPoint:'src/index.tsx'}),b=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium',logLevel:'error'});
try{const c=await selectComposition({serveUrl:url,id:'CommunicationStrata',puppeteerInstance:b});const sums=[];for(let i=0;i<2;i++){const path=`output/review/determinism-${i}.png`;await renderStill({serveUrl:url,composition:c,puppeteerInstance:b,frame:3000,output:path,imageFormat:'png'});sums.push(crypto.createHash('sha256').update(await fs.readFile(path)).digest('hex'))}const result={frame:3000,sha256:sums,identical:sums[0]===sums[1]};await fs.writeFile('output/determinism-check.json',JSON.stringify(result,null,2));console.log(result);if(!result.identical)throw Error('Frame repeat differs')}finally{await b.close({silent:true})}
