#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
npx tsc --noEmit
npx remotion render src/index.tsx CommunicationStrata output/Communication-Strata-Render.mp4 --browser-executable=/usr/bin/chromium --codec=h264 --crf=17 --pixel-format=yuv420p --concurrency=3
DURATION=$(python -c 'import json;print(json.load(open("src/settings.json"))["duration"])')
ffmpeg -v error -y -i output/Communication-Strata-Render.mp4 -map 0:v:0 -map 0:a:0 -c:v copy -af "atrim=duration=$DURATION" -c:a aac -b:a 224k -t "$DURATION" -movflags +faststart output/NewWorld-Communication-Strata.mp4
