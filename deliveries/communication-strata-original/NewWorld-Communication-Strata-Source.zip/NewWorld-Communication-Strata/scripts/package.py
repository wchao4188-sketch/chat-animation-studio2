from pathlib import Path
import zipfile,hashlib,json
R=Path(__file__).resolve().parents[1];O=R/'output';dst=O/'NewWorld-Communication-Strata-Source.zip'
files=[R/x for x in ['package.json','package-lock.json','tsconfig.json','README.md']]
for folder in ['src','scripts','public']:
 files+= [p for p in (R/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name != 'kokoro-test.py']
for name in ['script.json','content-map.json','voice-model.json','Font-LICENSE.txt','Kokoro-LICENSE.txt','environment-notes.json']:files.append(R/'assets'/name)
for name in ['Acceptance.md','music-analysis.json','sound-events.json','quality-check.json','playback-check.json','determinism-check.json','narration-asr.json','audio-balance.json','Narration.txt','Narration.srt']:files.append(O/name)
assert all(p.exists() for p in files)
with zipfile.ZipFile(dst,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(files):z.write(p,Path('NewWorld-Communication-Strata')/p.relative_to(R))
with zipfile.ZipFile(dst) as z:assert z.testzip() is None
assert dst.stat().st_size<100*1024**2
manifest=[]
for p in [O/'NewWorld-Communication-Strata.mp4',dst,O/'Communication-Strata-Keyframes.pdf',O/'Acceptance.md']:
 manifest.append({'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(O/'SHA256SUMS.txt').write_text('\n'.join(x['sha256']+'  '+x['name'] for x in manifest)+'\n');(O/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));print(json.dumps(manifest,ensure_ascii=False,indent=2))
