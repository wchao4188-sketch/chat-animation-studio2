import React,{useEffect,useRef,useState} from 'react';
import {AbsoluteFill,continueRender,delayRender,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import {Audio} from '@remotion/media';
import {prepareBackground,caption} from './draw';
import {renderers,darkness,transition} from './scenes';
import timeline from './timeline.json';
import chapters from './chapters.json';
function subtitle(t:number){const row=timeline.find(r=>t>=r.start&&t<r.end);if(!row)return '';
 const parts=row.text.match(/[^，。；？！：]+[，。；？！：]?/g)||[row.text];const chunks:string[]=[];let buf='';for(const p of parts){if((buf+p).length>25&&buf){chunks.push(buf);buf=''}buf+=p}if(buf)chunks.push(buf);const progress=(t-row.start)/row.duration;let acc=0;for(const s of chunks){acc+=s.length/row.text.length;if(progress<acc)return s.replace(/[，；：]$/,'')}return chunks[chunks.length-1];}
export const Film=({scene}:{scene?:number})=>{const frame=useCurrentFrame(),{fps}=useVideoConfig(),ref=useRef<HTMLCanvasElement>(null);const [handle]=useState(()=>delayRender('Load local typography'));const [ready,setReady]=useState(false);
 useEffect(()=>{let live=true;Promise.all(['StrataSans','StrataBold','StrataSerif'].map(n=>new FontFace(n,`url(${staticFile(`fonts/${n}.woff`)})`).load())).then(fs=>{fs.forEach(f=>(document.fonts as FontFaceSet & {add:(f:FontFace)=>void}).add(f));prepareBackground();if(live)setReady(true)});return()=>{live=false}},[handle]);
 useEffect(()=>{if(!ready||!ref.current)return;const c=ref.current.getContext('2d')!;const t=frame/fps+(scene===undefined?0:chapters[scene].frame/fps);let idx=0;for(let i=1;i<chapters.length;i++)if(t>=chapters[i].time)idx=i;
 c.setTransform(1,0,0,1,0,0);c.globalAlpha=1;c.clearRect(0,0,1920,1080);
 let ti=-1;for(let i=1;i<chapters.length;i++)if(t>=chapters[i].time-.9&&t<=chapters[i].time+.55)ti=i;
 if(scene!==undefined)renderers[scene](c,t);else if(ti>0)transition(c,ti,t,chapters[ti].time);else renderers[idx](c,t);
 caption(c,subtitle(t),darkness[idx]);continueRender(handle);
 },[frame,ready,handle,scene,fps]);
 return <AbsoluteFill style={{background:'#e8ece9'}}><canvas ref={ref} width={1920} height={1080} style={{width:1920,height:1080}}/><Audio src={staticFile('audio/master.m4a')} trimBefore={scene===undefined?0:chapters[scene].frame}/></AbsoluteFill>
};
