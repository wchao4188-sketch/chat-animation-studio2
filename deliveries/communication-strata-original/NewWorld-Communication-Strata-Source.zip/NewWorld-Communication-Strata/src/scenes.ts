import {type C,ink,paper,lime,blue,coral,palette,txt,line,path,dot,round,pill,bg,mast,chapter,bezier,trace,shadow,metalCircle,project,worldLine,type Camera} from './draw';
import {clamp,mix,smooth,ease,io,range,reveal,hash,bez,type P} from './math';
import {strata,portal,contour,coast} from './objects';
import {sculpture} from './sculpture';
import timeline from './timeline.json';
import chapters from './chapters.json';
const T=Object.fromEntries(timeline.map(r=>[r.key,r.start]));
const labels=['开始','表达','聊天能力','自身条件与匹配'];
const arrows=(c:C,x:number,y:number,col:string)=>{line(c,[{x:x-9,y:y-9},{x,y},{x:x-9,y:y+9}],col,2)};
export function opening(c:C,t:number){
 bg(c);mast(c,1);
 const expanded=reveal(t,1,4.2),late=reveal(t,T.reveal-.3,1.3);
 // The compact monolith separates into four independently readable surfaces.
 const close=reveal(t,T.loop+.45,1.65)*(1-reveal(t,T.reveal-1,1.45));
 const cam:Camera={cx:mix(1265,1235,late)+close*10,cy:560-close*300,scale:1.01+close*.38,yaw:mix(-.65,-.42,expanded)-close*.12,tilt:mix(.44,.55,expanded)};
 strata(c,t,cam,expanded,late>.65);
 txt(c,'一个标签，',84,238,42,'#627269');
 const titleP=reveal(t,.15,.85);c.save();c.beginPath();c.rect(70,260,790*titleP,210);c.clip();txt(c,'不会聊天',77,438,145,ink,'StrataBold');c.restore();
 if(t<T.reveal){
  const p=reveal(t,5.3,.9);txt(c,'可能是四件不同的事。',86,533,38,ink,'StrataSans','left',p);
  // A loop illustrates working hard at the wrong place. The moving point never reaches the exit.
  const loopTime=range(t,5.4,12.9),a=loopTime*Math.PI*3.3;const ps=[];for(let i=0;i<145;i++){const q=i/144*Math.PI*2;ps.push({x:340+Math.cos(q)*175,y:746+Math.sin(q)*77})}
  if(t>5.1){line(c,ps,'#a6b2a8',1,.6);const q={x:340+Math.cos(a)*175,y:746+Math.sin(a)*77};dot(c,q.x,q.y,7,ink);line(c,[{x:515,y:746},{x:657,y:746}],'#a6b2a8',1,.6);line(c,[{x:655,y:728},{x:655,y:764}],coral,3);txt(c,'反复找话题',340,750,25,'#5f6d64','StrataSans','center');txt(c,'却没有找对问题',87,897,26,'#627269');txt(c,'连开始都没有发生',1420,821,28,ink,'StrataBold','center',close)}
 }else{
  txt(c,'先拆开，再解决。',85,548,49,ink,'StrataBold','left',late);
  txt(c,'四类卡点 / 不代表价值高低',88,862,24,'#68776e','StrataSans','left',late);
  for(let i=0;i<4;i++){const p=reveal(t,T.reveal+.25+i*.18,.55);line(c,[{x:88,y:642+i*42},{x:116+100*p,y:642+i*42}],palette[i],3,p);txt(c,labels[i],236,651+i*42,25,ink,'StrataSans','left',p)}
 }
 txt(c,'A LABEL IS NOT A DIAGNOSIS',87,942,17,'#77847a');
}
export function start(c:C,t:number){
 bg(c);mast(c,2);chapter(c,'01','开始','先分清：不想，还是不敢？');
 const local=t-chapters[1].time;const p=reveal(t,T.choice+1.75,1.2);const camMove=reveal(t,T.choice+2.9,1.3);
 // The two routes remain available; there is no forced push through the closed door.
 const xl=mix(1025,920,camMove),xr=mix(1515,1470,camMove),cy=530;
 portal(c,xl,cy,.03,.79,'#8fa291');portal(c,xr,cy,p,.9,lime);
 txt(c,'不想',xl,cy+349,48,ink,'StrataBold','center');txt(c,'想，但不敢',xr,cy+349,48,ink,'StrataBold','center');
 txt(c,'可以不开始',xl,cy+394,25,'#627269','StrataSans','center',reveal(t,T.choice,.8));
 txt(c,'先做一个小动作',xr,cy+394,25,'#627269','StrataSans','center',reveal(t,T.choice+3.4,.8));
 const items=['不愿意认识','不愿意表达','不愿意线上聊天','觉得自己不会聊天'];
 const idx=Math.min(3,Math.floor(range(t,T.start+1,T.choice-.5)*4));
 items.forEach((s,i)=>{const a=reveal(local,.75+i*.28,.6);dot(c,99,520+i*66,4,i===idx?ink:'#a2ada5');txt(c,s,121,530+i*66,27,i===idx?ink:'#7b887e','StrataSans','left',a)});
 // A single small message crosses the open threshold, with its track attached to the door.
 const motion=reveal(t,T.choice+2.1,2.1);const ps:P[]=[];for(let i=0;i<=90;i++){const u=i/90;ps.push(bez({x:xr-1,y:703},{x:xr+2,y:841},{x:xr-380,y:865},{x:xr-460,y:904},u))}
 trace(c,ps,motion,lime,5);if(motion>0){const q=ps[Math.round(motion*90)];shadow(c,q.x,q.y+8,22,8,.15);dot(c,q.x,q.y,10,lime,ink)}
 if(t>T.choice+3.3){pill(c,'你好',xr-85,cy+65,ink,lime,27)}
 txt(c,'选择先于技巧',87,894,27,ink,'StrataBold','left',reveal(t,T.choice+3.6,.9));
}
export function expression(c:C,t:number){
 bg(c,true);mast(c,3,true);chapter(c,'02','表达','让交流留出回应的空间。',true);
 const local=t-chapters[2].time;const comp=reveal(t,T.competition-.3,1.2),settle=reveal(t,T.pace-.35,1.1);
 const left={x:720,y:535},right={x:1705,y:535};
 const phrase=['害怕开始','太急','退出竞争 / 虚假竞争','错误认知'];
 phrase.forEach((s,i)=>{const a=reveal(local,1+i*.28,.65);txt(c,s,89,541+i*66,27,i===1?lime:'#a8b8ad','StrataSans','left',a)});
 // The visible channel compresses when requests overtake one another, then opens out.
 const channelY=535;const gap=mix(64,194,settle);
 for(let k=0;k<4;k++){
  const base=970+k*gap;const y=channelY+(1-settle)*Math.sin(k*1.3)*35;
  const x=mix(720,base,reveal(local,.9+k*.25,1.7));
  const alpha=(1-comp*.5);c.save();c.globalAlpha*=alpha;
  round(c,x-60,y-43,122,86,18,k===0?lime:'#26372c','#667e64');txt(c,k===0?'提问':'再问',x,y+10,27,k===0?ink:'#c2d0c2','StrataBold','center');c.restore();
 }
 bezier(c,left,{x:960,y:340},{x:1460,y:350},right,settle>.5?lime:'#70876e',2,reveal(local,.7,1.4));
 if(settle>.01){const a=settle;bezier(c,right,{x:1460,y:742},{x:920,y:741},left,blue,3,a);const q=bez(right,{x:1460,y:742},{x:920,y:741},left,clamp((t-T.pace-.1)/2));dot(c,q.x,q.y,7,blue);txt(c,'回应',1205,758,30,blue,'StrataBold','center',a);txt(c,'留一点间距',1210,334,30,paper,'StrataBold','center',a)}
 if(comp>0&&settle<1){
  c.save();c.globalAlpha*=comp*(1-settle);
  // Imaginary race lines peel away from the real interlocutor instead of arriving at a trophy.
  const ps1=[],ps2=[];for(let i=0;i<=100;i++){const u=i/100;ps1.push({x:795+u*860,y:535-Math.sin(u*Math.PI)*165-u*230});ps2.push({x:795+u*860,y:535+Math.sin(u*Math.PI)*140+u*170})}
  trace(c,ps1,range(t,T.competition+.3,T.competition+2.5),'#6f7f77',1.8);trace(c,ps2,range(t,T.competition+.5,T.competition+2.8),'#53665b',1.8);
  txt(c,'想象中的输赢',1560,240,25,'#97a59d','StrataSans','center');txt(c,'提前退出',1485,805,25,'#89998e','StrataSans','center');
  line(c,[{x:1660,y:465},{x:1660,y:607}],paper,1,.5);txt(c,'眼前的人',1660,655,29,paper,'StrataBold','center');c.restore();
 }
 const caution=1-settle;line(c,[{x:848,y:420},{x:848,y:650}],coral,4,caution*.7);
 txt(c,settle>.5?'不只有话术，还有节奏。':'越急，留给回应的空间越少。',1220,897,35,settle>.5?lime:'#bac9bc','StrataBold','center',reveal(local,1.2,1));
}
export function skills(c:C,t:number){
 bg(c);mast(c,4);const local=t-chapters[3].time;
 const photo=reveal(t,T.photo-.35,1.2),question=reveal(t,T.question-.4,1.1),answer=reveal(t,T.response+.4,1.1),initiative=reveal(t,T.initiative-.25,1.1);
 const macro=reveal(t,T.photo-.4,.95)*(1-reveal(t,T.question-.6,1.4));
 const x=mix(1245,1030,photo),y=mix(542,530,photo),r=mix(200,190,photo)+macro*65;
 chapter(c,'03','能力','把技巧拆成可以练习的动作。');
 // Before the concrete example, a set of routes grows out of one stable hub.
 const skills=['不会开场','不会接话','不会制造话题','不会应对话题'];
 skills.forEach((s,i)=>{const a=reveal(local,.9+i*.35,.75);txt(c,s,90,535+i*66,27,i===1?ink:'#738176','StrataSans','left',a*(1-photo));});
 shadow(c,x+3,y+225,310,48,.17);
 if(photo<1){
  c.save();c.globalAlpha*=1-photo;metalCircle(c,x,y,r,lime);txt(c,'一个回应',x,y+12,44,paper,'StrataBold','center');
  for(let j=0;j<4;j++){const a=-Math.PI/2+j*Math.PI/2;const q={x:x+Math.cos(a)*310,y:y+Math.sin(a)*260};bezier(c,{x:x+Math.cos(a)*r,y:y+Math.sin(a)*r},{x:q.x,y:y},{x:q.x,y:q.y},q,ink,2,reveal(local,.7+j*.3,1.2));dot(c,q.x,q.y,5,ink)}c.restore();
 }
 if(photo>0){
  c.save();c.globalAlpha*=photo;coast(c,x,y,r,t);txt(c,'同一张海边照片',x,y+r+72,30,ink,'StrataBold','center');
  const pp=reveal(t,T.photo+.8,.8)*(1-question);if(pp>0){c.save();c.globalAlpha*=pp;bezier(c,{x:x+r*.8,y:y-r*.5},{x:1400,y:230},{x:1545,y:230},{x:1590,y:282},'#8c9c91',2,1,true);txt(c,'喜欢旅游？',1580,252,34,'#6a7c71','StrataSans','center');txt(c,'一种可能，不是结论',1580,302,23,'#7e8e84','StrataSans','center');c.restore()}
  if(question>0){
   const p1=reveal(t,T.question+.15,1.05),p2=reveal(t,T.question+1.6,1.05);const top={x:1570,y:345},bottom={x:1570,y:685};
   bezier(c,{x:x+r*.87,y:y-r*.3},{x:1390,y:405},{x:1340,y:345},top,answer>.5?'#a9b5ac':ink,2,p1);
   bezier(c,{x:x+r*.87,y:y+r*.3},{x:1375,y:600},{x:1365,y:685},bottom,answer>.5?blue:ink,answer>.5?4:2,p2);
   dot(c,top.x,top.y,7,answer>.5?'#a9b5ac':ink);dot(c,bottom.x,bottom.y,7,answer>.5?blue:ink);
   txt(c,'风景',top.x+35,top.y+12,43,answer>.5?'#8a9b8e':ink,'StrataBold','left',p1);
   txt(c,'拍照的过程',bottom.x-55,bottom.y+69,40,answer>.5?'#4c63c4':ink,'StrataBold','left',p2);
   txt(c,'还是',1503,522,27,'#7d8e82','StrataSans','left',question);
   if(answer>0){
    pill(c,'假设回答：我更喜欢拍照',1270,845,ink,'#c9d2ef',24);const q=bez({x:x+r*.87,y:y+r*.3},{x:1375,y:600},{x:1365,y:685},bottom,answer);dot(c,q.x,q.y,8,blue);
    txt(c,'摄影',1740,896,30,'#4c63c4','StrataBold','center',reveal(t,T.response+1.7,.7));
    const q3={x:1740,y:847};bezier(c,bottom,{x:1570,y:780},{x:1650,y:760},q3,blue,2,reveal(t,T.response+1.2,1));
   }
  }
  c.restore();
 }
 // All nine original items are present. The last five form feedback loops, not a ladder of romantic success.
 if(photo>.8){
  const a=reveal(t,T.photo-.1,.7);c.save();c.globalAlpha*=a;
  txt(c,'看见线索',90,529,30,ink,'StrataBold');txt(c,'提出开放的问题',90,589,30,question>.5?ink:'#9aa79c','StrataBold');txt(c,'沿实际回应继续',90,649,30,answer>.5?ink:'#9aa79c','StrataBold');
  line(c,[{x:94,y:680},{x:422,y:680}],'#94a698',1,.6);txt(c,'示例不是判断公式',90,724,23,'#738678');c.restore();
 }
 if(initiative>0){
  c.save();c.globalAlpha*=initiative;
  // A wide feedback band enters the lower space without replacing the photo or its branch.
  round(c,78,805,1075,135,22,'#d7e0d5');
  const ss=['不敢表达','不会主动','不知道什么时候主动','不会推进关系'];
  ss.forEach((s,i)=>{const xx=104+[0,184,367,710][i];txt(c,s,xx,859,25,ink,'StrataBold');});
  txt(c,'观察双方反馈，而非机械推进',108,909,24,'#5d7360');bezier(c,{x:1077,y:876},{x:1220,y:884},{x:1230,y:572},{x:x+r,y:y+7},'#70836d',1.5,initiative,true);
  c.restore();
 }
 txt(c,'开场  /  接话  /  制造话题  /  应对话题',90,925,20,'#87968b','StrataSans','left',1-photo);
}
export function matching(c:C,t:number){
 bg(c,true);mast(c,5,true);const local=t-chapters[4].time;chapter(c,'04','匹配','差异不是分数，关系也不是排名。',true);
 const talk=reveal(t,T.compatibility-.2,1.5),boundary=reveal(t,T.boundary-.3,1.2);
 const cx1=mix(1090,1185,talk),cx2=mix(1530,1430,talk),cy=535;
 // Two distinct contour fields retain their own shape while exploring a shared region.
 const radius=mix(205,214,talk);shadow(c,1330,818,410,54,.3);
 sculpture(c,cx1,cy+3,1.08,.25,-.45+Math.min(local,9)*.012,[120,148,113]);
 sculpture(c,cx2,cy+3,1.08,1.7,.35-Math.min(local,9)*.012,[100,119,174]);
 txt(c,'你',cx1-80,cy+225,23,'#c6d7bf','StrataSans','center');
 txt(c,'对方',cx2+80,cy+225,23,'#bdc9ed','StrataSans','center');
 // Fine center lines show a real overlap without turning it into a compatibility score.
 const shared=reveal(t,T.compatibility+1.4,1.4);if(shared>0){
  const xx=(cx1+cx2)/2;
  line(c,[{x:cx1+40,y:cy+45},{x:xx,y:cy+75},{x:cx2-40,y:cy+45}],lime,2,shared);
  dot(c,xx,cy+75,6,lime);
  txt(c,'相处中的交集',xx,cy+145,27,paper,'StrataBold','center',shared);

 }
 const ss=['颜值','穿搭','资金 / 现实条件','性格','门当户对','人对人兼容性'];
 ss.forEach((s,i)=>{const p=reveal(local,.8+i*.31,.65);const xx=i%2===0?970:1570;const yy=[240,240,819,819,903,903][i];const a=i%2===0?-1:1;line(c,[{x:xx,y:yy+12},{x:xx,y:yy+(yy<500?58:-52)},{x:xx-a*45,y:yy+(yy<500?77:-69)}],i<4?'#57685a':'#788c78',1,p);txt(c,s,xx,yy,25,i>=4?paper:'#a8baa8','StrataSans','center',p)});
 txt(c,'不是人的价值排行榜',89,556,30,lime,'StrataBold','left',talk);
 txt(c,'也不是努力就能通关',89,617,27,'#b2c4b0','StrataSans','left',reveal(t,T.boundary-.2,1));
 if(boundary>0){
  c.save();c.globalAlpha*=boundary;round(c,85,749,517,135,20,'#1d2920','#455844');txt(c,'聊得顺 ≠ 一定合适',112,805,31,paper,'StrataBold');txt(c,'不合适 ≠ 谁不够好',112,853,31,lime,'StrataBold');c.restore();
 }
 txt(c,'概念示意 · 两个人都保留选择的空间',1310,965,25,'#9caf9b','StrataSans','center',reveal(t,T.boundary+.8,1));
}
export function ending(c:C,t:number){
 bg(c);mast(c,6);const local=t-chapters[5].time;const end=reveal(t,T.end-.45,1.3);
 txt(c,'别把所有问题，',85,239,60,ink,'StrataBold');txt(c,'都叫「不会聊天」。',79,345,89,ink,'StrataBold');
 const cam:Camera={cx:1310,cy:530,scale:.77,yaw:mix(-.44,-.2,reveal(local,0,2.2)),tilt:.58};strata(c,Math.min(t,T.end),cam,1,false);
 const prompts=['要不要开始？','表达节奏如何？','具体动作缺在哪？','彼此是否合适？'];
 for(let j=0;j<4;j++){
  const a=reveal(local,.5+j*.28,.8),yy=484+j*77;dot(c,99,yy-9,5,palette[j],ink);line(c,[{x:124,y:yy-9},{x:187,y:yy-9}],palette[j],3,a);txt(c,`0${j+1}`,209,yy-2,22,'#7d8a80');txt(c,prompts[j],270,yy,37,ink,'StrataSans','left',a);
 }
 txt(c,'先看卡在哪里，再决定练什么。',87,878,37,ink,'StrataBold','left',reveal(local,2,1));
 // The final phrase is a held conclusion; it is not covered by unnecessary motion.
 if(end>0){
  c.save();c.globalAlpha*=end;round(c,772,820,1057,135,20,ink);txt(c,'看清问题，才有选择。',1300,907,53,lime,'StrataBold','center');c.restore();
 }
 txt(c,'四类问题是观察框架，并非科学分级或个人价值排序。',87,952,21,'#728176');
}
export const renderers=[opening,start,expression,skills,matching,ending];
export const darkness=[false,false,true,false,true,false];
export function transition(c:C,idx:number,t:number,startTime:number){
 const p=io(range(t,startTime-.9,startTime+.55));const prev=renderers[idx-1],next=renderers[idx];
 // Different transitions follow the object that carries the explanation.
 if(idx===1){
  // Camera tracks across a floor edge into the first gate.
  c.save();c.beginPath();c.rect(0,0,1920,1080);c.clip();c.translate(-p*1920,0);prev(c,t);c.restore();c.save();c.translate((1-p)*1920,0);next(c,t);c.restore();
  line(c,[{x:mix(1800,-120,p),y:939},{x:mix(2040,120,p),y:939}],lime,4,.6);
 }else if(idx===2){
  // Open doorway becomes the aperture to the communication channel.
  prev(c,t);const w=1920*p,h=1080*p;const x=mix(1470,960,p),y=mix(530,540,p);c.save();c.beginPath();c.roundRect(x-w/2,y-h/2,w,h,24*(1-p));c.clip();next(c,t);c.restore();
 }else if(idx===3){
  // One response packet widens into the circular topic hub.
  prev(c,t);const rr=p*2100;c.save();c.beginPath();c.arc(1225,535,rr,0,Math.PI*2);c.clip();next(c,t);c.restore();
 }else if(idx===4){
  // The circular photograph becomes the contour field of two independent people.
  prev(c,t);const rr=p*2050;c.save();c.beginPath();c.arc(1030,530,rr,0,Math.PI*2);c.clip();next(c,t);c.restore();
 }else{
  // The relation plane folds upward, exposing the complete structure once more.
  c.save();c.translate(0,-p*1080);prev(c,t);c.restore();c.save();c.translate(0,(1-p)*1080);next(c,t);c.restore();
 }
}
