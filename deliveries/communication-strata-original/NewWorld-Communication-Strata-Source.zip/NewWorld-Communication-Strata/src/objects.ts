import {type C,type Camera,ink,paper,lime,blue,coral,palette,txt,line,path,dot,solids,project,worldLine,shadow} from './draw';
import {mix,smooth,range,clamp,reveal,type V,type P} from './math';
export function strata(c:C,t:number,cam:Camera,spread=1,labels=false,focus=-1){
 const pending:{x:number,y:number,col:string,label:string}[]=[];
 const ys=[-225,-75,75,225].map(y=>y*mix(.16,1,spread));
 shadow(c,cam.cx,cam.cy+320*cam.scale,390*cam.scale,70*cam.scale,.22);
 for(let j=0;j<4;j++){
  const y=ys[j],col=palette[j];
  const p=(x:number,z:number,dy=20)=>project({x,y:y+dy,z},cam);
  if(j>0)worldLine(c,[{x:0,y:ys[j-1]+21,z:0},{x:0,y:y-21,z:0}],cam,'#8e9d94',1,.5);
  const shift=focus<0||j===focus?0:mix(0,90,spread)*(j<focus?-1:1);
  const active=focus<0||focus===j;
  c.save();c.globalAlpha*=active?1:.28;
  solids(c,[{x:shift,y,z:0,w:580,h:38,d:350,top:'#29332d',front:'#121a16',side:'#1b241e',edge:active?'#72806e':'#526155'}],cam);
  // Three fine engraved loops travel on the plane: explicitly anchored to each layer.
  for(let ring=2;ring<3;ring++){
   const ps=[];for(let k=0;k<=120;k++){const a=k/120*Math.PI*2;const r=ring*25+65;ps.push(p(shift+Math.cos(a)*r*1.6,Math.sin(a)*r*.88))}
   line(c,ps,ring===2&&active?col:'#6c7c6a',ring===2?1.6:.8,ring===2?.85:.42);
  }
  // Per-layer functional marks rather than decorative particles.
  // Four distinct mechanisms are engraved on the four physical planes.
  const wl=(vs:{x:number,z:number}[],color=col,width=1.6)=>line(c,vs.map(v=>p(v.x+shift,v.z)),color,width,.9);
  if(j===0){
   wl([{x:-130,z:0},{x:-28,z:0}]);wl([{x:28,z:0},{x:130,z:0}]);
   wl([{x:-25,z:-48},{x:-25,z:48}],'#9cb591',2.2);wl([{x:25,z:-48},{x:25,z:48}],'#9cb591',2.2);
  }else if(j===1){
   const ps=[];for(let k=0;k<=60;k++){const u=k/60;ps.push({x:-150+u*300,z:Math.sin(u*Math.PI)*55})}wl(ps);
   wl(ps.map(v=>({x:v.x,z:-v.z})),blue);
  }else if(j===2){
   for(const z of [-72,0,72]){const ps=[];for(let k=0;k<=40;k++){const u=k/40;ps.push({x:-90+u*235,z:z*(3*u*u-2*u*u*u)})}wl(ps)}
   const q=p(-90+shift,0);dot(c,q.x,q.y,3.7*cam.scale,col);
  }else{
   for(const xx of [-45,45]){const ps=[];for(let k=0;k<=80;k++){const a=k/80*Math.PI*2;ps.push({x:xx+Math.cos(a)*85,z:Math.sin(a)*63})}wl(ps,xx<0?lime:blue,1.4)}
  }
  const nodes=4+j;for(let k=0;k<nodes;k++){const a=k/nodes*Math.PI*2+.22;const q=p(shift+Math.cos(a)*220,Math.sin(a)*118);dot(c,q.x,q.y,2.8*cam.scale,active?col:'#788477')}
  const front=[p(-272+shift,155),p(272+shift,155)];line(c,front,col,2,active?.85:.2);
  const upper=[p(-272+shift,-155),p(272+shift,-155)];line(c,upper,'#a5b49f',.7,.65);
  const q=p(shift-230,115);txt(c,`0${j+1}`,q.x,q.y,19*cam.scale,col,'StrataBold');
  const prog=(Math.min(t,16)*.13+j*.21)%1;const a=prog*Math.PI*2;const head=p(shift+Math.cos(a)*185,Math.sin(a)*100);dot(c,head.x,head.y,4*cam.scale,col);
  if(labels){const q=p(shift+290,0);pending.push({x:q.x,y:q.y,col,label:['开始','表达','能力','匹配'][j]})}
  c.restore();
 }
 for(const q of pending){line(c,[q,{x:q.x+65,y:q.y},{x:q.x+90,y:q.y-22}],q.col,1.5);txt(c,q.label,q.x+101,q.y-16,27,ink,'StrataBold')}
}
export function portal(c:C,cx:number,cy:number,open:number,scale=1,col=lime){
 c.save();c.translate(cx,cy);c.scale(scale,scale);shadow(c,12,310,260,50,.22);
 const bevel=19;const x=-170,y=-245,w=340,h=510;
 // Edge planes and a recessed opening preserve depth when the doors move.
 path(c,[{x:x-24,y:y-20},{x:x+w+24,y:y-20},{x:x+w+54,y:y+8},{x:x+5,y:y+8}],'#4e5a50','#7a897b');
 path(c,[{x:x+w+24,y:y-20},{x:x+w+54,y:y+8},{x:x+w+54,y:y+h+24},{x:x+w+24,y:y+h}],'#0c130e','#445044');
 const g=c.createLinearGradient(-200,-250,200,250);g.addColorStop(0,'#222e23');g.addColorStop(.55,'#121b15');g.addColorStop(1,'#566852');c.fillStyle=g;c.fillRect(x-24,y-20,w+48,h+40);
 c.fillStyle='#070d09';c.fillRect(x+bevel,y+bevel,w-2*bevel,h-bevel);
 for(let i=0;i<5;i++){c.strokeStyle=`rgba(177,204,151,${.08+i*.01})`;c.lineWidth=1;c.strokeRect(x+bevel+i*10,y+bevel+i*10,w-2*bevel-i*20,h-bevel-i*10)}
 const move=open*140;for(let side of [-1,1]){const dx=side<0?x+bevel-move:0+move;c.save();c.beginPath();c.rect(x+bevel,y+bevel,w-2*bevel,h-bevel);c.clip();const g2=c.createLinearGradient(dx,y,dx+151,y);g2.addColorStop(0,'#3a473c');g2.addColorStop(.5,'#29392d');g2.addColorStop(1,'#121d14');c.fillStyle=g2;c.fillRect(dx,y+bevel,151,h-bevel);c.strokeStyle='#6e8369';c.strokeRect(dx,y+bevel,151,h-bevel);c.restore()}
 line(c,[{x:0,y:y+22},{x:0,y:y+h-5}],col,1.5,1-open);line(c,[{x:-170,y:270},{x:170,y:270}],col,2,.7);c.restore();
}
export function contour(c:C,cx:number,cy:number,r:number,phase:number,col:string,rotation=0,progress=1){
 const ps:P[]=[];for(let i=0;i<=180*progress;i++){const a=i/180*Math.PI*2+rotation;const rr=r*(1+.12*Math.cos(3*a+phase)+.055*Math.sin(5*a-phase));ps.push({x:cx+Math.cos(a)*rr,y:cy+Math.sin(a)*rr})}line(c,ps,col,1.5,1);
}
export function coast(c:C,x:number,y:number,r:number,t:number){
 c.save();c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.clip();const g=c.createLinearGradient(x-r,y-r,x+r,y+r);g.addColorStop(0,'#789caa');g.addColorStop(.58,'#3d727e');g.addColorStop(1,'#17383f');c.fillStyle=g;c.fillRect(x-r,y-r,2*r,2*r);
 // Aerial coastline: repeating moving contours reveal a stable photographic anchor.
 const shore=(offset:number)=>{const ps:P[]=[];for(let i=0;i<=90;i++){const a=i/90;ps.push({x:x-r+a*2*r,y:y-r*.4+Math.sin(a*4.6+1)*r*.45+a*r*.62+offset})}return ps};
 for(let i=0;i<9;i++){line(c,shore(i*20-110+(t*.8)%20),'#b5d5cc',i===5?3:1,.12+i*.025)}
 const land=shore(40);path(c,[...land,{x:x+r,y:y+r},{x:x-r,y:y+r}],'#c1c8b4');line(c,land,'#eef4df',4,.8);line(c,shore(52),'#657b6e',2,.4);
 for(let i=0;i<20;i++){const a=i*.46;const px=x-r+((i*47)%Math.round(2*r)),py=y+r*.45+Math.sin(a)*r*.4;line(c,[{x:px,y:py},{x:px+25,y:py+3}],'#71816d',.8,.35)}
 c.restore();c.beginPath();c.arc(x,y,r+7,0,Math.PI*2);c.strokeStyle='#9bada5';c.lineWidth=1;c.stroke();
}
