import React from 'react';
import {Composition,registerRoot,Folder} from 'remotion';
import {Film} from './Film';
import settings from './settings.json';
import chapters from './chapters.json';
const Root=()=> <>
 <Composition id="CommunicationStrata" component={Film} durationInFrames={settings.frames} fps={30} width={1920} height={1080}/>
 <Folder name="Editable-Chapters">
  <Composition id="01-Opening" component={Film} defaultProps={{scene:0}} durationInFrames={chapters[1].frame} fps={30} width={1920} height={1080}/>
  <Composition id="02-Start" component={Film} defaultProps={{scene:1}} durationInFrames={chapters[2].frame-chapters[1].frame} fps={30} width={1920} height={1080}/>
  <Composition id="03-Expression" component={Film} defaultProps={{scene:2}} durationInFrames={chapters[3].frame-chapters[2].frame} fps={30} width={1920} height={1080}/>
  <Composition id="04-Skills" component={Film} defaultProps={{scene:3}} durationInFrames={chapters[4].frame-chapters[3].frame} fps={30} width={1920} height={1080}/>
  <Composition id="05-Matching" component={Film} defaultProps={{scene:4}} durationInFrames={chapters[5].frame-chapters[4].frame} fps={30} width={1920} height={1080}/>
  <Composition id="06-Choice" component={Film} defaultProps={{scene:5}} durationInFrames={settings.frames-chapters[5].frame} fps={30} width={1920} height={1080}/>
 </Folder>
</>;
registerRoot(Root);
