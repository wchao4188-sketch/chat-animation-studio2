import {type C,project,type Camera,shadow,line} from './draw';
import {type V,clamp} from './math';
type Vertex=V&{u:number,a:number};
const cross=(a:V,b:V):V=>({x:a.y*b.z-a.z*b.y,y:a.z*b.x-a.x*b.z,z:a.x*b.y-a.y*b.x});
const sub=(a:V,b:V):V=>({x:a.x-b.x,y:a.y-b.y,z:a.z-b.z});
const norm=(v:V)=>{const d=Math.hypot(v.x,v.y,v.z)||1;return{x:v.x/d,y:v.y/d,z:v.z/d}};
// A deterministic, shaded parametric surface. No stock render, particle overlay or random motion.
export function sculpture(c:C,cx:number,cy:number,scale:number,phase:number,rotation:number,tint:[number,number,number]){
 const cam:Camera={cx,cy,scale,yaw:rotation,tilt:.83,focal:1900};
 const mesh:Vertex[][]=[];const rings=38,segs=160;
 const point=(u:number,a:number):Vertex=>{const rad=235*u*(1+.12*Math.cos(3*a+phase)+.045*Math.sin(5*a-phase));return{x:Math.cos(a)*rad,y:46*Math.sin(u*Math.PI*1.5+phase*.55)+52*Math.cos(3*a+phase)*u**1.5+18*Math.sin(6*a)*u**3,z:Math.sin(a)*rad,u,a}};
 for(let r=0;r<=rings;r++){mesh[r]=[];for(let j=0;j<=segs;j++)mesh[r].push(point(r/rings,j/segs*Math.PI*2))}
 const triangles:{ps:ReturnType<typeof project>[],color:string,depth:number}[]=[];
 const light=norm({x:-.5,y:.9,z:.35}),view=norm({x:.1,y:.85,z:.6});
 const half=norm({x:light.x+view.x,y:light.y+view.y,z:light.z+view.z});
 for(let r=0;r<rings;r++)for(let j=0;j<segs;j++){
  for(let k=0;k<2;k++){
   const vs=k===0?[mesh[r][j],mesh[r+1][j],mesh[r+1][j+1]]:[mesh[r][j],mesh[r+1][j+1],mesh[r][j+1]];
   let n=norm(cross(sub(vs[1],vs[0]),sub(vs[2],vs[0])));if(n.y<0)n={x:-n.x,y:-n.y,z:-n.z};
   const diff=Math.max(0,n.x*light.x+n.y*light.y+n.z*light.z);const spec=Math.pow(Math.max(0,n.x*half.x+n.y*half.y+n.z*half.z),30);
   const u=vs.reduce((s,v)=>s+v.u,0)/3;const v=.24+.68*diff;const rgb=tint.map(ch=>Math.round(clamp(ch*v+spec*130+u*5,0,255)));
   const ps=vs.map(p=>project(p,cam));triangles.push({ps,color:`rgb(${rgb.join(',')})`,depth:ps.reduce((s,p)=>s+p.dep,0)});
  }
 }
 shadow(c,cx,cy+scale*200,270*scale,38*scale,.25);triangles.sort((a,b)=>a.depth-b.depth);
 for(const tri of triangles){c.beginPath();tri.ps.forEach((p,i)=>i?c.lineTo(p.x,p.y):c.moveTo(p.x,p.y));c.closePath();c.fillStyle=tri.color;c.fill();c.strokeStyle=tri.color;c.lineWidth=.65;c.stroke()}
 // Isocurves follow the actual warped surface, not circles pasted on top.
 for(let r=2;r<=rings;r+=2){const vs=[];for(let j=0;j<=segs;j++)vs.push(project(point(r/rings,j/segs*Math.PI*2),cam));line(c,vs,r===rings?'#c6d6c0':`rgba(${tint.map(ch=>Math.min(255,ch+80)).join(',')},.45)`,r===rings?1.5:.7,.65)}
}
