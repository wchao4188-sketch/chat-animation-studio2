# 新世界｜别把所有问题，都叫「不会聊天」

原创动态知识动画。依据用户给出的思维导图，区分开始、表达、聊天能力、条件与匹配四类问题。分类是观察框架，不是经过验证的心理分级；形状和路径是视觉隐喻，不是好感或个人价值评分。

## 播放与编辑

- 完整视频单独交付：`NewWorld-Communication-Strata.mp4`。源工程 ZIP 不重复包含 MP4。
- 工程：Remotion 4.0.536 + React 19.2.4 + TypeScript 5.9.3。
- 规格：1920×1080，16:9，30 fps。精确时长/帧数在 `src/settings.json`。
- 在工程目录运行 `npm ci`，再运行 `npm run studio`。Studio 中有整片及六个可单独预览的章节。
- `npm run typecheck` 检查类型，`npm run render` 渲染并使用 FFmpeg 封装精确时长。
- 已在 Node 24.19.0、Chromium 154、FFmpeg 7.1.5 的 Linux 环境实际运行。渲染脚本当前使用 `/usr/bin/chromium`，其他系统需改为本机 Chromium 路径；未验证 Windows 渲染。

## 改哪里

- `src/scenes.ts`：六段内容的布局、物体和帧驱动动画。
- `src/objects.ts`：立体层板、门、海岸线；`sculpture.ts`：有光照的参数曲面。
- `src/draw.ts`：绘图、字体、色彩、三维投影。不是静态截图拼接，无实时随机动画。
- `src/Film.tsx`：场景衔接、中文字幕、音轨。
- `assets/script.json`：本片原创旁白；`src/timeline.json`：实际生成的配音起止时间。
- `src/chapters.json`：章节/音乐事件到帧；`output/music-analysis.json`：实际音乐分析。
- `public/audio`：配音分句、旁白/音乐/音效分轨、总混音。改视觉不需要重新生成声音。

## 素材与依赖

视觉全部由本工程代码生成，没有使用此前参考视频、旧成片截图或外部人物图像。中文字体为本地 Noto CJK 子集，许可见 `assets/Font-LICENSE.txt`。

音乐沿用用户上传的 `mmexport1792300994359.mp3` 中现有 AAC 音轨（实际容器是 MP4）。使用片段和 SHA-256 见音乐分析文件。

配音为本地 Kokoro 中文合成声线 `zm_yunjian`（sid 49），通过 sherpa-onnx 1.12.35 实际生成。模型来源、压缩包校验见 `assets/voice-model.json`，许可见 `assets/Kokoro-LICENSE.txt`。模型大文件不包含在工程 ZIP 内；已经包含可渲染的配音，重渲染无需模型。重新生成旁白时，将官方模型放到 `scripts/voice.py` 的 `P` 路径，使用带 sherpa-onnx / NumPy 的 Python 环境运行。该脚本不是 `npm run render` 的前置步骤。

音效是本地确定性合成的开合、轨迹和到达声，不冒充真实录音。未新增 npm 依赖。语音模型是本轮唯一新增的大型制作资产。

## 验证与限制

实际检查记录在 `output/Acceptance.md`、`quality-check.json`、`playback-check.json`、`narration-asr.json` 中。自动识别不是人工试听；视觉审查和技术检查也不保证主观审美。不同机器的字体栅格/视频编码可能存在微小差异。
