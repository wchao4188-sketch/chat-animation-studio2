import React,{useEffect,useRef,useState} from 'react';
import {AbsoluteFill,continueRender,delayRender,staticFile,useCurrentFrame} from 'remotion';
import {Audio} from '@remotion/media';
import {drawFrame,prepare} from './scene';
export const Film=()=>{
 const frame=useCurrentFrame(),ref=useRef<HTMLCanvasElement>(null);
 const [handle]=useState(()=>delayRender('Load local Chinese fonts and sample glyphs'));
 const [ready,setReady]=useState(false);
 useEffect(()=>{let live=true;const a=new FontFace('BowlSans',`url(${staticFile('fonts/BowlSans.woff')})`),b=new FontFace('BowlDisplay',`url(${staticFile('fonts/BowlDisplay.woff')})`);Promise.all([a.load(),b.load()]).then(fonts=>{fonts.forEach(f=>(document.fonts as FontFaceSet & {add:(f:FontFace)=>void}).add(f));prepare();if(live){setReady(true)}}).catch(e=>{console.error(e);throw e});return()=>{live=false}},[handle]);
 useEffect(()=>{if(ready&&ref.current){const c=ref.current.getContext('2d');if(c){drawFrame(c,frame);continueRender(handle)}}},[frame,ready,handle]);
 return <AbsoluteFill style={{background:'#0c1014'}}><canvas ref={ref} width={1920} height={1080} style={{width:1920,height:1080}}/><Audio src={staticFile('audio/master.wav')}/></AbsoluteFill>
};
