import {hash,lerp,phase} from './math';
export type V={x:number;y:number;z:number};
export type BowlPose={x:number;y:number;s:number;pitch:number;yaw:number;roll:number};
type Face={p:V[];n:V;z:number};
const controls=[[0,-100],[51,-100],[66,-91],[80,-88],[111,-68],[146,-30],[181,19],[208,68],[211,76],[203,80],[198,71],[177,26],[144,-20],[108,-57],[76,-75],[38,-81],[0,-81]];
const profile:Array<{r:number;y:number;dr:number;dy:number}>=[];
for(let i=0;i<controls.length-1;i++)for(let j=0;j<3;j++){
 const t=j/3,p0=controls[Math.max(0,i-1)],p1=controls[i],p2=controls[i+1],p3=controls[Math.min(controls.length-1,i+2)];
 const v=(k:number)=>.5*((2*p1[k])+(-p0[k]+p2[k])*t+(2*p0[k]-5*p1[k]+4*p2[k]-p3[k])*t*t+(-p0[k]+3*p1[k]-3*p2[k]+p3[k])*t*t*t);
 const d=(k:number)=>.5*((-p0[k]+p2[k])+2*(2*p0[k]-5*p1[k]+4*p2[k]-p3[k])*t+3*(-p0[k]+3*p1[k]-3*p2[k]+p3[k])*t*t);
 profile.push({r:Math.max(0,v(0)),y:v(1),dr:d(0),dy:d(1)});
}
profile.push({r:0,y:-81,dr:-30,dy:0});
export function rot(v:V,p:BowlPose):V{let {x,y,z}=v;const a=p.yaw,b=p.pitch,c=p.roll;[x,z]=[x*Math.cos(a)+z*Math.sin(a),-x*Math.sin(a)+z*Math.cos(a)];[y,z]=[y*Math.cos(b)-z*Math.sin(b),y*Math.sin(b)+z*Math.cos(b)];[x,y]=[x*Math.cos(c)-y*Math.sin(c),x*Math.sin(c)+y*Math.cos(c)];return{x,y,z}}
export const project=(v:V,p:BowlPose)=>{const w=rot(v,p),q=1+w.z/1800;return{x:p.x+w.x*p.s*q,y:p.y-w.y*p.s*q,z:w.z}};
export function bowlPose(f:number):BowlPose{const move=phase(f,85,110);return{x:lerp(1370,385,move),y:lerp(560,590,move),s:lerp(1.42,1.03,move),pitch:lerp(.62,.88,phase(f,41,155)),yaw:lerp(-.62,.85,phase(f,42,165)),roll:lerp(-.08,.075,phase(f,50,156))}}
export function surfacePoint(n:number,p:BowlPose){const k=8+Math.floor(hash(n+33)*32),q=profile[k],a=hash(n+81)*Math.PI*2;return project({x:q.r*Math.cos(a),y:q.y,z:q.r*Math.sin(a)},p)}
export function drawBowl(ctx:CanvasRenderingContext2D,p:BowlPose,dirty=false,water=true){
 ctx.save();const faces:Face[]=[];const N=96;
 for(let k=0;k<profile.length-1;k++)for(let j=0;j<N;j++){
  const a=j/N*Math.PI*2,b=(j+1)/N*Math.PI*2,u=profile[k],v=profile[k+1],mid=(a+b)/2;
  const normal=rot({x:u.dy*Math.cos(mid),y:-u.dr,z:u.dy*Math.sin(mid)},p);const norm=Math.hypot(normal.x,normal.y,normal.z)||1;const n={x:normal.x/norm,y:normal.y/norm,z:normal.z/norm};if(n.z<-.08)continue;
  const pts=[{x:u.r*Math.cos(a),y:u.y,z:u.r*Math.sin(a)},{x:v.r*Math.cos(a),y:v.y,z:v.r*Math.sin(a)},{x:v.r*Math.cos(b),y:v.y,z:v.r*Math.sin(b)},{x:u.r*Math.cos(b),y:u.y,z:u.r*Math.sin(b)}].map(q=>project(q,p));
  faces.push({p:pts,n,z:pts.reduce((s,q)=>s+q.z,0)/4});
 }
 faces.sort((a,b)=>a.z-b.z);
 for(const q of faces){const d=Math.max(0,-.34*q.n.x+.68*q.n.y+.65*q.n.z);const sp=Math.pow(Math.max(0,-.19*q.n.x+.38*q.n.y+.905*q.n.z),42);const v=87+143*d+30*sp;ctx.fillStyle=`rgb(${v*.91},${v*.955},${v})`;ctx.strokeStyle=ctx.fillStyle;ctx.lineWidth=.65;ctx.beginPath();q.p.forEach((a,i)=>i?ctx.lineTo(a.x,a.y):ctx.moveTo(a.x,a.y));ctx.closePath();ctx.fill();ctx.stroke();}
 // Thin glazed lip follows the same transformed geometry.
 ctx.beginPath();for(let j=0;j<=144;j++){const a=j/144*Math.PI*2,q=project({x:206*Math.cos(a),y:77,z:206*Math.sin(a)},p);j?ctx.lineTo(q.x,q.y):ctx.moveTo(q.x,q.y)}ctx.strokeStyle='#d8e5e6';ctx.globalAlpha=.64;ctx.lineWidth=2*p.s;ctx.stroke();ctx.globalAlpha=1;
 // A tiny maker's mark and surface droplets make axial rotation readable.
 for(let i=0;i<3;i++){const a=1.18+i*.055,q=project({x:174*Math.cos(a),y:9+i*4,z:174*Math.sin(a)},p);ctx.fillStyle='#4b626e';ctx.fillRect(q.x,q.y,3.5*p.s,13*p.s)}
 if(water)for(let i=0;i<12;i++){const a=.4+hash(i+7)*2.3,q=project({x:185*Math.cos(a),y:27+hash(i+12)*24,z:185*Math.sin(a)},p);const r=(2+hash(i+53)*3)*p.s;const g=ctx.createRadialGradient(q.x-r*.25,q.y-r*.35,.2,q.x,q.y,r);g.addColorStop(0,'#f6ffffbd');g.addColorStop(.38,'#9fbfc845');g.addColorStop(1,'#bed8e814');ctx.fillStyle=g;ctx.beginPath();ctx.ellipse(q.x,q.y,r*.7,r,0,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#d5e8ed77';ctx.lineWidth=.7;ctx.stroke();}
 if(dirty){for(let i=0;i<22;i++){const a=hash(i+331)*Math.PI*2,r=30+hash(i+101)*94,q=project({x:r*Math.cos(a),y:-59+r*.14,z:r*Math.sin(a)},p);ctx.strokeStyle=i%3?'#9b796977':'#af8d7288';ctx.lineWidth=(2+hash(i)*3)*p.s;ctx.beginPath();ctx.ellipse(q.x,q.y,(2+hash(i+2)*7)*p.s,(1+hash(i+5)*2)*p.s,-.4,0,Math.PI*1.7);ctx.stroke()}}
 ctx.restore();
}
