from pathlib import Path
import json,subprocess,wave,hashlib,re,tempfile
import numpy as np
import sherpa_onnx
from scipy.signal import find_peaks,fftconvolve
R=Path(__file__).resolve().parents[1];A=R/'public/audio';O=R/'output';sr=48000;N=sr*10
p=R.parent/'assets/models/vits-melo-tts-zh_en'
lex='\n'.join('碗 w an 2 2' if q.startswith('碗 ') else q for q in (p/'lexicon.txt').read_text().splitlines())
# Mandarin third-tone sandhi: wan3 xi3 is realized as wan2 xi3. Only a temporary copy is changed.
with tempfile.NamedTemporaryFile(mode='w',suffix='.txt',delete=False) as tmp:tmp.write(lex);lexfile=tmp.name
config=sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(vits=sherpa_onnx.OfflineTtsVitsModelConfig(model=str(p/'model.onnx'),lexicon=lexfile,tokens=str(p/'tokens.txt'),noise_scale=.1,noise_scale_w=.2),num_threads=2),rule_fsts=','.join(str(q) for q in sorted(p.glob('*.fst'))),max_num_sentences=1)
assert config.validate();tts=sherpa_onnx.OfflineTts(config);audio=tts.generate('碗洗了，为什么还在吵？',sid=0,speed=.92)
with wave.open(str(A/'voice-original.wav'),'wb') as w:w.setparams((1,2,audio.sample_rate,0,'NONE','not compressed'));w.writeframes((np.asarray(audio.samples).clip(-1,1)*32767).astype('<i2').tobytes())
subprocess.run(['ffmpeg','-v','error','-y','-i',str(A/'voice-original.wav'),'-af','highpass=f=75,loudnorm=I=-17:TP=-2:LRA=7','-ar',str(sr),'-ac','1',str(A/'voice.wav')],check=True)
def read(p,rate=sr,channels=1,duration=None):
 cmd=['ffmpeg','-v','error','-i',str(p)];cmd+=['-t',str(duration)] if duration else [];cmd+=['-ac',str(channels),'-ar',str(rate),'-f','f32le','-'];x=np.frombuffer(subprocess.check_output(cmd),np.float32);return x.reshape(-1,channels) if channels>1 else x
voice=read(A/'voice.wav');m=read(A/'user-music-source.m4a',channels=2,duration=10)[:N];mono=read(A/'user-music-source.m4a',rate=22050,duration=10)
win=1024;hop=256;spec=np.abs(np.fft.rfft(np.lib.stride_tricks.sliding_window_view(mono,win)[::hop]*np.hanning(win)));flux=np.maximum(np.diff(np.log1p(spec),axis=0),0).sum(axis=1);flux=(flux-flux.mean())/(flux.std()+1e-9);peaks,_=find_peaks(flux,prominence=1.15,distance=int(.32*22050/hop));times=(peaks*hop+win/2)/22050;ac=fftconvolve(flux,flux[::-1],mode='full')[len(flux)-1:];lags=np.arange(int(22050/hop*60/145),int(22050/hop*60/65));bpm=[]
for k in sorted(lags,key=lambda i:ac[i],reverse=True):
 val=60*22050/hop/k
 if all(abs(val-q['bpm'])>4 for q in bpm):bpm.append({'bpm':float(val),'autocorrelation_score':float(ac[k]/ac[0])})
 if len(bpm)==3:break
events=[('drop',1.30),('text-to-bowl',1.60),('bowl-translate',2.86),('stage1',3.66),('stage2',4.06),('stage3',4.64),('focus-stage1',5.55),('focus-text',6.73),('second-fusion',7.17),('reassembly',8.85)]
analysis={'source_sha256':hashlib.sha256((A/'user-music-source.m4a').read_bytes()).hexdigest(),'segment_seconds':[0,10],'method':'10-second spectral-flux onsets and autocorrelation; short-segment tempo estimates, not confirmed bar downbeats','bpm_candidates':bpm,'onsets':[{'seconds':round(float(t),4),'frame':round(float(t)*30),'strength':round(float(flux[k]),3)} for t,k in zip(times,peaks)],'events':[{'event':name,'frame':round(t*30),'nearest_onset_frame':round(float(times[np.argmin(abs(times-t))])*30),'difference_frames':round(t*30)-round(float(times[np.argmin(abs(times-t))])*30)} for name,t in events]}
(O/'music-analysis.json').write_text(json.dumps(analysis,ensure_ascii=False,indent=2))
t=np.arange(N)/sr;v=np.zeros(N);start=round(.10*sr);v[start:start+len(voice)]=voice;active=np.zeros(N);active[start:start+len(voice)]=1;duck=fftconvolve(active,np.ones(12001)/12001,mode='same');music=m*(.046/(np.sqrt(np.mean(m*m))+1e-9))*(1-.80*duck[:,None]);music*=np.minimum(1,t/.18)[:,None]
sfx=np.zeros((N,2));rng=np.random.default_rng(4188)
for name,at in events:
 duration=.26 if name=='drop' else .64 if 'fusion' in name or 'bowl' in name or name=='reassembly' else .22;n=round(duration*sr);z=np.arange(n)/sr;env=np.sin(np.pi*np.arange(n)/n)**2
 if name=='drop':sig=(np.sin(2*np.pi*(1100*z-850*z*z))+.32*np.sin(2*np.pi*2100*z))*np.exp(-z*26)*.045
 elif name.startswith('stage'):sig=(np.sin(2*np.pi*(210+35*int(name[-1]))*z)+.2*np.sin(2*np.pi*810*z))*np.exp(-z*22)*.024
 else:
  noise=rng.normal(0,1,n);soft=fftconvolve(noise,np.ones(11)/11,mode='same');sig=(soft*.016+np.sin(2*np.pi*(160*z+95*z*z))*.009)*env
 j=round(at*sr);pan=-.35 if name=='text-to-bowl' else .35 if name=='second-fusion' else 0;sfx[j:j+n,0]+=sig*(1-pan);sfx[j:j+n,1]+=sig*(1+pan)
mix=v[:,None]+music+sfx;peak=float(abs(mix).max());mix*=min(1,.89/max(peak,1e-8));fade=np.minimum(1,(10-t)/.18);mix*=fade[:,None]
for name,x in [('narration.wav',v),('music.wav',music),('sfx.wav',sfx),('master.wav',mix)]:
 with wave.open(str(A/name),'wb') as w:w.setparams((1 if x.ndim==1 else 2,2,sr,0,'NONE','not compressed'));w.writeframes((x.clip(-1,1)*32767).astype('<i2').tobytes())
q=R.parent/'assets/models/sherpa-onnx-paraformer-zh-small-2024-03-09';a=sherpa_onnx.OfflineRecognizer.from_paraformer(paraformer=str(q/'model.int8.onnx'),tokens=str(q/'tokens.txt'),num_threads=2);s=a.create_stream();s.accept_waveform(16000,read(A/'voice.wav',rate=16000));a.decode_stream(s)
report={'requested_text':'碗洗了为什么还在吵？','tts_input':'碗洗了，为什么还在吵？','pronunciation_adjustment':'wan3 xi3 -> wan2 xi3 (Mandarin third-tone sandhi); original model dictionary untouched','automatic_transcription':s.result.text,'automatic_transcription_exact_match':re.sub(r'[^\u4e00-\u9fff]','',s.result.text)=='碗洗了为什么还在吵','voice_duration_seconds':len(voice)/sr,'voice_start_seconds':.1,'audio_frames':N,'sample_rate':sr,'peak_before_gain':peak,'peak_after_gain':float(abs(mix).max()),'music_rms_voice_region':float(np.sqrt(np.mean(music[active>.5]**2))),'voice_rms':float(np.sqrt(np.mean(voice**2))),'sound_effects':'Locally synthesized deterministic drop, friction, connection and reassembly accents; not recorded foley','human_listening':False}
(O/'audio-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False));print(json.dumps(bpm))
