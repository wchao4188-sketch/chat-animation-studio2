import {openBrowser} from '@remotion/renderer';
import fs from 'node:fs/promises';
const b=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium',logLevel:'error'});
try{
 const p=await b.newPage({context:()=>null,logLevel:'error',indent:false,pageIndex:0,onBrowserLog:null,onLog:()=>{}});
 await p.setViewport({width:1440,height:900,deviceScaleFactor:1});await p.goto({url:'http://127.0.0.1:3122/',timeout:30000,options:{waitUntil:'load'}});
 const r=await p.evaluate(async()=>{document.body.innerHTML='';document.body.style.cssText='background:#101418;display:flex;align-items:center;justify-content:center;height:95vh';const v=document.createElement('video');v.src='NewWorld-Bowl-Knowledge-10s-Exact.mp4';v.muted=true;v.controls=true;v.style.width='1400px';document.body.append(v);await new Promise((resolve,reject)=>{v.onloadedmetadata=resolve;v.onerror=()=>reject(Error('metadata error'));setTimeout(()=>reject(Error('metadata timeout')),15000)});await v.play();await new Promise((resolve,reject)=>{v.onended=resolve;v.onerror=()=>reject(Error('playback error'));setTimeout(()=>reject(Error('playback timeout')),25000)});return {duration:v.duration,time:v.currentTime,width:v.videoWidth,height:v.videoHeight,decodedFrames:v.getVideoPlaybackQuality().totalVideoFrames,droppedFrames:v.getVideoPlaybackQuality().droppedVideoFrames,error:v.error?.message||null,muted:true}});
 if(r.time<9.99||r.decodedFrames<295||r.error)throw Error(JSON.stringify(r));await fs.writeFile('output/browser-playback.json',JSON.stringify(r,null,2));console.log(r);
 const s=await p._client().send('Page.captureScreenshot',{format:'png'});await fs.writeFile('output/browser-playback.png',Buffer.from(s.value.data,'base64'));
}finally{await b.close({silent:true})}
