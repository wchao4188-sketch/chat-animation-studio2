from pathlib import Path
import subprocess,json,hashlib,wave
import numpy as np
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[1];O=R/'output';v=O/'NewWorld-Bowl-Knowledge-10s-Exact.mp4'
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(v)]));vs=next(x for x in probe['streams'] if x['codec_type']=='video');au=next(x for x in probe['streams'] if x['codec_type']=='audio');assert(vs['width'],vs['height'],vs['r_frame_rate'],int(vs['nb_read_frames']))==(1920,1080,'30/1',300);assert abs(float(vs['duration'])-10)<1e-7;assert abs(float(probe['format']['duration'])-10)<1e-7;assert abs(float(au['duration'])-10)<1e-7
q=subprocess.run(['ffmpeg','-v','error','-i',str(v),'-f','null','-'],capture_output=True);assert q.returncode==0 and not q.stderr
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(v),'-vf','scale=320:180','-f','rawvideo','-pix_fmt','rgb24','-']);frames=np.frombuffer(raw,np.uint8).reshape(300,180,320,3);means=frames.mean(axis=(1,2,3));diff=np.abs(np.diff(frames.astype(np.float32),axis=0)).mean(axis=(1,2,3));assert means.min()>8
# All 300 frames are decoded; every frame is included in a 12-page visual overview.
pages=[]
for page in range(12):
 im=Image.new('RGB',(1600,1025),(14,18,22));d=ImageDraw.Draw(im)
 for j in range(25):
  i=page*25+j;x=(j%5)*320;y=(j//5)*205;im.paste(Image.fromarray(frames[i]).resize((320,180)),(x,y));d.text((x+8,y+182),f'f{i:03} / {i/30:.3f}s',fill=(210,218,222))
 p=O/f'review/all-frames-{page:02}.jpg';im.save(p,quality=91);pages.append(p)
ims=[Image.open(p).convert('RGB') for p in pages];ims[0].save(O/'NewWorld-Bowl-Keyframes.pdf',save_all=True,append_images=ims[1:],resolution=110)
# Full-size milestone frames for reading, contacts and particle inspections.
for frame in [0,36,60,80,110,141,159,185,202,222,240,258,270,285,299]:
 subprocess.run(['ffmpeg','-v','error','-i',str(v),'-vf',f'select=eq(n\\,{frame})','-frames:v','1',str(O/f'review/f{frame:03}.png')],check=True)
audio=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(v),'-vn','-ac','2','-ar','48000','-f','f32le','-']),np.float32).reshape(-1,2)
with wave.open(str(R/'public/audio/master.wav')) as w:master=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32).reshape(-1,2)/32768
n=min(len(master),len(audio));corr=float(np.corrcoef(master[:n].ravel(),audio[:n].ravel())[0,1]);assert corr>.98;assert abs(audio).max()<1
check={'video':{'width':vs['width'],'height':vs['height'],'fps':vs['r_frame_rate'],'duration_seconds':float(vs['duration']),'decoded_frames':int(vs['nb_read_frames']),'codec':vs['codec_name']},'audio':{'codec':au['codec_name'],'sample_rate':au['sample_rate'],'channels':au['channels'],'decoded_peak':float(abs(audio).max()),'master_correlation':corr},'full_ffmpeg_decode':{'exit_code':q.returncode,'errors':q.stderr.decode()},'all_frames':{'overview_pages':12,'included_frames':300,'minimum_frame_mean':float(means.min()),'maximum_adjacent_mean_difference':float(diff.max()),'largest_difference_frame':int(diff.argmax()+1),'first_fusion_adjacent_differences':diff[43:85].round(4).tolist(),'second_fusion_adjacent_differences':diff[200:280].round(4).tolist()},'file':{'bytes':v.stat().st_size,'sha256':hashlib.sha256(v.read_bytes()).hexdigest()},'human_audio_listening':False,'voice_note':'Synthetic Chinese voice included. Automatic ASR opening is homophonically ambiguous; exact text recognition did not pass. No claim of human listening or perfect diction.'}
(O/'quality-check.json').write_text(json.dumps(check,ensure_ascii=False,indent=2));print(json.dumps(check,ensure_ascii=False,indent=2))
