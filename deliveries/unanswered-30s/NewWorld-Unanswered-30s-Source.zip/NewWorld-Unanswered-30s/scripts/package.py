from pathlib import Path
import zipfile,json,hashlib
R=Path(__file__).resolve().parents[1];O=R/'output';q=json.loads((O/'quality-check.json').read_text());p=json.loads((O/'playback-check.json').read_text());d=json.loads((O/'determinism.json').read_text());m=json.loads((O/'music-analysis.json').read_text())
(O/'Acceptance.md').write_text(f'''# 新世界｜30秒测试片实际验收

## 输出

1920×1080、16:9、30fps、900帧，视频时长{q['video']['duration']}秒，容器{q['container_duration']}秒。无配音。MP4 {q['file']['bytes']:,}字节；SHA-256 `{q['file']['sha256']}`。

## 实际制作与修正

本片用手机中的消息、注意力回路、从同一信息长出的猜测分支和事实边界解释一种可能的机制。虚构聊天不是事实报道；轨迹不是脑区、好感评分或实验数据。不把复杂依恋归因于唯一机制，没有成瘾或神经递质的虚构结论。

首轮实际渲染后，检查了6个高清时点。制作中修正消息终点，使其到达注意力中心；猜测支路改为沿路径连续描绘。发现旧字体子集缺47个汉字，补齐本片全部中文字库并检查覆盖后重新渲染全部900帧。旧作品未修改。

最终MP4完整FFmpeg解码退出{q['decode']['exit']}，错误输出为空。900帧全部计算基础亮度与相邻差异；查看全片半秒总览、6段密集转场和高清帧。基础检测不等于每帧审美认证。

Chromium全长播放结束{p['ended']}，总帧{p['frames']}，丢帧{p['dropped']}，媒体错误{p['error']}。第570帧两次实际渲染字节相同{d['byte_identical']}。

## 声音

实际使用用户原有音乐{m['source_start_seconds']:.1f}秒起的30秒片段，无变速。主BPM算法候选{m['bpm_candidates'][0]}；没有人工确认小节重拍。关键动作与起音距离记录在music-analysis.json。音效本地合成，非素材库实录。

混音AAC测量输入约−17.00LUFS，真峰值−4.44dBTP。最终解码音轨峰值{q['audio']['decoded_peak']:.6f}；与预定混音相关系数{q['audio']['reference_correlation']:.6f}。自动播放为静音，未进行真人试听，不声称人耳验收通过。

## 工具与边界

Remotion4.0.536、React19.2.4、TypeScript5.9.3及Chromium、FFmpeg复用已安装依赖，没有新增npm包。画面使用SVG和确定性坐标，没有三维网格或物理粒子仿真。

当前OpenAI Platform标签未提供可调用连接器工具，未调用该连接器，也没有外部付费API调用。按既有参考的主体连续演化和知识揭示方式原创，不声称已核实vibe知识大赏具体账号、模型版本或完整复刻其风格。

论文访问被网络代理403拒绝，未完成全文核实；本片不呈现研究数字或声称文献证明长期依恋因果。工程可编辑；其他电脑上的新安装与完整重渲尚未验证。
''')
paths=[R/x for x in ['README.md','package.json','package-lock.json','tsconfig.json','requirements-production.txt']]
for name in ['src','public','scripts','assets']:paths += [p for p in (R/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
for name in ['Acceptance.md','quality-check.json','playback-check.json','determinism.json','music-analysis.json','audio-measurement.log']:paths.append(O/name)
Z=O/'NewWorld-Unanswered-30s-Source.zip'
with zipfile.ZipFile(Z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(paths):z.write(p,Path('NewWorld-Unanswered-30s')/p.relative_to(R))
with zipfile.ZipFile(Z) as z:assert z.testzip() is None
rows=[]
for p in [O/'NewWorld-Unanswered-30s.mp4',Z,O/'Keyframes.pdf',O/'Acceptance.md']:
 rows.append({'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(O/'manifest.json').write_text(json.dumps(rows,indent=2));(O/'SHA256SUMS.txt').write_text('\n'.join(x['sha256']+'  '+x['name'] for x in rows)+'\n');print(json.dumps(rows,indent=2))
