from pathlib import Path
import subprocess,json,wave
import numpy as np
from scipy.signal import find_peaks,butter,sosfilt
R=Path(__file__).resolve().parents[1];A=R/'public/audio';O=R/'output';sr=48000
raw=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(A/'user-music-source.m4a'),'-ac','1','-ar','12000','-f','f32le','-']),'<f4').copy();hop=240;n=len(raw)//hop;e=np.sqrt(np.mean(raw[:n*hop].reshape(n,hop)**2,axis=1));on=np.maximum(np.diff(e,prepend=e[0]),0);peaks,_=find_peaks(on,distance=10,prominence=np.percentile(on,75)*.65);pt=peaks*.02
ac=np.correlate(on[:6000]-on[:6000].mean(),on[:6000]-on[:6000].mean(),'full')[min(6000,len(on))-1:];lags=np.arange(20,75);rank=lags[np.argsort(ac[lags])[-8:][::-1]];bpm=[round(60/(k*.02),3) for k in rank[:5]]
events=[{'time':5.3,'event':'reply leaves phone'},{'time':6.35,'event':'reply reaches attention'},{'time':10.2,'event':'checking loop 1'},{'time':11.6,'event':'checking loop 2'},{'time':13,'event':'checking loop 3'},{'time':14.4,'event':'checking loop 4'},{'time':17.6,'event':'possibility 1 unfolds'},{'time':18.25,'event':'possibility 2 unfolds'},{'time':18.9,'event':'possibility 3 unfolds'},{'time':23.5,'event':'fact boundary settles'},{'time':26.6,'event':'final question settles'}]
anchors=np.array([6.35,10.2,17.6,23.5,26.6]);candidates=np.arange(0,min(70,len(raw)/12000-30),.1);scores=[sum(np.exp(-((pt-(s+x))/.1)**2).sum() for x in anchors) for s in candidates];start=float(candidates[np.argmax(scores)])
subprocess.run(['ffmpeg','-v','error','-y','-ss',str(start),'-i',str(A/'user-music-source.m4a'),'-t','30','-af','aresample=48000,highpass=f=50,lowpass=f=6500','-ac','2',str(A/'music.wav')],check=True)
with wave.open(str(A/'music.wav')) as w:music=np.frombuffer(w.readframes(w.getnframes()),'<i2').reshape(-1,2)/32768
N=sr*30;music=music[:N];sfx=np.zeros((N,2));rng=np.random.default_rng(318)
for ev in events:
 t=ev['time'];L=int(sr*.65);q=np.arange(L)/sr;freq=620 if 'reply' in ev['event'] else 310;env=(1-np.exp(-q*100))*np.exp(-q*9);tone=(np.sin(2*np.pi*freq*q)+.3*np.sin(2*np.pi*freq*1.498*q))*env*.045
 noise=sosfilt(butter(2,[450,4200],fs=sr,btype='band',output='sos'),rng.normal(0,1,L))*env*.018;sig=tone+noise;i=int(t*sr);L=min(L,N-i);pan=.15 if 'reply' in ev['event'] else -.15;sfx[i:i+L,0]+=sig[:L]*(1-pan);sfx[i:i+L,1]+=sig[:L]*(1+pan)
# Low, continuous friction follows the actual graph-growth phases.
for a,b in [(16.2,19.8),(22,24.2),(25.2,27.2)]:
 i,j=int(a*sr),int(b*sr);q=np.linspace(0,1,j-i);env=np.sin(np.pi*q)**2;noise=sosfilt(butter(2,[220,1600],fs=sr,btype='band',output='sos'),rng.normal(0,1,j-i))*env*.022;sfx[i:j]+=noise[:,None]
q=np.arange(N)/sr;fade=np.clip(q/.6,0,1)*np.clip((30-q)/1.3,0,1);mix=(music*.62+sfx)*fade[:,None];mix*=.79/max(.79,float(abs(mix).max()))
def save(name,y):
 with wave.open(str(A/name),'w') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((np.clip(y,-1,1)*32767).astype('<i2').tobytes())
save('sfx.wav',sfx);save('master.wav',mix)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(A/'master.wav'),'-af','loudnorm=I=-17:TP=-2:LRA=9','-c:a','aac','-b:a','256k','-ar','48000',str(A/'master.m4a')],check=True)
report={'source':'user-music-source.m4a','source_start_seconds':start,'duration':30,'method':'20ms RMS positive-difference onset; autocorrelation tempo candidates; no manually confirmed downbeat','bpm_candidates':bpm,'onsets_in_selected_excerpt':[round(float(t-start),3) for t in pt if start<=t<start+30],'animation_events':[dict(x,frame=round(x['time']*30),nearest_onset_distance_seconds=round(float(min(abs(pt-(start+x['time'])))),3)) for x in events],'voiceover':False,'human_listening':False};(O/'music-analysis.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
