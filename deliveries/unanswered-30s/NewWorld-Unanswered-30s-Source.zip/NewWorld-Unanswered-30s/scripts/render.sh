#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
npm run typecheck
npx remotion render src/index.tsx Unanswered output/Native-Render.mp4 --browser-executable=/usr/bin/chromium --codec=h264 --crf=16 --concurrency=3
ffmpeg -v error -y -i output/Native-Render.mp4 -map 0:v:0 -map 0:a:0 -c:v copy -af atrim=duration=30 -c:a aac -b:a 256k -t 30 -movflags +faststart output/NewWorld-Unanswered-30s.mp4
