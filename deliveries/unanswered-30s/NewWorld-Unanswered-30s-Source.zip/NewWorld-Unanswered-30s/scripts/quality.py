from pathlib import Path
import subprocess,json,hashlib
from PIL import Image,ImageDraw
import numpy as np
R=Path(__file__).resolve().parents[1];O=R/'output';Q=O/'review';P=O/'NewWorld-Unanswered-30s.mp4'
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(P)]));v=next(x for x in probe['streams'] if x['codec_type']=='video');a=next(x for x in probe['streams'] if x['codec_type']=='audio');assert(v['width'],v['height'],v['r_frame_rate'],int(v['nb_read_frames']))==(1920,1080,'30/1',900);assert abs(float(v['duration'])-30)<.001
p=subprocess.run(['ffmpeg','-v','error','-i',str(P),'-f','null','-'],capture_output=True);assert p.returncode==0 and not p.stderr
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(P),'-vf','scale=320:180','-f','rawvideo','-pix_fmt','rgb24','-']);frames=np.frombuffer(raw,np.uint8).reshape(900,180,320,3);means=frames.mean((1,2,3));diff=np.abs(np.diff(frames.astype(np.int16),axis=0)).mean((1,2,3));assert means.min()>3

def page(ids,name,cols=4):
 out=Image.new('RGB',(400*cols,250*((len(ids)+cols-1)//cols)),'#141516');d=ImageDraw.Draw(out)
 for k,i in enumerate(ids):
  x=k%cols*400;y=k//cols*250;out.paste(Image.fromarray(frames[i]).resize((400,225)),(x,y));d.text((x+5,y+230),f'{i/30:.3f}s / f{i}',fill='white')
 path=Q/name;out.save(path,quality=95);return path
ids=list(range(0,900,15))+[899];pages=[page(ids[i:i+20],f'contact-{i//20}.jpg') for i in range(0,len(ids),20)];pdf=[Image.open(p).convert('RGB') for p in pages];pdf[0].save(O/'Keyframes.pdf',save_all=True,append_images=pdf[1:],resolution=120)
for t in[4.2,6.35,9.2,16,22.1,26]:page(list(range(max(0,round((t-.2)*30)),min(900,round((t+1.4)*30)),2)),f'transition-{t}.jpg')
for t in[2,6.1,11.5,18.9,24.2,28,29.967]:subprocess.run(['ffmpeg','-v','error','-y','-i',str(P),'-vf',rf'select=eq(n\,{min(899,round(t*30))})','-frames:v','1',str(Q/f'actual-{t}.png')],check=True)
audio=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(P),'-vn','-ar','48000','-ac','2','-f','f32le','-']),'<f4');ref=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(R/'public/audio/master.m4a'),'-ar','48000','-ac','2','-f','f32le','-']),'<f4');n=min(len(audio),len(ref));corr=float(np.corrcoef(audio[:n],ref[:n])[0,1]);assert corr>.98 and abs(audio).max()<1
r={'video':{'width':v['width'],'height':v['height'],'fps':v['r_frame_rate'],'frames':v['nb_read_frames'],'duration':v['duration'],'codec':v['codec_name']},'container_duration':probe['format']['duration'],'audio':{'codec':a['codec_name'],'rate':a['sample_rate'],'channels':a['channels'],'decoded_peak':float(abs(audio).max()),'reference_correlation':corr,'final_20ms_rms':float(np.sqrt(np.mean(audio[-1920:]**2)))},'decode':{'exit':p.returncode,'stderr':p.stderr.decode()},'all_frames':{'count':900,'minimum_mean_brightness':float(means.min()),'largest_adjacent_difference':float(diff.max()),'largest_difference_frame':int(diff.argmax()+1)},'file':{'bytes':P.stat().st_size,'sha256':hashlib.sha256(P.read_bytes()).hexdigest()},'human_listening':False,'voiceover':False,'notes':'All-frame scalar metrics are basic checks; visual reviews are separate, and do not certify aesthetic quality.'};(O/'quality-check.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
