from pathlib import Path
import urllib.request,hashlib,json,subprocess,zipfile,io
R=Path(__file__).resolve().parents[1];O=R/'output';repo=Path('/workspace/bowl3d-delivery');commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();rows=[]
for item in json.loads((O/'manifest.json').read_text()):
 p='deliveries/unanswered-30s/'+item['name'];tree=subprocess.check_output(['git','ls-tree','-l',commit,'--',p],cwd=repo,text=True).strip();assert tree and int(tree.split()[3])==item['bytes']
 u=f'https://raw.githubusercontent.com/wchao4188-sketch/chat-animation-studio2/{commit}/{p}'
 with urllib.request.urlopen(u,timeout=120) as response:status=response.status;data=response.read()
 assert status==200 and len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
 r={**item,'url':u,'http_status':status,'anonymous_full_download':True}
 if item['name'].endswith('.zip'):
  with zipfile.ZipFile(io.BytesIO(data)) as z:assert z.testzip() is None;r['zip_crc']='passed'
 rows.append(r);print(json.dumps(r),flush=True)
(O/'download-verification.json').write_text(json.dumps({'commit':commit,'files':rows},indent=2))
