import React from 'react';
import {AbsoluteFill,Audio,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';

const C={bg:'#101113',white:'#e8e6dd',muted:'#92938e',yellow:'#dcb95d',red:'#d76b60',line:'#5a5d5a'};
export const ease=(x:number)=>{x=Math.max(0,Math.min(1,x));return x*x*x*(x*(x*6-15)+10)};
export const r=(t:number,a:number,b:number)=>ease((t-a)/(b-a));
const mix=(a:number,b:number,x:number)=>a+(b-a)*x;
const win=(t:number,a:number,b:number)=>r(t,a,a+.45)*(1-r(t,b-.4,b));
const hash=(n:number)=>{const a=Math.sin(n*127.1+73.8)*43758.5453;return a-Math.floor(a)};
const T=({x,y,size=48,children,color=C.white,opacity=1,width=1600,align='left',style={}}:{x:number;y:number;size?:number;children:React.ReactNode;color?:string;opacity?:number;width?:number;align?:'left'|'center';style?:React.CSSProperties})=><div style={{position:'absolute',left:x,top:y,width,fontFamily:'Text',fontSize:size,lineHeight:1.3,whiteSpace:'pre-wrap',color,opacity,textAlign:align,...style}}>{children}</div>;
const Caption=({t,a,b,children}:{t:number;a:number;b:number;children:React.ReactNode})=><T x={120} y={150-16*r(t,a,a+.7)} size={72} opacity={win(t,a,b)} style={{fontFamily:'Display',fontWeight:700,letterSpacing:1}}>{children}</T>;

function Phone({t}:{t:number}){
 const reveal=r(t,3.5,5),exit=r(t,16.5,18.5),scale=mix(1,.68,reveal),x=mix(1370,1515,reveal)+850*exit,y=mix(560,570,reveal),rot=mix(-13,0,reveal);
 const incoming=r(t,4.8,5.3),sent=r(t,9,10),waiting=r(t,9.2,10);
 return <g transform={`translate(${x} ${y}) scale(${scale}) rotate(${rot})`}>
  <ellipse cx={0} cy={365} rx={190} ry={23} fill="#000" opacity=".6" filter="url(#blur)"/>
  <rect x={-170} y={-332} width={340} height={660} rx={47} fill="url(#metal)" stroke="#868983" strokeWidth="1.4"/>
  <rect x={-164} y={-326} width={328} height={648} rx={42} fill="#070809" stroke="#313433" strokeWidth="2"/>
  <rect x={-153} y={-315} width={306} height={626} rx={34} fill="url(#screen)"/>
  <path d="M-147 -270V-290Q-147-308-129-308H129" fill="none" stroke="#b5b9ae" opacity=".25"/>
  <rect x={-56} y={-300} width={112} height={23} rx={12} fill="#030405"/>
  <circle cx={0} cy={-213} r={25} fill="#343932"/><path d="M-13-213A13 13 0 0 1 13-213M-20-193Q0-210 20-193" fill="none" stroke="#9caa95"/>
  <text y={-158} textAnchor="middle" fill={C.white} fontSize={23} fontFamily="Text">对方</text>
  <path d="M-125-124H125" stroke="#343733"/>
  <g opacity={1-sent}>
   <rect x={-125} y={-70} width={205} height={69} rx={15} fill="#c9d1bb"/>
   <path d="M-118-70L-135-70L-125-53" fill="#c9d1bb"/>
   <text x={-103} y={-24} fill="#252922" fontSize={29} fontFamily="Text">晚点聊</text>
   <rect x={-40} y={30} width={169} height={58} rx={13} fill="#454d42"/>
   <text x={-20} y={69} fill={C.white} fontSize={26} fontFamily="Text">好呀</text>
  </g>
  <g opacity={waiting}><text y={-17} textAnchor="middle" fill="#939a8e" fontSize={24} fontFamily="Text">等待新的回复</text><path d="M-25 30H25" stroke="#646c60" strokeDasharray="4 8"/></g>
  <rect x={-128} y={229} width={256} height={45} rx={22} fill="#232824" stroke="#40483d"/>
  <path d="M-48 296H48" stroke="#999e94" strokeWidth="5" strokeLinecap="round"/>
  <path d="M-170-230V70" stroke="#777e72" strokeWidth="3"/><path d="M170-180V-80" stroke="#777e72" strokeWidth="3"/>
  <g opacity={incoming*(1-r(t,6.4,7))}><rect x={-212} y={-70} width={235} height={80} rx={16} fill={C.yellow}/><text x={-187} y={-18} fill="#20221e" fontSize={34} fontFamily="Text">晚点聊</text></g>
 </g>;
}

function Lens({t}:{t:number}){
 const show=r(t,3.7,5),concept=r(t,16,18),close=r(t,23,25),release=r(t,25.2,27.2);
 const cx=mix(mix(510,525,concept),960,release),cy=mix(590,610,release),rad=mix(168,106,release),spin=t*.12;
 const keep=(1-r(t,28.3,29.4));
 return <g opacity={show*keep}>
  <ellipse cx={cx} cy={cy+240} rx={165} ry={17} fill="#000" opacity=".5" filter="url(#blur)"/>
  {Array.from({length:11},(_,j)=>{const ry=rad*(.21+j*.065);return <ellipse key={j} cx={cx} cy={cy} rx={rad+j*.8} ry={ry} fill="none" stroke={j===10?C.white:C.line} strokeWidth={j===10?2.4:.8} opacity={j===10?.85:.3} transform={`rotate(${-24+18*release} ${cx} ${cy})`}/>})}
  <path d={`M${cx-rad-18} ${cy}H${cx+rad+18}M${cx} ${cy-rad-18}V${cy+rad+18}`} stroke={C.line} strokeWidth=".7" opacity=".45"/>
  {Array.from({length:76},(_,i)=>{
   const q=i/76*Math.PI*2+spin,rx=rad*(1+.18*Math.sin(q*.5)),ry=rad*.56;
   const a=q+t*.65*(1-release),px=cx+Math.cos(a)*rx,py=cy+Math.sin(a)*ry;
   const loss=release*hash(i+10);return <circle key={i} cx={px+loss*Math.cos(q)*360} cy={py+loss*Math.sin(q)*220} r={i%9===0?3.1:1.4} fill={i%9===0?C.yellow:C.white} opacity={mix(.65,.18,release)*(1-close*.2)}/>;
  })}
  <circle cx={cx} cy={cy} r={29+6*r(t,6.1,6.7)} fill="url(#orb)" stroke="#e5d59a" strokeWidth="1"/>
  <circle cx={cx} cy={cy} r={46} fill="none" stroke={C.yellow} opacity={.5*(1-release)} strokeWidth=".8"/>
  <g opacity={1-concept}><text x={cx} y={cy+260} textAnchor="middle" fill={C.muted} fontSize="28" fontFamily="Text">你的注意力</text></g>
 </g>;
}

function Flow({t}:{t:number}){
 const reveal=r(t,4.7,5.6),concept=r(t,16,18),release=r(t,23,25),alpha=reveal*(1-concept);
 const d='M 1455 570 C 1225 428 898 424 510 590';
 const pathPoint=(u:number)=>{const p=1-u;return{x:p*p*p*1455+3*p*p*u*1225+3*p*u*u*898+u*u*u*510,y:p*p*p*570+3*p*p*u*428+3*p*u*u*424+u*u*u*590}};
 return <g opacity={alpha}>
  <path d={d} pathLength={1} stroke={C.line} fill="none" strokeWidth="1.4" strokeDasharray={1} strokeDashoffset={1-reveal}/>
  {[5.3].map((start,j)=>{const u=r(t,start,start+1.05),p=pathPoint(u),a=win(t,start-.1,start+1.45);return <g key={j} opacity={a} transform={`translate(${p.x} ${p.y})`}><rect x={-74} y={-29} width={148} height={58} rx={8} fill={C.yellow}/><text textAnchor="middle" y={11} fill="#252620" fontSize={29} fontFamily="Text">晚点聊</text></g>})}
  {Array.from({length:4},(_,i)=>{const start=10+i*1.4,u=r(t,start,start+1.25),a=win(t,start-.05,start+1.5),ang=u*2*Math.PI,p={x:510+Math.cos(ang)*226,y:590+Math.sin(ang)*143};return <g opacity={a} key={i}><ellipse cx={510} cy={590} rx={226} ry={143} fill="none" stroke={C.red} strokeWidth={1} strokeDasharray="4 12"/><circle cx={p.x} cy={p.y} r={5} fill={C.red}/><path d={`M${p.x-9} ${p.y-7}l16 7-16 7`} fill="none" stroke={C.red} strokeWidth="2" transform={`rotate(${u*360+90} ${p.x} ${p.y})`}/></g>})}
  <g opacity={r(t,10.1,10.7)*(1-r(t,15,16))}><text x={950} y={570} textAnchor="middle" fill={C.red} fontSize={28} fontFamily="Text">再看一眼</text><path d="M887 599H1013" stroke={C.red} strokeWidth="1"/></g>
 </g>;
}

function Possibilities({t}:{t:number}){
 const enter=r(t,16.2,17.6),filter=r(t,22,24.2),leave=r(t,25.1,26.5),alpha=enter*(1-leave),left=525;
 const answers=[{x:1290,y:405,s:'是不是在忙？'},{x:1450,y:605,s:'是不是我说错了？'},{x:1250,y:805,s:'也许下一条……'}];
 return <g opacity={alpha}>
  <g transform={`translate(${left} 590)`}><rect x={-105} y={-40} width={210} height={80} rx={12} fill={C.yellow}/><text y={12} textAnchor="middle" fontFamily="Text" fontSize="35" fill="#23251e">晚点聊</text></g>
  <text x={left} y={790} textAnchor="middle" fontSize="30" fill={C.yellow} fontFamily="Text">实际收到的</text>
  {answers.map((p,i)=>{const amount=r(t,17.3+i*.65,18.3+i*.65),endx=mix(p.x,1005,filter),d=`M 635 590 C 830 590 840 ${p.y} ${endx} ${p.y}`;return <g key={i}>
   <path d={d} fill="none" stroke={C.white} strokeWidth="1.6" opacity={.5*(1-filter*.65)} pathLength={1} strokeDasharray={1} strokeDashoffset={1-amount}/>
   <g opacity={amount*(1-filter)} transform={`translate(${p.x} ${p.y})`}><circle r={12} fill={C.bg} stroke={C.white}/><text x={30} y={11} fill={C.white} fontFamily="Text" fontSize={34}>{p.s}</text></g>
   {Array.from({length:7},(_,j)=>{const u=r(t,18.1+i*.3+j*.13,19.2+i*.3+j*.13),p0=1-u,cx=p0*p0*p0*635+3*p0*p0*u*830+3*p0*u*u*840+u*u*u*endx,cy=p0*p0*p0*590+3*p0*p0*u*590+3*p0*u*u*p.y+u*u*u*p.y;return <circle key={j} cx={cx} cy={cy} r={2} fill={C.white} opacity={amount*(1-filter)*.5}/>})}
  </g>})}
  <text x={1330} y={915} textAnchor="middle" fill={C.muted} fontFamily="Text" fontSize="30" opacity={1-filter}>脑中补完的可能</text>
  <g opacity={filter}><path d="M1008 352V850" stroke={C.yellow} strokeWidth="2"/><path d="M997 352H1019M997 850H1019" stroke={C.yellow} strokeWidth="2"/><text x={1050} y={560} fill={C.white} fontFamily="Text" fontSize="46">猜测，不等于事实。</text><text x={1050} y={620} fill={C.muted} fontFamily="Text" fontSize="28">暂时不知道，也是一种答案。</text></g>
 </g>;
}

export const Film=()=>{
 const f=useCurrentFrame(),{fps}=useVideoConfig(),t=f/fps;
 return <AbsoluteFill style={{background:C.bg,overflow:'hidden'}}>
  <style>{`@font-face{font-family:Display;src:url('${staticFile('fonts/Display.woff')}')}@font-face{font-family:Text;src:url('${staticFile('fonts/Text.woff')}')}@font-face{font-family:Mono;src:url('${staticFile('fonts/Mono.woff')}')}`}</style>
  <AbsoluteFill style={{background:'radial-gradient(ellipse at 65% 50%,#262820 0%,#171917 42%,#101113 78%)'}}/>
  <svg width={1920} height={1080} style={{position:'absolute',inset:0}}>
   <defs><linearGradient id="metal" x1="0" y1="0" x2="1" y2=".4"><stop stopColor="#282d2b"/><stop offset=".2" stopColor="#9a9e94"/><stop offset=".25" stopColor="#333b35"/><stop offset=".8" stopColor="#161b17"/><stop offset="1" stopColor="#71776c"/></linearGradient><linearGradient id="screen" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#252d24"/><stop offset=".5" stopColor="#121912"/><stop offset="1" stopColor="#1f2720"/></linearGradient><radialGradient id="orb" cx=".3" cy=".25"><stop stopColor="#fff7ce"/><stop offset=".3" stopColor="#e5cd88"/><stop offset=".75" stopColor="#8b7948"/><stop offset="1" stopColor="#302c20"/></radialGradient><filter id="blur"><feGaussianBlur stdDeviation="12"/></filter></defs>
   {Array.from({length:120},(_,i)=>{const x=hash(i+1)*1920,y=hash(i+300)*1080;return <circle key={i} cx={x} cy={y} r={hash(i+20)*.8+.2} fill="#b2b5a9" opacity={.04+hash(i+30)*.09}/>})}
   <Phone t={t}/><Lens t={t}/><Flow t={t}/><Possibilities t={t}/>
  </svg>
  <div style={{position:'absolute',inset:0,backgroundImage:'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'180\' height=\'180\'%3E%3Cfilter id=\'n\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'.9\' numOctaves=\'3\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' opacity=\'.4\' filter=\'url(%23n)\'/%3E%3C/svg%3E")',opacity:.08,mixBlendMode:'screen'}}/>
  <T x={120} y={65} size={21} color={C.muted} style={{letterSpacing:5}}>新世界 / RELATIONSHIP STUDY</T>
  <T x={1540} y={65} size={20} width={260} align="center" color={C.muted} style={{fontFamily:'Mono'}}>01 — ATTENTION</T>
  <Caption t={t} a={0} b={4.2}>{'为什么对一个人\n越来越放不下？'}</Caption>
  <Caption t={t} a={4.2} b={9.2}>{<>一句<span style={{color:C.yellow}}>“晚点聊”</span>，<br/>让期待有了去处。</>}</Caption>
  <Caption t={t} a={9.2} b={16}>{<>回应没有来，<br/>注意力却<span style={{color:C.red}}>反复回来。</span></>}</Caption>
  <Caption t={t} a={16} b={22.1}>{'收到的只有一句，\n脑中却长出许多可能。'}</Caption>
  <Caption t={t} a={22.1} b={26}>{<>不确定，可能让你<br/><span style={{color:C.yellow}}>反复寻求答案。</span></>}</Caption>
  <T x={120} y={174} size={72} opacity={r(t,26,26.6)} align="center" width={1680} style={{fontFamily:'Display',fontWeight:700}}>{'你在想念一个人，\n还是等待一个答案？'}</T>
  <T x={120} y={905} size={24} color={C.muted} opacity={win(t,4.7,16)}>{'虚构聊天示例 · 轨迹表示注意力流向，不代表好感评分'}</T>
  <T x={120} y={940} size={22} color={C.muted} opacity={r(t,26.8,27.5)} align="center" width={1680}>{'这是一种可能的机制，并非依恋的唯一原因。'}</T>
  <div style={{position:'absolute',bottom:50,left:120,width:1680,height:1,background:'#3c4039'}}><div style={{width:`${f/899*100}%`,height:1,background:C.yellow}}/></div>
  <Audio src={staticFile('audio/master.m4a')}/>
 </AbsoluteFill>;
};
