# 新世界｜知识蒸馏与智能视频制作集成

Open Montage已作为优先复用组件接入。本次依据用户提供的7页《04、无限聊天话题技巧.pdf》，完成知识蒸馏、导演决策及10秒实际验证，不扩展整片，不修改旧成果。

- 完整集成报告：`docs/Integration-Report.md`
- 更新工作流：`docs/Workflow.md`
- 知识蒸馏：`project/artifacts/knowledge-distillation.json`
- 导演决策：`project/artifacts/director-decision.json`
- 真实调用与测试：`artifacts/`、`project/artifacts/jobs/`
- 成片：`project/renders/NewWorld-ChatTopics-OM-10s.mp4`
- 可编辑动画：`project/visual/src/`

## 运行入口

当前环境已配置，无需重新安装或升级。

```sh
/workspace/tools/OpenMontage/.venv/bin/python -m orchestrator.cli capabilities
/workspace/tools/OpenMontage/.venv/bin/python -m orchestrator.cli run examples/probe.json
/workspace/tools/OpenMontage/.venv/bin/python scripts/audio_prepare.py
/workspace/tools/OpenMontage/.venv/bin/python scripts/render_plan.py
/workspace/tools/OpenMontage/.venv/bin/python tests/test_integration.py
python scripts/quality.py
```

`config.json`包含本机工具与项目路径，不含凭据。移到其他机器时需调整路径，并安装对应提交的Open Montage及其依赖；跨机器重装尚未验证。为避免将配置路径默认为可下载入口，文件交付链接另经HTTP完整下载核验。

Open Montage来源：<https://github.com/calesthio/OpenMontage>，检出提交`c8066452325cb57c8fc1ba8c2a71b6e8842e6b65`；上游许可AGPL-3.0，源代码及许可参见该仓库。本包主要包含本次适配代码和测试工程，不冒充上游官方发行包。

公开交付工程不包含用户PDF原文、全文抽取或推广水印。原PDF在本地保留；包内只有页码证据、少量必要引文和原创演绎。已有PDF可通过`orchestrator.content.extract_pdf()`接入其他任务。

画面与知识表达以实际10秒测试片为准。技术测试不代表审美认证；未进行人耳试听。成片没有效果承诺，课程作者的个人观点没有被包装为研究结论。
