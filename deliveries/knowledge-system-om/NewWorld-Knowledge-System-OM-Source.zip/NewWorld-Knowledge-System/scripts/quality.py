from pathlib import Path
import subprocess,json,hashlib,wave,sys
import numpy as np
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R));from orchestrator.dispatch import Dispatcher,Request
from orchestrator.content import check_published_text
from orchestrator.review import normalize_upstream_review
D=Dispatcher();P=D.project;F=P/'renders/NewWorld-ChatTopics-OM-10s.mp4';O=R/'output'
q=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(F)]));v=next(s for s in q['streams'] if s['codec_type']=='video');a=next(s for s in q['streams'] if s['codec_type']=='audio');assert(v['width'],v['height'],v['r_frame_rate'],int(v['nb_read_frames']))==(1920,1080,'30/1',300);assert abs(float(q['format']['duration'])-10)<.002
run=subprocess.run(['ffmpeg','-v','error','-i',str(F),'-f','null','-'],capture_output=True);assert run.returncode==0 and not run.stderr
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(F),'-vf','scale=320:180','-f','rawvideo','-pix_fmt','rgb24','-']);frames=np.frombuffer(raw,np.uint8).reshape(300,180,320,3);diff=np.abs(np.diff(frames.astype(np.int16),axis=0)).mean((1,2,3));means=frames.mean((1,2,3));assert means.min()>3
ids=list(range(0,300,15))+[299];sheet=Image.new('RGB',(1600,250*((len(ids)+3)//4)),'#111719');draw=ImageDraw.Draw(sheet)
for k,n in enumerate(ids):
 x=k%4*400;y=k//4*250;sheet.paste(Image.fromarray(frames[n]).resize((400,225)),(x,y));draw.text((x+6,y+229),f'{n/30:.3f}s / f{n}',fill='white')
sheet.save(O/'Keyframes.jpg',quality=95);sheet.save(O/'Keyframes.pdf',resolution=120)
# The same final compressed video packets must survive final audio mux.
def packet_hash(p):return subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-map','0:v:0','-c','copy','-f','hash','-hash','sha256','-'],text=True).strip()
copy_hash=[packet_hash(P/'renders/stitched-video.mp4'),packet_hash(F)];assert copy_hash[0]==copy_hash[1]
audio=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(F),'-vn','-ar','48000','-ac','2','-f','f32le','-']),'<f4')
with wave.open(str(P/'assets/audio/master.wav')) as w:reference=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32)/32768
n=min(len(audio),len(reference));corr=float(np.corrcoef(audio[:n],reference[:n])[0,1]);assert corr>.98 and abs(audio).max()<1
texts=json.loads((P/'artifacts/published-text.json').read_text());assert not check_published_text('\n'.join(texts))
reviews={}
for name in ['render_ShotA','render_ShotB']:
 source=json.loads((P/f'artifacts/{name}.result.json').read_text());norm=normalize_upstream_review(source['data']['final_review']);assert norm['automatic_gate']!='blocked';reviews[name]=norm;(P/f'artifacts/{name}.review-normalized.json').write_text(json.dumps(norm,indent=2))
old={'/workspace/-/unanswered-30s/output/NewWorld-Unanswered-30s.mp4':'7b07ebaf0b37bf56c3714a1211fc66952f9c0d10c43c7ba0a79d00a76049608f','/workspace/-/origin-of-the-false-person/output/NewWorld-Origin-Of-The-False-Person.mp4':'b04d4f1ff42ffbdd5f45ed9eb3eb5befff8325a81591fb8ae9b0a196e040fe52'}
for p,h in old.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
r={'video':{'width':v['width'],'height':v['height'],'fps':v['r_frame_rate'],'frames':v['nb_read_frames'],'duration':v['duration'],'container_duration':q['format']['duration']},'audio':{'codec':a['codec_name'],'sample_rate':a['sample_rate'],'channels':a['channels'],'peak':float(abs(audio).max()),'master_correlation':corr,'human_listening':False},'full_decode':{'exit':run.returncode,'stderr':run.stderr.decode()},'all_frames':{'count':300,'minimum_brightness':float(means.min()),'maximum_adjacent_difference':float(diff.max()),'maximum_difference_frame':int(diff.argmax()+1),'splice_boundary_difference':float(diff[149])},'video_packet_copy':{'identical':True,'sha256':copy_hash[0]},'content_guard':{'checked':'AST-extracted visible copy','matches':[]},'source':{'pdf_pages':7,'used_pages':[6,7],'evidence_type':'author opinion and illustrative example; not a scientific study'},'voiceover_added':False,'old_deliverables_hashes_unchanged':True,'file':{'bytes':F.stat().st_size,'sha256':hashlib.sha256(F.read_bytes()).hexdigest()}}
(O/'quality-check.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
