from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from orchestrator.dispatch import Dispatcher,Request
D=Dispatcher();P=D.project;events=[{'time':1.2,'label':'reply settles'},{'time':2,'label':'keyword underline reaches edge'},{'time':4.8,'label':'keyword becomes evidence anchor'},{'time':5.35,'label':'feeling branch reaches node'},{'time':5.85,'label':'expectation branch reaches node'},{'time':6.9,'label':'open question connection reaches anchor'}]
jobs=[Request('music_rhythm','audio.rhythm',{'input_path':str(P/'assets/music/excerpt.m4a'),'output_path':str(P/'artifacts/music-rhythm.json'),'events':events},[str(P/'assets/music/excerpt.m4a')]),Request('sound_synthesis','audio.sfx',{'duration':10,'events':events,'output_path':str(P/'assets/audio/sfx.wav')}),Request('audio_mix','audio.mix',{'operation':'full_mix','tracks':[{'path':str(P/'assets/music/excerpt.m4a'),'role':'music','volume':.5,'fade_in_seconds':.35,'fade_out_seconds':.8},{'path':str(P/'assets/audio/sfx.wav'),'role':'sfx','volume':.8}],'normalize':True,'loudnorm_target':-17,'target_duration':10,'ducking':{'enabled':False},'output_path':str(P/'assets/audio/master.wav')},[str(P/'assets/music/excerpt.m4a'),str(P/'assets/audio/sfx.wav')],cache=True)]
for j in jobs:
 r=D.run(j);assert r['success'],r;print(j.id,r['tool'])
