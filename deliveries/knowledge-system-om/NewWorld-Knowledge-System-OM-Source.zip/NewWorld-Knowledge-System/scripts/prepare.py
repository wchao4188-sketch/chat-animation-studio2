from pathlib import Path
import json,hashlib,sys,subprocess
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from orchestrator.content import extract_pdf,check_published_text
from orchestrator.dispatch import Dispatcher,Request
D=Dispatcher();P=D.project;A=P/'artifacts';pdf=P/'assets/source/original.pdf'
extracted=extract_pdf(pdf,A/'pdf-extracted.txt');(A/'source-pages.json').write_text(json.dumps(extracted,ensure_ascii=False,indent=2))
claims=[{'id':'K1','pages':[1],'source_evidence':'问了对方只能说“是”或者“不是”的封闭式问题','kind':'author_practical_view','distilled':'封闭问题有时提供的延伸信息较少，可以结合实际回应调整问法。','certainty':'情境性建议；不是聊天效果定律'}, {'id':'K2','pages':[3,4],'source_evidence':'所以适当的沉默和倾听也是很有必要的','kind':'author_practical_view','distilled':'不必为填满沉默而持续提问；可根据双方状态倾听或暂停。','certainty':'不把沉默等同于魅力或吸引力'}, {'id':'K3','pages':[4,5],'source_evidence':'保持基本的礼貌的基础上，合理的合适的表达自己的想法和情感','kind':'adaptable_practical_view','distilled':'在尊重对方意愿的前提下，分享与当前话题相关的想法或经历。','certainty':'不把提问与自卑、性别或人格强弱绑定'}, {'id':'K4','pages':[6,7],'source_evidence':'“不好玩，商业化气息太浓厚了”','kind':'source_example','distilled':'可从实际回应中的地点、感受或期待寻找下一步交流线索，再询问验证。','certainty':'线索不等于性格结论；对话能否继续取决于双方情境与意愿'}]
for c in claims:
 assert any(c['source_evidence'].replace('\n','') in ''.join(extracted['pages'][p-1]['text'].splitlines()) for p in c['pages']), c['id']
# K4 spans the p6-to-p7 example; quote belongs specifically to p7.
report={'source_file':'04、无限聊天话题技巧.pdf','source_sha256':extracted['source_sha256'],'pages':7,'evidence_level':'课程作者观点与个人轶事，非同行评审研究','claims':claims,'excluded':['推广联系方式与水印','把提问归因于人格强弱的判断','对性别或相亲群体的概括','用个人经历推断普遍吸引力','忽略对方明确意愿的行为示例'],'selected_claims':['K4','K3'],'no_guarantees':True,'story_boundary':'新增聊天示例属于原创演绎，不伪装为PDF原话或真实经历'}
(A/'knowledge-distillation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
plan={'title':'从回应里找线索','duration_seconds':10,'fps':30,'frames':300,'resolution':[1920,1080],'audio_architecture':'music_and_sfx_no_narration','render_runtime':'remotion','composition_mode':'atelier','source_claims':['K4','K3'],'render_options_considered':[{'runtime':'remotion','decision':'selected','reason':'实际已验证的确定性中文排版与连续路径动画；由OpenMontage调用'}, {'runtime':'hyperframes','decision':'unavailable','reason':'本轮注册表检测不可用，没有伪装成已验证运行'}, {'runtime':'ffmpeg','decision':'selected_for_passthrough_mux','reason':'镜头渲染后保留视频流，避免额外重编码'}, {'runtime':'blender','decision':'not_needed','reason':'该知识关系无需三维材质解释；安装存在但不为本镜头添加无意义建模'}], 'shots':[{'id':'ShotA','timeline_frames':[0,150],'primary_subject':'原始回应中的关键词','action':'旅行路网随回复收拢，镜头放大商业化关键词；同一个词移动到线索起点','meaning':'先关注对方已经表达的内容'}, {'id':'ShotB','timeline_frames':[150,300],'primary_subject':'从词语生长出的感受与期待路径','action':'次要地点支路退后，期待支路连接到一个开放问题，最后停稳供阅读','meaning':'从线索发问，验证而非下定义'}], 'visual_system':{'background':'冷黑灰','accent':'冷薄荷色与克制灰白','type':'本地Noto Sans CJK子集','anti_patterns':['堆砌静态卡片','随机粒子装饰','用亮度或线宽表示好感','以效果承诺代替知识解释']},'authorization':{'source':'用户本轮要求完成知识蒸馏、导演决策并选取10秒验证','scope':['本地集成','新目录','10秒测试','无付费调用'],'not_authorized':['自动扩展整片','改动旧成果','开通付费服务']}}
(A/'director-decision.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2))
texts=['从回应里找线索','丽江这趟，感觉怎么样？','不好玩，商业化气息太浓了。','商业化','地点','感受','期待','可能更在意旅行的氛围？','这是一条待验证的线索','你原本期待的旅行，是什么样的？','原创演绎 · 不据此判断性格']
assert not check_published_text('\n'.join(texts));(A/'published-text.json').write_text(json.dumps(texts,ensure_ascii=False,indent=2));(A/'content-guard.json').write_text(json.dumps({'checked':'all visible copy','matches':[],'status':'passed','not_a_scientific_truth_checker':True},indent=2))
user_music=Path('/workspace/-/unanswered-30s/public/audio/user-music-source.m4a')
r=D.run(Request('music_excerpt','audio.trim',{'operation':'cut','input_path':str(user_music),'output_path':str(P/'assets/music/excerpt.m4a'),'start_seconds':6.1,'end_seconds':16.1,'codec':'copy'},[str(user_music)],cache=True));assert r['success'],r
r=D.run(Request('probe_music','media.probe',{'input_path':str(P/'assets/music/excerpt.m4a')},[str(P/'assets/music/excerpt.m4a')]));assert r['success'],r
print('Prepared source, decision, copy and actual OpenMontage music trim/probe')
