from pathlib import Path
import json,sys,subprocess
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));from orchestrator.dispatch import Dispatcher,Request
D=Dispatcher();P=D.project;A=P/'artifacts';V=P/'visual'
from orchestrator.content import check_published_text
from orchestrator.review import normalize_upstream_review
subprocess.run(["node",str(ROOT/"scripts/extract-copy.cjs")],check=True)
assert not check_published_text("\n".join(json.loads((A/"published-text.json").read_text())))
composition={'render_runtime':'remotion','cuts':[{'id':'a','in_seconds':0,'out_seconds':5,'type':'generated'},{'id':'b','in_seconds':5,'out_seconds':10,'type':'generated'}],'audio':{'music':{'src':str(P/'assets/audio/master.wav')}}}
(A/'composition-preflight.json').write_text(json.dumps(composition,indent=2))
r=D.run(Request('pre_render_validation','timeline.validate',{'composition_path':str(A/'composition-preflight.json'),'assets_root':str(P),'render_runtime':'remotion'},[str(A/'composition-preflight.json'),str(P/'assets/audio/master.wav')]));assert r['success'],r
r=D.run(Request('frame_timeline_validation','timeline.frames',{'fps':30,'frames':300,'clips':[{'id':'ShotA','start_frame':0,'end_frame':150},{'id':'ShotB','start_frame':150,'end_frame':300}]}));assert r['success'],r
proposal={'production_plan':{'render_runtime':'remotion'},'authorization_source':'User requested autonomous 10-second integration verification; no broader production authorized.'}
steps=[]
for name in ['ShotA','ShotB']:
 ed={'render_runtime':'remotion','renderer_family':'bespoke','composition_mode':'atelier','total_duration_seconds':5,'metadata':{'proposal_render_runtime':'remotion','narration_expected':False,'visual_only':True},'bespoke':{'entry':str(V/'src/index.tsx'),'composition_id':name,'public_dir':str(V/'public'),'crf':16,'concurrency':2,'art_direction':'Cold ink-black and mint; original response changes into a keyword anchor, then semantic paths grow toward an open question; no stock visual components.'}}
 params={'operation':'render','edit_decisions':ed,'asset_manifest':{},'proposal_packet':proposal,'output_path':str(P/'assets/video'/f'{name}.mp4')}
 (A/f'{name}-render-request.json').write_text(json.dumps(params,indent=2));steps.append({'request':Request('render_'+name,'video.programmatic',params,[str(V/'src'),str(V/'public')],cache=True,allow_fallback=False)})
r=D.execute_plan(steps)
for name,v in r.items():
 print(name,v['status'],v.get('error'));assert v['success'],v
 raw=v.get('data',{}).get('final_review',{});norm=normalize_upstream_review(raw)
 (A/f'{name}.review-normalized.json').write_text(json.dumps(norm,indent=2))
 assert norm['automatic_gate']!='blocked',norm
stitch=D.run(Request('stitch_main','video.stitch',{'operation':'stitch','clips':[str(P/'assets/video/ShotA.mp4'),str(P/'assets/video/ShotB.mp4')],'transition':'cut','auto_normalize':False,'output_path':str(P/'renders/stitched-video.mp4')},[str(P/'assets/video/ShotA.mp4'),str(P/'assets/video/ShotB.mp4')],cache=True));assert stitch['success'],stitch
mux=D.run(Request('final_mux','video.mux',{'video_path':str(P/'renders/stitched-video.mp4'),'audio_path':str(P/'assets/audio/master.wav'),'duration':10,'output_path':str(P/'renders/NewWorld-ChatTopics-OM-10s.mp4')},[str(P/'renders/stitched-video.mp4'),str(P/'assets/audio/master.wav')]));assert mux['success'],mux
sampler=D.run(Request('sample_final','media.sample',{'input_path':str(P/'renders/NewWorld-ChatTopics-OM-10s.mp4'),'strategy':'timestamps','timestamps':[0,.8,1.5,2.5,3.5,4.8,5,5.3,6.5,7.5,9.5,9.966],'output_dir':str(P/'renders/review'),'format':'png'},[str(P/'renders/NewWorld-ChatTopics-OM-10s.mp4')]));assert sampler['success'],sampler
print('Native OpenMontage render + stitch + frame sample complete; final video mux used stream-copy.')
