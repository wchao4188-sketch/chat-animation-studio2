from pathlib import Path
import json,zipfile,hashlib,shutil
R=Path(__file__).resolve().parents[1];cfg=json.loads((R/'config.json').read_text());P=Path(cfg['project_root']);O=R/'output';O.mkdir(exist_ok=True)
for src,name in [(P/'renders/NewWorld-ChatTopics-OM-10s.mp4','NewWorld-ChatTopics-OM-10s.mp4'),(R/'docs/Workflow.md','Workflow.md'),(R/'docs/Integration-Report.md','Integration-Report.md')]:shutil.copy2(src,O/name)
files=[R/'README.md',R/'config.json'];mapping=[]
for folder in ['orchestrator','tests','scripts','docs','examples','artifacts']:
 for p in (R/folder).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:mapping.append((p,p.relative_to(R)))
for p in files:mapping.append((p,p.relative_to(R)))
for folder in ['visual','assets/audio','assets/music']:
 for p in (P/folder).rglob('*'):
  if p.is_file() and 'node_modules' not in p.parts and '__pycache__' not in p.parts:mapping.append((p,Path('project')/p.relative_to(P)))
for p in (P/'artifacts').rglob('*'):
 if p.is_file() and p.name not in ['pdf-extracted.txt','source-pages.json']:
  mapping.append((p,Path('project')/p.relative_to(P)))
for name in ['quality-check.json','playback-check.json','Keyframes.pdf','source-frame.json']:
 p=O/name
 if p.exists():mapping.append((p,Path('output')/name))
z=O/'NewWorld-Knowledge-System-OM-Source.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
 for p,relative in sorted(mapping,key=lambda x:str(x[1])):archive.write(p,Path('NewWorld-Knowledge-System')/relative)
with zipfile.ZipFile(z) as a:
 assert a.testzip() is None
 assert not any(n.endswith('.pdf') and 'Keyframes' not in n for n in a.namelist())
rows=[]
for p in [O/'NewWorld-ChatTopics-OM-10s.mp4',z,O/'Integration-Report.md',O/'Workflow.md',O/'Keyframes.pdf']:
 rows.append({'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(O/'manifest.json').write_text(json.dumps(rows,indent=2));(O/'SHA256SUMS.txt').write_text('\n'.join(x['sha256']+'  '+x['name'] for x in rows)+'\n');print(json.dumps(rows,indent=2))
