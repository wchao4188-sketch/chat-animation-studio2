from pathlib import Path
import json,sys,hashlib,subprocess
R=Path(__file__).resolve().parents[1];cfg=json.loads((R/'config.json').read_text());P=Path(cfg['project_root']);O=R/'output';q=json.loads((O/'quality-check.json').read_text());t=json.loads((R/'artifacts/integration-tests.json').read_text());p=json.loads((O/'playback-check.json').read_text());env=json.loads((R/'artifacts/environment-report.json').read_text());trans=json.loads((R/'artifacts/transition-test.json').read_text());rhythm=json.loads((P/'artifacts/music-rhythm.json').read_text());repair=json.loads((P/'artifacts/local-repair.json').read_text())
report=f'''# Open Montage实际集成与验证报告

## 本次结果

已在新目录`/workspace/-/knowledge-production-system`建立统一适配层，优先调用本地Open Montage；并依据用户PDF完成7页知识提取、页码证据与原创导演决策，实际制作10秒测试序列《从回应里找线索》。旧作品哈希未改变，未升级原有依赖。

最终MP4：1920×1080、16:9、30fps、300帧，视频及容器均{q['video']['duration']}秒；无新增配音，有原有用户音乐与本地合成音效。{q['file']['bytes']:,}字节，SHA-256 `{q['file']['sha256']}`。

这是针对本次场景运行通过的集成验证，不把工具安装或技术通过描述为电影级审美认证。

## 1. 实际安装与调用方式

- 上游：<https://github.com/calesthio/OpenMontage>。
- 检出提交：`{env['git_revision']}`。`setup.py`及本次使用的Python工具声明版本为0.1.0；没有据此虚构仓库发行版号。
- 路径：`{cfg['openmontage_root']}`；Python：`{cfg['openmontage_python']}`。
- 类型：独立Python项目、仓库内技能和Remotion子工程；不是当前会话已连接的MCP服务，也没有假称存在官方`openmontage`命令。
- 正确调用：通过`tools.tool_registry.registry`发现工具，再调用`tool.execute(params)`。本次的统一CLI是新增的`python -m orchestrator.cli`，它使用隔离子进程与JSON包络接入上游。
- 环境：Python{env['python']}、Node{env['node']}、npm{env['npm']}；Open Montage子工程Remotion{env['composer_dependencies']['remotion']}、React{env['composer_dependencies']['react']}；{env['blender_binary']}已响应版本命令。实际依赖清单另附`environment-report.json`，没有输出密钥。
- 配置：上游`.env.example`、Makefile、requirements与技能文档已读取；本层使用`config.json`声明路径、媒体规格、禁止付费调用与禁止视觉降级。上游运行代码未被改写，浏览器路径与中间画面静音参数由适配器显式传入。

## 2. 真实功能与分工

| 环节 | 本次实际承担者与证据 | 使用边界 |
|---|---|---|
| 素材信息/管理 | Open Montage `audio_probe`、`video_trimmer`、原生`AssetCache`；音乐实际裁切并探测，镜头缓存实际恢复并比对字节 | 不是已验证的语义素材检索库；来源、页码和SHA索引由本层补充 |
| 镜头组织与剪辑 | Open Montage `video_stitch`，实际拼接两个5秒镜头；导演计划与路由另存JSON | 按已明确计划执行，不冒充自动理解任意故事的剪辑模型 |
| 转场 | Remotion负责词语抽离、路径生长和连续画面；Open Montage crossfade另有640×360技术验证，输出{trans['output_seconds']}秒 | 上游crossfade末段命令没有传递CRF/preset，本次主片采用画面内运动＋视频流拼接，避免额外压缩 |
| 时间轴 | Open Montage `composition_validator`验证素材与时长；本层补充整数帧、空隙和总帧数检查 | 实测上游预检没有拒绝测试中的时间轴空隙，不能替代严格帧校验 |
| 音乐节奏 | 本地NumPy对实际音乐做起音和自相关分析，逐项记录动作时刻；主BPM候选{rhythm['bpm_candidates'][0]} | 不把候选值当作人工确认的拍号或重拍；本次没有重新开发已存在的Open Montage混音 |
| 音效 | 本地确定性短音色生成；Open Montage `audio_mixer.full_mix`执行音量、淡入淡出、归一化及精确10秒混音 | 并非已验证的写实音效生成模型或现场录音；外部生成服务未调用 |
| 程序图形与渲染 | Open Montage `video_compose` atelier实际调用项目专属Remotion入口，分别渲染ShotA和ShotB | 不用库存文字卡片冒充连续运动；没有声称三维网格或粒子物理仿真 |
| 三维与人物资产 | Blender二进制已检查，统一路由包含Open Montage的三维工具入口 | 本次内容无需三维或人物表演，未执行三维镜头/人物生成，不计为成片验证通过 |
| 最终合成 | FFmpeg适配器替换混音，复制原视频数据流；封装前后视频流哈希一致 | Open Montage公开compose流程会重新编码裁切片段，本次不重复使用它来完成纯音轨封装 |
| 审核 | Open Montage抽帧、探测与原生渲染检查；另做整片解码、300帧指标、浏览器全长播放与实际画面查看 | 不能用音量推断旁白、不能用基础像素指标证明文字可读；未进行人耳试听 |

## 3. 已成功运行的测试

- 统一适配层实际调用7个Open Montage工具：`audio_probe`、`video_trimmer`、`audio_mixer`、`composition_validator`、`video_compose`、`video_stitch`、`frame_sampler`。请求、返回、命令与哈希均保留。
- {t['tests']}项集成测试运行通过，失败{t['failures']}、异常{t['errors']}。覆盖真实工具调用、缺失输入、缺失媒体、输出路径保护、严格帧时间轴、发布文字约束、依赖阻塞、输入内容改变使缓存失效、实际渲染文件的缓存恢复等。
- 故障回退采用明确标注的故障注入：将Open Montage探测工具临时标为不可用，原生ffprobe实际完成同一文件探测；没有伪称真实服务宕机。
- 三维工具不可用时任务阻塞，没有转成二维；备用渲染入口遇到未实现的props参数时拒绝执行，没有丢弃参数继续。
- 重复镜头任务实际命中Open Montage缓存，恢复文件哈希一致，缓存命中时没有执行Remotion命令。没有虚构节省的金额。
- 最终MP4完整FFmpeg解码退出{q['full_decode']['exit']}，错误输出为空；300帧基础指标已计算。浏览器播放至结束{p['ended']}，总帧{p['frames']}，丢帧{p['dropped']}，媒体错误{p['error']}。
- 实际查看整片半秒总览与Open Montage抽取的高清时点，修复了关键词抽离时的文字重叠；只重渲前5秒，后5秒文件哈希保持`{repair['shot_b_sha256_unchanged']}`，混音复用。
- 屏幕文案从JSX文字节点提取后检查，不再把CSS中的比例字符串误认为效果承诺；词语检查属于辅助约束，不替代语义与事实审查。

## 4. 测试中暴露并处理的问题

1. **中间音轨拉长画面拼接。** 初轮渲染器附带静音AAC，导致封装超过10秒约0.056秒。已改为中间镜头只输出视频，最终统一封装精确10秒混音；原先失败结果另存，不当作通过。
2. **上游审核的语义字段超出检测能力。** 音量阈值不能证明“有旁白”或“混音可懂”；简单抽帧不能证明“文字可读”。原报告保留，规范化报告将这些内容标为未由指标验证，最终画面另行实际检查。
3. **预检未检测时间轴空隙。** 已实测并补充帧级连续性检查，没有把上游成功返回直接当成时间轴完整。
4. **转场编码控制有限。** crossfade技术测试可运行，但末段编码质量参数传递有限；本次不把它用作主片的额外压缩步骤。
5. **运行时可用性有缓存影响。** HyperFrames注册表检测先后有差异；CLI 0.8.184实际运行成功，但没有完成其成片渲染验证，因此没有把它列为本片已验证路径。

## 5. PDF知识蒸馏与本期导演决策

该PDF共7页，内容是课程作者的交流观点和个人经历，不能直接称为研究证据。保留的主题包括：倾听和适度停顿、适当分享、从回应里的具体信息继续交流、用开放问题了解情境。

本次选第6—7页旅行例子，提炼为“商业化”这个词可能包含对旅行氛围的感受或期待，但仍需询问验证。前5秒展示原句并抽出关键词；后5秒从同一锚点生长“感受/期待”两条路径，连接到原创问题：“你原本期待的旅行，是什么样的？”

原文中的推广内容、群体和性别概括、把提问等同于人格强弱的判断、从个人轶事推断普遍吸引力的说法没有进入成片。新增对话标为原创演绎。屏幕文案不使用效果承诺，也不把“无限话题”的资料标题变成视频结论。

## 6. 尚未实现或需要配置的部分

- 未验证外部AI人物、视频、三维资产、音乐或音效生成服务；没有新的付费调用，不因SDK已安装就宣称服务已开通。
- HyperFrames只验证了CLI版本，Blender只验证了二进制与注册入口，尚未通过本系统产出三维镜头。Three.js没有新增独立生产适配器；需要具体三维需求时再选合适路径，不用安装数量替代画面质量。
- 自动剪辑目前执行结构化导演计划，未证明对任意长素材能自主做高质量叙事剪辑。
- 缓存以任务和声明文件为粒度；多产物缓存、跨机器缓存、并发生产队列、任意PDF的无人值守创作仍不属于本次通过范围。
- 声音完成解码和电平检测，但没有真人试听；自动浏览器播放静音，不声称音乐情绪和音效质感已通过人耳验收。
- 本地环境之外的完整重新安装与重渲未验证。工程包不公开分发用户原PDF或全文提取，保留少量页码证据与原创产物。

## 7. 更新后的完整工作流

`资料入库与来源哈希 → 按页蒸馏并标记证据层级 → 原创文案与承诺表达检查 → AI导演形成镜头需求 → 统一适配层按能力与实测状态选工具 → Open Montage素材/预检/渲染入口 → 按需Remotion或其他视觉工具 → Open Montage剪辑与混音 → 保留视频流的最终封装 → 自动技术检查＋实际画面审阅 → 版本化交付及下载校验`。

详见`Workflow.md`，其中列出每阶段输入输出、调用方式、缓存与回退边界。当前Codex承担语义与导演判断，代码执行结构化任务；本次没有把“工具接入”夸大为不需要审阅的全自动创作服务。
'''
(R/'docs/Integration-Report.md').write_text(report);(O/'Integration-Report.md').write_text(report)
print('Report built; exact current video hash',q['file']['sha256'])
