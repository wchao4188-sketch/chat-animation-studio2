from pathlib import Path
from fontTools import subset
from fontTools.ttLib import TTFont
R=Path(__file__).resolve().parents[1];V=R/'project/visual';text=''.join(p.read_text() for p in (V/'src').glob('*.tsx'));chars={ord(c) for c in text if '\u4e00'<=c<='\u9fff'}
for name,source in [('Text','NotoSansCJK-Regular.ttc'),('Display','NotoSansCJK-Bold.ttc')]:
 o=subset.Options();o.font_number=2;o.flavor='woff';f=subset.load_font('/usr/share/fonts/opentype/noto/'+source,o);s=subset.Subsetter(options=o);s.populate(text=text);s.subset(f);dest=V/'public/fonts'/f'{name}.woff';subset.save_font(f,dest,o);assert not(chars-set(TTFont(dest).getBestCmap()))
print('Local fonts cover',len(chars),'Chinese characters')
