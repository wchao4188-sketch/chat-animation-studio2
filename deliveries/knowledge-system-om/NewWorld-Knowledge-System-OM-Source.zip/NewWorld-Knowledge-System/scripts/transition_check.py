from pathlib import Path
import json,sys,subprocess
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R));from orchestrator.dispatch import Dispatcher,Request
D=Dispatcher();P=D.project;r=D.run(Request('transition_fixture','video.stitch',{'operation':'stitch','clips':[str(P/'assets/video/ShotA.mp4'),str(P/'assets/video/ShotB.mp4')],'transition':'crossfade','transition_duration':.4,'target_resolution':'640x360','target_fps':30,'crf':16,'output_path':str(P/'renders/crossfade-validation-only.mp4')},[str(P/'assets/video/ShotA.mp4'),str(P/'assets/video/ShotB.mp4')]))
assert r['success'],r
q=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(P/'renders/crossfade-validation-only.mp4')]));assert abs(float(q['format']['duration'])-9.6)<.1
p=subprocess.run(['ffmpeg','-v','error','-i',str(P/'renders/crossfade-validation-only.mp4'),'-f','null','-'],capture_output=True);assert p.returncode==0 and not p.stderr
v=next(s for s in q['streams'] if s['codec_type']=='video');report={'operation':'OpenMontage.video_stitch crossfade','input_seconds':[5,5],'overlap_seconds':.4,'output_seconds':q['format']['duration'],'resolution':[v['width'],v['height']],'full_decode':'passed','scope':'technical fixture only; main film uses stream-copy cut and authored continuous motion','quality_caveat':'upstream crossfade terminal command does not forward requested crf/preset; not selected for the main delivery quality path'};(R/'artifacts/transition-test.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
