import React,{useEffect,useState}from'react';
import{AbsoluteFill,useCurrentFrame,useVideoConfig,staticFile,delayRender,continueRender}from'remotion';
const WHITE='#e4e8e6',MINT='#b7d8cb',GRAY='#87938f',BG='#111719';
const e=(x:number)=>{x=Math.max(0,Math.min(1,x));return x*x*x*(x*(x*6-15)+10)};
const r=(t:number,a:number,b:number)=>e((t-a)/(b-a));
const m=(a:number,b:number,v:number)=>a+(b-a)*v;
const h=(i:number)=>{let x=Math.sin(i*53.83+9.2)*36547.45;return x-Math.floor(x)};
const Type=({x,y,size=48,children,opacity=1,color=WHITE,width=1600}:{x:number;y:number;size?:number;children:React.ReactNode;opacity?:number;color?:string;width?:number})=><div style={{position:'absolute',left:x,top:y,width,fontFamily:'Text',fontSize:size,lineHeight:1.3,whiteSpace:'pre-wrap',color,opacity}}>{children}</div>;
export const Film=({offset=0}:{offset?:number})=>{
 const f=useCurrentFrame()+offset,{fps}=useVideoConfig(),t=f/fps;
 const[fontHandle]=useState(()=>delayRender('Loading local Chinese font'));
 useEffect(()=>{Promise.all([document.fonts.load('48px Text'),document.fonts.load('72px Display')]).then(()=>continueRender(fontHandle));},[fontHandle]);
 const morph=r(t,3.1,4.8),branches=r(t,4.3,6.5),question=r(t,6.4,7.3),keyword={x:m(775,460,morph),y:m(430,535,morph)};
 const moveCity=r(t,2.6,5.2),cityOpacity=(1-moveCity*.83)*(1-r(t,6.4,7.4));
 return <AbsoluteFill style={{background:BG,overflow:'hidden'}}>
  <style>{`@font-face{font-family:Text;src:url('${staticFile('fonts/Text.woff')}')}@font-face{font-family:Display;src:url('${staticFile('fonts/Display.woff')}')}`}</style>
  <AbsoluteFill style={{background:'radial-gradient(ellipse at 62% 52%,#24302f 0%,#141d20 50%,#0d1216 100%)'}}/>
  <svg width={1920} height={1080} style={{position:'absolute',inset:0}}>
   <defs><linearGradient id="tile" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#46615c"/><stop offset="1" stopColor="#253a37"/></linearGradient><filter id="shadow"><feGaussianBlur stdDeviation="16"/></filter></defs>
   <g opacity={cityOpacity} transform={`translate(${80-110*moveCity} ${20+40*moveCity})`}>
    {Array.from({length:8},(_,i)=><path key={'street'+i} d={`M${250+i*170} 570 L${780+i*90} 910M${300} ${590+i*43}L${1590} ${730+i*20}`} stroke="#6d8c82" opacity=".22" fill="none" strokeWidth="1"/>)}
    {Array.from({length:56},(_,i)=>{const col=i%8,row=Math.floor(i/8),x=300+col*130+row*43,y=570+row*40+col*12,rise=(12+h(i+1)*44)*r(t,.1+(i%8)*.06,.9+(i%8)*.06);return <g key={i} transform={`translate(${x} ${y-rise})`} opacity={.5+h(i)*.35}><path d={`M0 0L65 17L26 35L-39 18Z`} fill="url(#tile)" stroke="#719082" strokeWidth=".7"/><path d={`M-39 18V${18+rise}L26 ${35+rise}L65 ${17+rise}V17L26 35Z`} fill="#253733" stroke="#49675c" strokeWidth=".6"/></g>})}
   </g>
   <g opacity={r(t,.2,.7)*(1-r(t,1.9,2.4))}><path d="M205 205H1020" stroke="#53625d" strokeWidth="1"/><text x={205} y={260} fontFamily="Text" fontSize="45" fill={GRAY}>丽江这趟，感觉怎么样？</text></g>
   <ellipse cx={m(990,460,morph)} cy={m(515,620,morph)} rx={m(500,140,morph)} ry={17} fill="#000" opacity={.35} filter="url(#shadow)"/>
   <rect x={m(420,330,morph)} y={m(337,458,morph)} width={m(1040,260,morph)} height={m(142,114,morph)} rx={m(6,20,morph)} fill={MINT} opacity={r(t,.8,1.3)}/>
   <g fontFamily="Text" fontSize="50" fill="#1a2a27" opacity={r(t,.8,1.3)*(1-r(t,2.85,3.3))}><text x={500} y={430}>不好玩，</text><text x={850} y={430}>气息太浓了。</text></g>
   <text x={keyword.x} y={keyword.y} textAnchor="middle" fontFamily="Display" fontWeight="700" fontSize={m(50,62,morph)} fill="#1a2a27" opacity={r(t,.8,1.3)}>商业化</text>
   <path d={`M${keyword.x-74} ${keyword.y+14}H${keyword.x+74}`} stroke="#1d5545" strokeWidth={3} pathLength={1} strokeDasharray={1} strokeDashoffset={1-r(t,1.7,2.3)} opacity={1-morph}/>
   <g opacity={branches}>
    <path d="M590 515C720 515 752 375 900 375" stroke={MINT} strokeWidth="2" fill="none" pathLength={1} strokeDasharray={1} strokeDashoffset={1-r(t,4.4,5.35)}/>
    <path d="M590 515C720 515 760 660 900 660" stroke={MINT} strokeWidth="2" fill="none" pathLength={1} strokeDasharray={1} strokeDashoffset={1-r(t,4.9,5.85)}/>
    <path d="M590 515C700 515 650 810 840 810" stroke={GRAY} strokeWidth="1.2" opacity={.3} fill="none" pathLength={1} strokeDasharray={1} strokeDashoffset={1-r(t,4.6,5.7)}/>
    <g opacity={r(t,5,5.5)}><circle cx={900} cy={375} r={8} fill={MINT}/><text x={930} y={389} fontFamily="Text" fontSize="39" fill={WHITE}>感受</text></g>
    <g opacity={r(t,5.5,6)}><circle cx={900} cy={660} r={8} fill={MINT}/><text x={930} y={674} fontFamily="Text" fontSize="39" fill={WHITE}>期待</text></g>
    <text x={870} y={824} fontFamily="Text" fontSize="31" fill={GRAY} opacity={.45}>地点</text>
    <path d="M1028 660C1110 660 1040 470 1110 470" stroke={MINT} strokeWidth="1.4" fill="none" pathLength={1} strokeDasharray={1} strokeDashoffset={1-r(t,6,6.9)}/>
   </g>
   <path d="M120 960H1800" stroke="#414c48" strokeWidth="1"/><path d={`M120 960H${120+1680*f/299}`} stroke={MINT} strokeWidth="1"/>
  </svg>
  <Type x={120} y={65} size={22} color={GRAY}>新世界 / 从回应里找线索</Type>
  <Type x={120} y={130} size={72} opacity={r(t,2.5,3.1)*(1-r(t,6.5,7.1))}>{'这句回应，\n还可能聊些什么？'}</Type>
  <Type x={120} y={140} size={68} opacity={r(t,6.6,7.2)}>{'接住回应，\n再试着了解。'}</Type>
  <Type x={1090} y={260} size={30} color={GRAY} width={710} opacity={r(t,5.5,6.2)*(1-r(t,6.5,7))}>可能更在意旅行的氛围？</Type>
  <Type x={1130} y={395-20*question} size={53} width={700} opacity={question}>{'你原本期待的旅行，\n是什么样的？'}</Type>
  <Type x={1130} y={570} size={26} color={MINT} width={650} opacity={r(t,7,7.6)}>一种接话尝试 · 仍需结合对方回应</Type>
  <Type x={120} y={866} size={26} color={GRAY} opacity={r(t,4.3,5)}>这是一条待验证的线索，不是性格结论。</Type>
  <Type x={120} y={992} size={21} color={GRAY}>依据所提供资料第6—7页改编 · 新增对话为原创演绎</Type>
 </AbsoluteFill>;
};
