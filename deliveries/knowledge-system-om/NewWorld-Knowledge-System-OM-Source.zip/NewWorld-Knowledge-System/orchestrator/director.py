"""Translate explicit shot requirements to eligible tools, not free-form taste claims."""
from .dispatch import Dispatcher
ROUTES={'programmatic_graphics':'video.programmatic','abstract_3d':'scene.3d','footage_edit':'video.stitch','audio_mix':'audio.mix','rhythm_analysis':'audio.rhythm'}
def route_shots(scene_plan,dispatcher=None):
 d=dispatcher or Dispatcher();out=[]
 for shot in scene_plan['shots']:
  technique=shot.get('technique','programmatic_graphics');cap=ROUTES.get(technique)
  if not cap:out.append({'shot':shot['id'],'status':'blocked','reason':'No verified tool route for '+technique});continue
  tool,err=d.choose(cap,allow_fallback=False);out.append({'shot':shot['id'],'technique':technique,'capability':cap,'tool':tool,'status':'selected' if tool else 'blocked','reason':err or 'OpenMontage preferred for eligible installed capabilities; creative treatment unchanged','still_needs_authored_inputs':True})
 return out
