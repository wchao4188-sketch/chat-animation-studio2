"""Content-grounded production adapters. Creative decisions remain explicit artifacts."""
