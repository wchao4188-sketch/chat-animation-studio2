"""python -m orchestrator.cli capabilities | run task.json | plan plan.json"""
import argparse,json
from pathlib import Path
from dataclasses import fields
from .dispatch import Dispatcher,Request

def main():
 p=argparse.ArgumentParser();p.add_argument('command',choices=['capabilities','run','plan']);p.add_argument('input',nargs='?');p.add_argument('--output');a=p.parse_args();d=Dispatcher()
 if a.command=='capabilities':
  from .dispatch import POLICY
  from .contracts import NATIVE_INPUTS,ENVELOPE
  rows=[]
  for cap,tools in POLICY.items():
   for tool in tools:
    i=d.catalog['tools'].get(tool.removeprefix('om.'),{});rows.append({'capability':cap,'tool':tool,'available':d.available(tool),'input_schema':i.get('input_schema',NATIVE_INPUTS.get(tool,{})),'output_schema':ENVELOPE,'raw_data_schema':i.get('output_schema',{}),'version':i.get('version','local-adapter-1'),'stability':i.get('stability','local_integration'),'validation':'declared; see integration report for executed operations'})
  result={'tools':rows,'output_envelope':{'success':'boolean','status':'succeeded|cached|failed','error_code':'string|null','data':'tool-specific object','attempts':'array','artifact_hashes':'path -> SHA-256'},'not_all_declared_features_have_been_tested':True}
 else:
  content=json.loads(Path(a.input).read_text());names={f.name for f in fields(Request)}
  if a.command=='run':result=d.run(Request(**{k:v for k,v in content.items() if k in names}))
  else:result=d.execute_plan([{'request':Request(**{k:v for k,v in step.items() if k in names}),'depends_on':step.get('depends_on',[])} for step in content])
 text=json.dumps(result,indent=2,ensure_ascii=False)
 if a.output:Path(a.output).write_text(text)
 else:print(text)
if __name__=='__main__':main()
