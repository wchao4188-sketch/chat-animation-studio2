from __future__ import annotations
from pathlib import Path
import json,hashlib,subprocess,time,uuid,shutil,os
from dataclasses import dataclass,field,asdict
ROOT=Path(__file__).resolve().parents[1]
POLICY={
 'media.probe':['om.audio_probe','ffmpeg.probe'],
 'media.sample':['om.frame_sampler'],
 'timeline.validate':['om.composition_validator'],
 'audio.trim':['om.video_trimmer'],
 'audio.mix':['om.audio_mixer'],
 'video.programmatic':['om.video_compose','remotion.render'],
 'video.stitch':['om.video_stitch'],
 'video.mux':['ffmpeg.mux'],
 'scene.3d':['om.blender_world'],
 'audio.rhythm':['local.rhythm'],
 'audio.sfx':['local.sfx'],
 'timeline.frames':['local.timeline'],
}
@dataclass
class Request:
 id:str
 capability:str
 params:dict
 inputs:list[str]=field(default_factory=list)
 cache:bool=False
 allow_fallback:bool=False

class Dispatcher:
 def __init__(self,config=None):
  self.config=config or json.loads((ROOT/'config.json').read_text());self.project=Path(self.config['project_root']);self.jobs=self.project/'artifacts/jobs';self.jobs.mkdir(parents=True,exist_ok=True);self.faults=set()
  report=ROOT/'artifacts/installed-tools.json'
  if not report.exists():self._worker({'mode':'discover'},'discover',report)
  self.catalog=json.loads(report.read_text())
 def _worker(self,payload,job_id,response=None):
  ident=f'{job_id}-{uuid.uuid4().hex[:8]}';request=self.jobs/(ident+'.request.json');response=response or self.jobs/(ident+'.result.json');request.write_text(json.dumps({**payload,'config':self.config},indent=2));log=self.jobs/(ident+'.log')
  try:
   with log.open('w') as f:r=subprocess.run([self.config['openmontage_python'],str(ROOT/'orchestrator/om_worker.py'),str(request),str(response)],stdout=f,stderr=f,timeout=1900)
   if not response.exists():return {'success':False,'error_code':'WORKER_FAILED','error':f'Worker exited {r.returncode}','log':str(log)}
   out=json.loads(response.read_text());out['log']=str(log);return out
  except subprocess.TimeoutExpired:return {'success':False,'error_code':'TIMEOUT','error':'Tool process exceeded 1900 seconds','log':str(log)}
 def available(self,tool):
  if tool in self.faults:return False
  if tool.startswith('om.'):return self.catalog['tools'].get(tool[3:],{}).get('status')=='available'
  if tool.startswith('ffmpeg.'):return bool(shutil.which('ffmpeg') and shutil.which('ffprobe'))
  if tool.startswith('local.'):return True
  if tool=='remotion.render':return Path(self.config['openmontage_root'],'remotion-composer/node_modules/.bin/remotion').exists()
  return False
 def choose(self,capability,allow_fallback=False):
  options=POLICY.get(capability,[])
  if not options:return None,{'code':'UNSUPPORTED_CAPABILITY','message':capability}
  for n,tool in enumerate(options):
   if n and not allow_fallback:break
   if self.available(tool):return tool,None
  return None,{'code':'UNAVAILABLE','message':'No eligible tool; no change of visual treatment is permitted','considered':options}
 def _fingerprint(self,req,tool):
  files={}
  for name in req.inputs:
   p=Path(name)
   if not p.exists():raise ValueError('Missing declared input: '+name)
   for f in sorted(p.rglob('*')) if p.is_dir() else [p]:
    if f.is_file() and 'node_modules' not in f.parts:files[str(f)]=hashlib.sha256(f.read_bytes()).hexdigest()
  params={k:v for k,v in req.params.items() if k not in ['output_path','output_dir']};version=self.catalog['tools'].get(tool.removeprefix('om.'),{}).get('version','adapter-1')
  signature={'tool':tool,'version':version,'upstream':self.catalog['revision'],'adapter_sha256':hashlib.sha256((ROOT/'orchestrator/om_worker.py').read_bytes()+(ROOT/'orchestrator/dispatch.py').read_bytes()).hexdigest(),'params':params,'files':files,'browser':self.config['browser']}
  return hashlib.sha256(json.dumps(signature,sort_keys=True).encode()).hexdigest()
 def _native(self,tool,p):
  from orchestrator import local_tools
  from orchestrator.contracts import NATIVE_INPUTS
  import jsonschema
  try:jsonschema.validate(p,NATIVE_INPUTS.get(tool,{}))
  except jsonschema.ValidationError as e:return {"success":False,"error_code":"INVALID_INPUT","error":e.message}
  required={'ffmpeg.probe':['input_path'],'ffmpeg.mux':['video_path','audio_path','duration','output_path'],'remotion.render':['edit_decisions','output_path'],'local.rhythm':['input_path','output_path'],'local.sfx':['duration','events','output_path'],'local.timeline':['fps','frames','clips']}.get(tool,[])
  if any(k not in p for k in required):return {'success':False,'error_code':'INVALID_INPUT','error':'Missing required native-tool input'}
  if tool.startswith('local.'):
   try:
    data=getattr(local_tools,tool[6:])(p);return {'success':data.get('valid',True),'data':data,'error_code':None if data.get('valid',True) else 'INVALID_TIMELINE','artifacts':[p['output_path']] if p.get('output_path') else []}
   except Exception as ex:return {'success':False,'error_code':'LOCAL_FAILED','error':str(ex)}
  if tool=='ffmpeg.probe':cmd=['ffprobe','-v','error','-show_format','-show_streams','-of','json',p['input_path']]
  elif tool=='ffmpeg.mux':cmd=['ffmpeg','-v','error','-y','-i',p['video_path'],'-i',p['audio_path'],'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','256k','-t',str(p['duration']),'-movflags','+faststart',p['output_path']]
  elif tool=='remotion.render':
   b=p['edit_decisions']['bespoke'];cmd=[str(Path(self.config['openmontage_root'],'remotion-composer/node_modules/.bin/remotion')),'render',b['entry'],b['composition_id'],p['output_path'],'--browser-executable='+self.config['browser'],'--public-dir='+b['public_dir'],'--codec=h264','--crf='+str(b.get('crf',16)),'--concurrency=2']
  else:return {'success':False,'error_code':'UNSUPPORTED_OPERATION','error':tool}
  try:
   r=subprocess.run(cmd,capture_output=True,text=True,timeout=1800,cwd=Path(self.config['openmontage_root'])/'remotion-composer');data=json.loads(r.stdout) if tool=='ffmpeg.probe' and r.returncode==0 else {'output':p.get('output_path')}
   return {'success':r.returncode==0,'error_code':None if r.returncode==0 else 'NATIVE_FAILED','error':r.stderr[-3000:] if r.returncode else None,'data':data,'commands':[cmd],'artifacts':[p['output_path']] if p.get('output_path') and r.returncode==0 else []}
  except (subprocess.TimeoutExpired,OSError,ValueError) as e:return {'success':False,'error_code':'NATIVE_FAILED','error':str(e)}
 def run(self,req:Request):
  start=time.monotonic();attempts=[]
  # Outputs cannot overwrite user inputs or escape this new integration project.
  for key in ['output_path','output_dir']:
   if req.params.get(key):
    out=Path(req.params[key]).resolve()
    if not out.is_relative_to(self.project.resolve()):return self._finish(req,{'success':False,'error_code':'OUTPUT_POLICY','error':'Output must stay inside the integration project'},[],start)
    if any(out==Path(x).resolve() for x in req.inputs):return self._finish(req,{'success':False,'error_code':'OUTPUT_POLICY','error':'Refusing to overwrite an input'},[],start)
  options=POLICY.get(req.capability,[])
  if not options:return self._finish(req,{'success':False,'error_code':'UNSUPPORTED_CAPABILITY','error':req.capability},[],start)
  for index,tool in enumerate(options):
   if index and not req.allow_fallback:break
   if not self.available(tool):attempts.append({'tool':tool,'status':'unavailable','fault_injected':tool in self.faults});continue
   try:key=self._fingerprint(req,tool)
   except ValueError as e:return self._finish(req,{'success':False,'error_code':'INVALID_INPUT','error':str(e)},attempts,start)
   self._event({'task':req.id,'status':'running','tool':tool})
   result=self._worker({'tool':tool[3:],'params':req.params,'cache_key':key if req.cache else None},req.id) if tool.startswith('om.') else self._native(tool,req.params)
   attempts.append({'tool':tool,'status':'cached' if result.get('from_cache') else ('succeeded' if result.get('success') else 'failed'),'error_code':result.get('error_code'),'error':result.get('error')})
   result['tool']=tool
   if result.get('success'):return self._finish(req,result,attempts,start)
   # Invalid content/input is not an availability issue; no fallback hides it.
   if result.get('error_code') not in ['UNAVAILABLE','TIMEOUT','WORKER_FAILED']:return self._finish(req,result,attempts,start)
  return self._finish(req,{'success':False,'error_code':'UNAVAILABLE','error':'No compatible available tool; job blocked rather than replacing its visual treatment'},attempts,start)
 def _event(self,row):
  with (self.project/'artifacts/events.jsonl').open('a') as f:f.write(json.dumps(row,default=str)+'\n')
 def _finish(self,req,result,attempts,start):
  result={**result,'id':req.id,'capability':req.capability,'attempts':attempts,'elapsed_seconds':round(time.monotonic()-start,4)};result['status']='cached' if result.get('from_cache') else ('succeeded' if result.get('success') else 'failed');result['artifact_hashes']={str(p):hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in result.get('artifacts',[]) if Path(p).is_file()};self._event({'task':req.id,'status':result['status'],'tool':result.get('tool'),'error_code':result.get('error_code')});(self.project/'artifacts'/f'{req.id}.result.json').write_text(json.dumps(result,indent=2,default=str));return result
 def execute_plan(self,steps):
  results={}
  for step in steps:
   deps=step.get('depends_on',[])
   if any(not results.get(k,{}).get('success') for k in deps):results[step['request'].id]={'success':False,'status':'blocked','error_code':'DEPENDENCY_FAILED'};continue
   results[step['request'].id]=self.run(step['request'])
  return results
