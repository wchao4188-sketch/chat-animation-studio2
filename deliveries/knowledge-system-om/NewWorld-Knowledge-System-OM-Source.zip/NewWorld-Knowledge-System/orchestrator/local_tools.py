"""Small gaps not supplied by the installed OpenMontage tool set."""
from pathlib import Path
import json,subprocess,wave
import numpy as np

def rhythm(params):
 raw=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',params['input_path'],'-ar','12000','-ac','1','-f','f32le','-']),'<f4');hop=240;n=len(raw)//hop;x=np.sqrt(np.mean(raw[:n*hop].reshape(n,hop)**2,axis=1));on=np.maximum(np.diff(x,prepend=x[0]),0);c=on-on.mean();ac=np.correlate(c,c,'full')[len(c)-1:];lags=np.arange(20,min(76,len(c)));rank=lags[np.argsort(ac[lags])[-5:][::-1]]
 peaks=[i for i in range(1,len(on)-1) if on[i]>on[i-1] and on[i]>=on[i+1] and on[i]>np.percentile(on,75)]
 events=params.get('events',[]);r={'duration':len(raw)/12000,'bpm_candidates':[round(float(60/(k*.02)),3) for k in rank],'onsets_seconds':[round(i*.02,3) for i in peaks],'events':[dict(e,frame=round(e['time']*30),nearest_onset_seconds=round(min((abs(i*.02-e['time']) for i in peaks),default=999),3)) for e in events],'method':'20ms RMS energy positive differences and autocorrelation; candidates, not manually identified downbeats','human_listening':False};Path(params['output_path']).write_text(json.dumps(r,indent=2));return r

def sfx(params):
 if any(e['time']>=params['duration'] for e in params['events']):raise ValueError('SFX event is outside the declared duration')
 sr=48000;N=int(params['duration']*sr);audio=np.zeros((N,2));rng=np.random.default_rng(692)
 for j,ev in enumerate(params['events']):
  i=round(ev['time']*sr);n=min(round(.7*sr),N-i);q=np.arange(n)/sr;env=(1-np.exp(-q*120))*np.exp(-q*10);f=450+j*65;tone=(np.sin(2*np.pi*f*q)+.2*np.sin(2*np.pi*f*1.5*q))*env*.045;noise=rng.normal(0,1,n);noise=np.convolve(noise,np.ones(7)/7,'same')*env*.011;sig=tone+noise;audio[i:i+n,0]+=sig*.9;audio[i:i+n,1]+=sig
 with wave.open(params['output_path'],'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((audio*32767).astype('<i2').tobytes())
 return {'sample_rate':sr,'duration':N/sr,'events':params['events'],'method':'local deterministic synthesis; not recorded-material SFX'}

def timeline(params):
 fps=params['fps'];frames=params['frames'];clips=params['clips'];issues=[];prev=0
 for c in clips:
  if c['start_frame']!=prev:issues.append('Gap or unintended overlap before '+c['id'])
  if c['end_frame']<=c['start_frame']:issues.append('Invalid interval '+c['id'])
  if not isinstance(c['start_frame'],int) or not isinstance(c['end_frame'],int):issues.append('Subframe edit '+c['id'])
  prev=c['end_frame']
 if prev!=frames:issues.append('Timeline does not cover the declared frame count')
 return {'valid':not issues,'issues':issues,'frames':frames,'fps':fps,'duration':frames/fps}
