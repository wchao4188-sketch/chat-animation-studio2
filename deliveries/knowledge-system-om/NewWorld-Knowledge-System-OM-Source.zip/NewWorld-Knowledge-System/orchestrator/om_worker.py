"""Isolated OpenMontage worker; JSON input/output, no credential output."""
from pathlib import Path
import sys,json,os,subprocess,hashlib,traceback,time
from dataclasses import asdict
import jsonschema

def main():
 request=Path(sys.argv[1]);response=Path(sys.argv[2]);req=json.loads(request.read_text());cfg=req['config'];root=Path(cfg['openmontage_root']);sys.path.insert(0,str(root));os.chdir(root)
 os.environ['npm_config_cache']='/tmp/new-world-skills-npm-cache';os.environ['OPENMONTAGE_ASSET_CACHE_DIR']=str(Path(cfg['project_root'])/'cache/native');os.environ['OPENMONTAGE_ASSET_CACHE']='0'
 from tools.tool_registry import registry
 from tools.video.video_compose import VideoCompose
 from tools.base_tool import BaseTool
 from lib.asset_cache import AssetCache
 commands=[]
 original_command=BaseTool.run_command
 def audited_command(self,cmd,*,timeout=None,cwd=None):
  commands.append(list(cmd))
  return original_command(self,cmd,timeout=timeout,cwd=cwd)
 BaseTool.run_command=audited_command
 class ConfiguredCompose(VideoCompose):
  def run_command(self,cmd,*,timeout=None,cwd=None):
   cmd=list(cmd)
   if len(cmd)>2 and cmd[:3]==['npx','remotion','render']:
    cmd += ['--browser-executable='+cfg['browser'],'--codec=h264','--pixel-format=yuv420p']
    if req['params'].get('edit_decisions',{}).get('metadata',{}).get('visual_only'):cmd.append('--muted')
   return super().run_command(cmd,timeout=timeout,cwd=cwd)
 registry.discover();registry._tools['video_compose']=ConfiguredCompose()
 mode=req.get('mode','execute')
 if mode=='discover':
  infos={n:t.get_info() for n,t in registry._tools.items()};out={'success':True,'summary':registry.provider_menu_summary(),'tools':infos,'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()};response.write_text(json.dumps(out,indent=2));return
 name=req['tool'];params=req['params'];tool=registry._tools.get(name)
 if tool is None:response.write_text(json.dumps({'success':False,'error_code':'UNAVAILABLE','error':'Unknown OpenMontage tool'}));return
 info=tool.get_info()
 if info.get('status')!='available':response.write_text(json.dumps({'success':False,'error_code':'UNAVAILABLE','error':name+' reports unavailable','tool_info':info}));return
 if info.get('runtime') not in ['local'] and not cfg['allow_paid_calls']:
  response.write_text(json.dumps({'success':False,'error_code':'POLICY_BLOCKED','error':'External provider execution is disabled in this integration test'}));return
 try:jsonschema.validate(params,info.get('input_schema',{}))
 except jsonschema.ValidationError as e:response.write_text(json.dumps({'success':False,'error_code':'INVALID_INPUT','error':e.message}));return
 cache=AssetCache(Path(cfg['project_root'])/'cache/artifacts',cfg['cache_max_bytes']);dest=Path(params['output_path']) if params.get('output_path') else None;key=req.get('cache_key');start=time.monotonic()
 if key and dest:
  meta=cache.try_restore(key,dest)
  if meta:
   data=meta['data'];expected=data.get('_integration_sha256');actual=hashlib.sha256(dest.read_bytes()).hexdigest()
   if expected==actual:
    response.write_text(json.dumps({'success':True,'data':data.get('tool_result',{}),'artifacts':[str(dest)],'from_cache':True,'tool_version':info['version'],'cache_key':key,'elapsed':time.monotonic()-start,'commands':[]}));return
   # Corrupt bytes are retained as a diagnostic, never accepted as a cache hit.
   dest.rename(dest.with_suffix(dest.suffix+'.cache-corrupt'))
 try:
  result=tool.execute(params);out=asdict(result);out['error_code']=None if result.success else 'TOOL_FAILED';out['tool_version']=info['version'];out['commands']=commands;out['elapsed']=time.monotonic()-start
  if result.success and dest and key and dest.is_file():
   cache.store(key,dest,tool_name=name,tool_version=info['version'],cost_usd=0,data={'_integration_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'tool_result':result.data})
  out['cache_key']=key
 except Exception as e:out={'success':False,'error_code':'TOOL_EXCEPTION','error':str(e),'commands':commands}
 response.write_text(json.dumps(out,indent=2,default=str))
if __name__=='__main__':
 try:main()
 except Exception as e:Path(sys.argv[2]).write_text(json.dumps({'success':False,'error_code':'WORKER_EXCEPTION','error':str(e)}));raise
