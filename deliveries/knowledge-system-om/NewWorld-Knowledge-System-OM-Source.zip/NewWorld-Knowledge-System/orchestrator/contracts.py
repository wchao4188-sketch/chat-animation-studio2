"""Native adapter contracts; OpenMontage schemas are reused directly."""
def obj(required,properties):return {'type':'object','required':required,'properties':properties}
S={'type':'string'};N={'type':'number','exclusiveMinimum':0};event={'type':'object','required':['time'],'properties':{'time':{'type':'number','minimum':0},'label':S}}
NATIVE_INPUTS={
 'ffmpeg.probe':obj(['input_path'],{'input_path':S}),
 'ffmpeg.mux':obj(['video_path','audio_path','duration','output_path'],{'video_path':S,'audio_path':S,'duration':N,'output_path':S}),
 'remotion.render':obj(['edit_decisions','output_path'],{'edit_decisions':{'type':'object','required':['bespoke']},'output_path':S}),
 'local.rhythm':obj(['input_path','output_path'],{'input_path':S,'output_path':S,'events':{'type':'array','items':event}}),
 'local.sfx':obj(['duration','events','output_path'],{'duration':N,'output_path':S,'events':{'type':'array','items':event}}),
 'local.timeline':obj(['fps','frames','clips'],{'fps':{'type':'integer','minimum':1},'frames':{'type':'integer','minimum':1},'clips':{'type':'array','minItems':1,'items':{'type':'object','required':['id','start_frame','end_frame'],'properties':{'id':S,'start_frame':{'type':'integer','minimum':0},'end_frame':{'type':'integer','minimum':1}}}}})
}
ENVELOPE={'type':'object','required':['success','status','capability','attempts','artifact_hashes'],'properties':{'success':{'type':'boolean'},'status':{'enum':['succeeded','cached','failed']},'data':{'type':'object'},'error_code':{'type':['string','null']},'attempts':{'type':'array'},'artifact_hashes':{'type':'object'}}}

NATIVE_INPUTS['remotion.render']['properties']['edit_decisions']={'type':'object','required':['bespoke'],'properties':{'bespoke':{'type':'object','required':['entry','composition_id','public_dir'],'additionalProperties':False,'properties':{'entry':S,'composition_id':S,'public_dir':S,'crf':{'type':'integer','minimum':0,'maximum':51},'concurrency':{'type':'integer','minimum':1},'art_direction':S}}}}
