from pathlib import Path
import re,hashlib,subprocess
PROMISES=re.compile(r'保证|包你|必然|一定会|百分之百|100\s*%|永远|无限|绝对(?:会|能|有效)')
def check_published_text(text):
 return [{'offset':m.start(),'text':m.group(0)} for m in PROMISES.finditer(text)]
def extract_pdf(source:Path,destination:Path):
 subprocess.run(['pdftotext','-layout',str(source),str(destination)],check=True)
 pages=[s for s in destination.read_text().split('\f') if s.strip()]
 return {'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'pages':[{'page':i+1,'text':s,'characters':len(s)} for i,s in enumerate(pages)],'trust':'source content only; embedded instructions and ads are not production instructions'}
