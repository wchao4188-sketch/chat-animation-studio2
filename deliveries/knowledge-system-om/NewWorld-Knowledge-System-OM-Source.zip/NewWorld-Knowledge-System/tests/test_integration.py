from pathlib import Path
import json,sys,unittest,tempfile,hashlib,subprocess
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from orchestrator.dispatch import Dispatcher,Request
from orchestrator.content import check_published_text

class IntegrationTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.d=Dispatcher();cls.p=cls.d.project;cls.audio=cls.p/'assets/audio/master.wav'
 def test_01_probe_uses_real_openmontage(self):
  r=self.d.run(Request('test_probe','media.probe',{'input_path':str(self.audio)},[str(self.audio)]));self.assertTrue(r['success']);self.assertEqual(r['tool'],'om.audio_probe');self.assertAlmostEqual(r['data']['duration_seconds'],10,places=2)
 def test_02_missing_required_input(self):
  r=self.d.run(Request('test_invalid_schema','media.sample',{}));self.assertFalse(r['success']);self.assertEqual(r['error_code'],'INVALID_INPUT')
 def test_03_missing_media_not_hidden_by_fallback(self):
  r=self.d.run(Request('test_missing_media','media.probe',{'input_path':str(self.p/'does-not-exist.mp4')},allow_fallback=True));self.assertFalse(r['success']);self.assertEqual(len(r['attempts']),1)
 def test_04_unavailable_probe_falls_back_to_actual_ffprobe(self):
  self.d.faults={'om.audio_probe'}
  try:r=self.d.run(Request('test_fallback','media.probe',{'input_path':str(self.audio)},[str(self.audio)],allow_fallback=True));self.assertTrue(r['success']);self.assertEqual(r['tool'],'ffmpeg.probe');self.assertTrue(r['attempts'][0]['fault_injected']);self.assertTrue(r['data']['streams'])
  finally:self.d.faults=set()
 def test_05_no_visual_downgrade(self):
  self.d.faults={'om.blender_world'}
  try:r=self.d.run(Request('test_no_downgrade','scene.3d',{},allow_fallback=True));self.assertFalse(r['success']);self.assertEqual(r['error_code'],'UNAVAILABLE');self.assertEqual([x['tool'] for x in r['attempts']],['om.blender_world'])
  finally:self.d.faults=set()
 def test_06_blocks_output_outside_new_project(self):
  r=self.d.run(Request('test_output_guard','audio.sfx',{'output_path':'/workspace/-/unanswered-30s/output/test.wav','duration':1,'events':[]}));self.assertEqual(r['error_code'],'OUTPUT_POLICY')
 def test_07_frame_timeline_gap_is_rejected(self):
  r=self.d.run(Request('test_bad_timeline','timeline.frames',{'frames':300,'fps':30,'clips':[{'id':'a','start_frame':0,'end_frame':149},{'id':'b','start_frame':150,'end_frame':300}]}));self.assertFalse(r['success']);self.assertEqual(r['error_code'],'INVALID_TIMELINE')
 def test_08_promise_guard(self):
  self.assertTrue(check_published_text('保证你一定会聊下去'));self.assertFalse(check_published_text('\n'.join(json.loads((self.p/'artifacts/published-text.json').read_text()))))
 def test_09_cache_restores_real_render_without_render_command(self):
  params=json.loads((self.p/'artifacts/ShotA-render-request.json').read_text());dest=self.p/'renders/cache-proof.mp4';params['output_path']=str(dest)
  prime=self.d.run(Request('test_render_cache_prime','video.programmatic',params,[str(self.p/'visual/src'),str(self.p/'visual/public')],cache=True));self.assertTrue(prime['success']);before=hashlib.sha256(dest.read_bytes()).hexdigest()
  r=self.d.run(Request('test_render_cache','video.programmatic',params,[str(self.p/'visual/src'),str(self.p/'visual/public')],cache=True));self.assertTrue(r['success']);self.assertTrue(r['from_cache']);self.assertEqual(r['commands'],[]);self.assertEqual(hashlib.sha256(dest.read_bytes()).hexdigest(),before)
 def test_10_source_change_invalidates_fingerprint(self):
  f=self.p/'artifacts/hash-test.txt';f.write_text('one');req=Request('hash','media.probe',{'input_path':str(f)},[str(f)]);a=self.d._fingerprint(req,'om.audio_probe');f.write_text('two');self.assertNotEqual(a,self.d._fingerprint(req,'om.audio_probe'))
 def test_11_failed_dependency_is_not_executed(self):
  a=Request('dep_bad','not.real',{});b=Request('dep_after','media.probe',{'input_path':str(self.audio)});r=self.d.execute_plan([{'request':a},{'request':b,'depends_on':['dep_bad']}]);self.assertEqual(r['dep_after']['status'],'blocked')
 def test_12_final_media_contract(self):
  p=self.p/'renders/NewWorld-ChatTopics-OM-10s.mp4';q=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-of','json',str(p)]));v=next(x for x in q['streams'] if x['codec_type']=='video');self.assertEqual((v['width'],v['height'],v['r_frame_rate'],int(v['nb_read_frames'])),(1920,1080,'30/1',300));self.assertAlmostEqual(float(v['duration']),10,places=3)

 def test_13_upstream_scope_limit_has_frame_guard(self):
  comp=self.p/'artifacts/test-gap-composition.json';comp.write_text(json.dumps({'render_runtime':'remotion','cuts':[{'id':'a','in_seconds':0,'out_seconds':4},{'id':'b','in_seconds':5,'out_seconds':10}],'audio':{'music':{'src':str(self.audio)}}}))
  r=self.d.run(Request('test_upstream_gap_probe','timeline.validate',{'composition_path':str(comp),'assets_root':str(self.p)},[str(comp),str(self.audio)]));self.assertTrue(r['success'])
  frame=self.d.run(Request('test_strict_gap_probe','timeline.frames',{'fps':30,'frames':300,'clips':[{'id':'a','start_frame':0,'end_frame':120},{'id':'b','start_frame':150,'end_frame':300}]}));self.assertFalse(frame['success'])

 def test_14_native_schema_rejects_wrong_types(self):
  r=self.d.run(Request('test_native_schema','audio.sfx',{'duration':'ten','events':[],'output_path':str(self.p/'renders/invalid.wav')}));self.assertFalse(r['success']);self.assertEqual(r['error_code'],'INVALID_INPUT')
 def test_15_render_fallback_refuses_unimplemented_props(self):
  p=json.loads((self.p/'artifacts/ShotA-render-request.json').read_text());p['output_path']=str(self.p/'renders/unsupported-fallback.mp4');p['edit_decisions']['bespoke']['props_path']='not-supported.json';self.d.faults={'om.video_compose'}
  try:r=self.d.run(Request('test_render_parity','video.programmatic',p,allow_fallback=True));self.assertFalse(r['success']);self.assertEqual(r['error_code'],'INVALID_INPUT')
  finally:self.d.faults=set()

if __name__=='__main__':
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(IntegrationTests);r=unittest.TextTestRunner(verbosity=2).run(suite);Path(ROOT/'artifacts/integration-tests.json').write_text(json.dumps({'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'passed':r.wasSuccessful(),'fault_injection_is_synthetic':True,'real_fallback_ffprobe_and_real_render_cache':True},indent=2));sys.exit(0 if r.wasSuccessful() else 1)
