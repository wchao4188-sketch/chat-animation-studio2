"""Full anonymous HTTP GET verification of committed delivery files."""
from pathlib import Path
import hashlib,json,subprocess,urllib.request,zipfile,io
R=Path(__file__).resolve().parents[1];O=R/'output';checkout=Path('/workspace/bowl3d-delivery')
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=checkout,text=True).strip()
manifest=json.loads((O/'manifest.json').read_text());rows=[]
for item in manifest:
 path='deliveries/false-person-origin/'+item['name']
 tree=subprocess.check_output(['git','ls-tree','-l',commit,'--',path],cwd=checkout,text=True).strip()
 assert tree and int(tree.split()[3])==item['bytes'],tree
 url=f'https://raw.githubusercontent.com/wchao4188-sketch/chat-animation-studio2/{commit}/{path}'
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'NewWorld-Delivery-Verification'}),timeout=120) as response:
  status=response.status;data=response.read()
 assert status==200 and len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
 row={**item,'url':url,'http_status':status,'anonymous_full_get':True}
 if item['name'].endswith('.zip'):
  with zipfile.ZipFile(io.BytesIO(data)) as z:assert z.testzip() is None;row['zip_crc']='passed';row['entries']=len(z.namelist())
 rows.append(row);print(json.dumps(row),flush=True)
(O/'download-verification.json').write_text(json.dumps({'commit':commit,'files':rows},indent=2))
