from pathlib import Path
import zipfile,json,hashlib
R=Path(__file__).resolve().parents[1];O=R/'output';files=[R/x for x in ['README.md','package.json','package-lock.json','tsconfig.json','requirements-production.txt']]
for d in ['src','scripts','public','assets']:files += [p for p in (R/d).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
for name in ['Acceptance.md','quality-check.json','playback-check.json','continuity.json','determinism.json','music-analysis.json','sound-events.json','audio-measurement.log','audio-copy-check.json']:files.append(O/name)
dst=O/'NewWorld-Origin-Of-The-False-Person-Source.zip'
with zipfile.ZipFile(dst,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(set(files)):z.write(p,Path('NewWorld-Origin-Of-The-False-Person')/p.relative_to(R))
with zipfile.ZipFile(dst) as z:assert z.testzip() is None
rows=[]
for p in [O/'NewWorld-Origin-Of-The-False-Person.mp4',dst,O/'Origin-Of-The-False-Person-Keyframes.pdf',O/'Acceptance.md']:
 rows.append({'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(O/'manifest.json').write_text(json.dumps(rows,indent=2));(O/'SHA256SUMS.txt').write_text('\n'.join(x['sha256']+'  '+x['name'] for x in rows)+'\n');print(json.dumps(rows,indent=2))
