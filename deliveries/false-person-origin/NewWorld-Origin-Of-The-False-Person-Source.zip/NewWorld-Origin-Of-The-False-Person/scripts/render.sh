#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
npm run typecheck
npx remotion render src/index.tsx OriginOfTheFalsePerson output/Origin-Render.mp4 --browser-executable=/usr/bin/chromium --codec=h264 --crf=16 --pixel-format=yuv420p --concurrency=3
ffmpeg -v error -y -i output/Origin-Render.mp4 -map 0:v:0 -map 0:a:0 -c:v copy -af atrim=duration=72 -c:a aac -b:a 256k -t 72 -movflags +faststart output/NewWorld-Origin-Of-The-False-Person.mp4
