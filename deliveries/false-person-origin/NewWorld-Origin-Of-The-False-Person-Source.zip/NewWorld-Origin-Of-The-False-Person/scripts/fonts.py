from pathlib import Path
from fontTools import subset
R=Path(__file__).resolve().parents[1];text=''.join(p.read_text() for p in (R/'src').rglob('*.tsx'))
for source,name,index in [('/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc','Display',2),('/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc','Narrative',2),('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc','Text',2),('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf','Mono',0)]:
 o=subset.Options();o.font_number=index;o.flavor='woff';f=subset.load_font(source,o);s=subset.Subsetter(options=o);s.populate(text=text);s.subset(f);subset.save_font(f,R/'public/fonts'/f'{name}.woff',o)
