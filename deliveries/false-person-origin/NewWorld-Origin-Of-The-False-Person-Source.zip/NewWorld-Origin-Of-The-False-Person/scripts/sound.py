from pathlib import Path
import numpy as np,subprocess,json,hashlib,wave
from scipy.signal import butter,sosfilt,stft,find_peaks,correlate
R=Path(__file__).resolve().parents[1];A=R/'public/audio';O=R/'output';SR=48000;D=72
src=A/'user-music-source.m4a';processed=A/'music-processed.wav'
# 54 seconds of actual source become 72 seconds. This is an intentional edit, not a new recording.
subprocess.run(['ffmpeg','-v','error','-y','-ss','38','-t','54','-i',str(src),'-af','aresample=48000,asetrate=36000,aresample=48000,lowpass=f=2800,highpass=f=45','-ac','2','-ar','48000',str(processed)],check=True)
music=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(processed),'-t','72','-ac','2','-ar','48000','-f','f32le','-']),'<f4').reshape(-1,2).copy();n=D*SR
if len(music)<n:music=np.pad(music,((0,n-len(music)),(0,0)))
music=music[:n];mono=music.mean(axis=1)[::2];f,t,z=stft(mono,24000,nperseg=1024,noverlap=768);flux=np.maximum(np.diff(abs(z),axis=1),0).sum(axis=0);flux/=max(flux.max(),1e-9);peaks,_=find_peaks(flux,distance=25,prominence=.06);onsets=t[1:][peaks]
ac=correlate(flux,flux,method='fft')[len(flux)-1:];lag=np.arange(len(ac))*256/24000;v=np.where((lag>60/160)&(lag<60/55))[0];p,_=find_peaks(ac[v]);ids=sorted(v[p],key=lambda i:ac[i],reverse=True)[:4]
events=[(2.4,'mask begins assembling'),(6.8,'title reveal'),(12,'age dossier unfolds'),(17,'strata separate'),(22,'dimensions separate'),(27,'independent thinking dimension'),(32,'fictional case'),(33.8,'first label attaches'),(35.45,'second label attaches'),(37.1,'third label attaches'),(41,'context arrives'),(45,'one information slice'),(48,'revision starts'),(50,'personal context'),(52,'social information'),(54,'actual conversation'),(56,'long-term interaction'),(58,'questions replace labels'),(60.2,'first question settles'),(60.75,'daily life'),(61.3,'world view'),(61.85,'present needs'),(66,'false model exits'),(68,'closing hold')]
mapping=[{'seconds':s,'frame':round(s*30),'event':label,'nearest_detected_onset':round(float(min(onsets,key=lambda x:abs(x-s))),4)} for s,label in events]
analysis={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'source_segment':[38,92],'processed_duration':72,'processing':'source 48 kHz interpreted at 36 kHz, resampled to 48 kHz; lowpass 2800Hz/highpass45Hz; 0.75 speed, lower pitch','bpm_candidates':[{'bpm':round(60/lag[i],3),'autocorrelation':float(ac[i]/ac[0])}for i in ids],'onsets':np.round(onsets,4).tolist(),'bar_downbeats':'Not manually confirmed','events':mapping}
(O/'music-analysis.json').write_text(json.dumps(analysis,indent=2))
tt=np.arange(n)/SR;rng=np.random.default_rng(17391);sfx=np.zeros((n,2),np.float32)
def smooth(t,a,b):
 x=np.clip((t-a)/(b-a),0,1);return x*x*x*(x*(x*6-15)+10)
motion=np.zeros(n)
for a,b,g in [(2,6,.8),(17,21,.7),(23,26,.45),(41,44,.4),(45,47,.6),(48,49.4,.3),(50,51.4,.3),(52,53.4,.3),(54,55.4,.3),(56,57.4,.3),(58,66,.8),(66,68,.5)]:
 x=np.clip((tt-a)/(b-a),0,1);motion+=30*x*x*(x-1)**2*g
noise=sosfilt(butter(2,[180,2000],btype='bandpass',fs=SR,output='sos'),rng.normal(size=n));noise=noise/max(np.std(noise),1e-8)
friction=noise*motion*.012;sfx[:,0]+=friction;sfx[:,1]+=np.roll(friction,127)*.82
drone=(np.sin(2*np.pi*49*tt+.14*np.sin(tt*.31))+.25*np.sin(2*np.pi*98.12*tt)+.12*np.sin(2*np.pi*147.1*tt))*.013
sfx[:,0]+=drone;sfx[:,1]+=drone*.94
for i,(sec,label)in enumerate(events):
 dur=.55;u=np.arange(int(SR*dur))/SR
 if sec in [6.8,41,66]:tone=(np.sin(2*np.pi*146*u)+.25*np.sin(2*np.pi*439*u))*np.exp(-u*8)*.028
 else:tone=(np.sin(2*np.pi*720*u)+.3*np.sin(2*np.pi*1123*u))*np.exp(-u*25)*(1-np.exp(-u*200))*.022
 k=int(sec*SR);end=min(n,k+len(tone));pan=np.sin(i*1.2)*.45;st=np.array([np.sqrt((1-pan)/2),np.sqrt((1+pan)/2)]);sfx[k:end]+=tone[:end-k,None]*st
fade=smooth(tt,0,1.6)*(1-smooth(tt,69.8,72));duck=1-.55*smooth(tt,40.5,41.2)*(1-smooth(tt,45.5,48));music*=.63*duck[:,None]*fade[:,None];sfx*=fade[:,None];master=music+sfx;gain=.78/max(abs(master).max(),1e-9)
for name,a in [('music',music),('sfx',sfx),('master',master)]:
 a=a*gain
 with wave.open(str(A/(name+'.wav')),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR);w.writeframes(np.int16(np.clip(a,-1,1)*32767).tobytes())
subprocess.run(['ffmpeg','-v','error','-y','-i',str(A/'master.wav'),'-c:a','aac','-b:a','256k',str(A/'master.m4a')],check=True)
(O/'sound-events.json').write_text(json.dumps({'voiceover':False,'events':mapping,'continuous_friction':'Envelope follows the actual settle/separate/flip timing','source':'Local deterministic synthesis, not recorded stone/paper foley','human_listening':False},indent=2));print('Audio ready',analysis['bpm_candidates'])
