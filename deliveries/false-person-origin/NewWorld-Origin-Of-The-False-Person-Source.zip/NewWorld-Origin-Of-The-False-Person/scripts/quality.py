from pathlib import Path
import subprocess,json,hashlib,wave
from PIL import Image,ImageDraw
import numpy as np
R=Path(__file__).resolve().parents[1];O=R/'output';Q=O/'review';P=O/'NewWorld-Origin-Of-The-False-Person.mp4'
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(P)]));v=next(s for s in probe['streams'] if s['codec_type']=='video');a=next(s for s in probe['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'],v['r_frame_rate'],int(v['nb_read_frames']))==(1920,1080,'30/1',2160)
assert abs(float(probe['format']['duration'])-72)<.01
decoded=subprocess.run(['ffmpeg','-v','error','-i',str(P),'-f','null','-'],capture_output=True);assert decoded.returncode==0 and not decoded.stderr
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(P),'-vf','scale=240:135','-f','rawvideo','-pix_fmt','rgb24','-']);frames=np.frombuffer(raw,np.uint8).reshape(2160,135,240,3)
means=frames.mean((1,2,3));diff=np.abs(np.diff(frames.astype(np.int16),axis=0)).mean((1,2,3));assert means.min()>3
pages=[];selected=list(range(0,2160,15))+[2159]
def page(ids,name,cols=5):
 rows=(len(ids)+cols-1)//cols;out=Image.new('RGB',(320*cols,205*rows),'#151719');d=ImageDraw.Draw(out)
 for n,idx in enumerate(ids):
  x=n%cols*320;y=n//cols*205;out.paste(Image.fromarray(frames[idx]).resize((320,180),Image.Resampling.LANCZOS),(x,y));d.text((x+6,y+184),f'{idx/30:.3f}s / f{idx}',fill='white')
 path=Q/name;out.save(path,quality=94);return path
for k in range(0,len(selected),25):pages.append(page(selected[k:k+25],f'film-contact-{k//25:02}.jpg'))
imgs=[Image.open(p).convert('RGB') for p in pages];imgs[0].save(O/'Origin-Of-The-False-Person-Keyframes.pdf',save_all=True,append_images=imgs[1:],resolution=120)
for t in [2,6,12,17,22,32,41,45,48,58,60.75,66]:
 ids=list(range(max(0,round((t-.2)*30)),min(2160,round((t+1.9)*30)),3));page(ids,f'transition-{t}.jpg')
for t in [1.5,8.8,16,24.5,35,39,43,46.5,53,59.2,62.5,65,69.5]:
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(P),'-vf',rf'select=eq(n\,{round(t*30)})','-frames:v','1',str(Q/f'actual-{t}.png')],check=True)
audio=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(P),'-vn','-ar','48000','-ac','2','-f','f32le','-']),'<f4').reshape(-1,2)
with wave.open(str(R/'public/audio/master.wav')) as w:master=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32).reshape(-1,2)/32768
n=min(len(master),len(audio));corr=float(np.corrcoef(audio[:n].ravel(),master[:n].ravel())[0,1]);peak=float(abs(audio).max());assert corr>.98 and peak<1
q={'video':{'width':v['width'],'height':v['height'],'fps':v['r_frame_rate'],'frames':v['nb_read_frames'],'duration':v['duration'],'codec':v['codec_name']},'container_duration':probe['format']['duration'],'audio':{'codec':a['codec_name'],'sample_rate':a['sample_rate'],'channels':a['channels'],'peak_linear':peak,'reference_correlation':corr,'final_20ms_rms':float(np.sqrt(np.mean(audio[-960:]**2)))},'full_decode':{'exit':decoded.returncode,'stderr':decoded.stderr.decode()},'all_frames_metrics':{'count':len(frames),'minimum_mean_brightness':float(means.min()),'maximum_adjacent_difference':float(diff.max()),'maximum_adjacent_difference_frame':int(diff.argmax()+1)},'contact_sheets':len(pages),'transition_contact_sheets':12,'voiceover_added':False,'human_audio_listening':False,'file':{'bytes':P.stat().st_size,'sha256':hashlib.sha256(P.read_bytes()).hexdigest()}}
(O/'quality-check.json').write_text(json.dumps(q,indent=2));print(json.dumps(q,indent=2))
