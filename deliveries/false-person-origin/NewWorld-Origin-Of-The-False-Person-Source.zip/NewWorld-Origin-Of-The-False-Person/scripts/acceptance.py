from pathlib import Path
import json
R=Path(__file__).resolve().parents[1];O=R/'output';q=json.loads((O/'quality-check.json').read_text());p=json.loads((O/'playback-check.json').read_text());c=json.loads((O/'continuity.json').read_text());d=json.loads((O/'determinism.json').read_text());m=json.loads((O/'music-analysis.json').read_text());meta=json.loads((R/'src/mask-meta.json').read_text())
s=f'''# 《伪人起源》实际制作与检查

## 成片

1920×1080、16:9、30fps、{q['video']['frames']}帧、{q['container_duration']}秒；H.264 / yuv420p、AAC / 48kHz / 双声道。无新增配音。
{q['file']['bytes']:,}字节；SHA-256 `{q['file']['sha256']}`。

## 创作与素材

根据用户上一张年龄经验模型图，创作为关于误判的视觉寓言。标题“伪人起源”按本轮要求；“伪人”是脑中未经验证的想象，不是把他人称为怪物。年龄比例注明经验设定、非人口统计；周末待在家的聊天明确标注虚构。

本轮AI生成透明石膏雕塑PNG，SHA-256 `{meta['sha256']}`。不是人像实拍，也不是Blender/Three.js三维网格。使用24个原图切片的2.5D空间动画、连续遮挡、翻面与档案纸构图。旧视频不是视觉模板，旧工程没有覆盖。

## 实际修改

确定主视觉后，检查了开场、片名、档案、双维度纸条、虚构聊天、修正过程、翻面、结尾的实际渲染帧。将五步修正与五组切片重新对齐绑定；问题纸条提前完成翻面，保留阅读时间；统一退出方向，避免纸条横穿结尾文字。

首版全片检查发现45秒情境纸条硬切消失，随后改为连续滑出、从下方揭示新文字；同时使模拟地面阴影随面具拆解减弱，避免面具离场后残留孤立阴影。以上修改后重新渲染整片。

第二轮密集转场检查又发现47.7秒附近文字向右退出时受到浏览器自动收缩影响而重排。随后为文字和页眉固定版心宽度，独立重渲第1398—1439帧，按帧裁切合入完整2160帧影片；原AAC音轨直接复制，没有重混或替换。拼接后统一为固定30fps时间戳，并从原成片恢复完整72秒AAC音轨。再次对最终MP4完整解码、全长浏览器播放和实际转场帧检查。

音乐制作中发现原始采样率不能直接假定48kHz，因此先显式重采样再变速。实际处理后音乐文件时长已读取确认72秒，没有用补静音冒充等时素材。

## 视频与动画检查

- 最终MP4全片FFmpeg解码退出 {q['full_decode']['exit']}，错误输出为空。
- 2160帧全部进行亮度和相邻差异基本检查；另查看整片每0.5秒总览、12段密集转场页及高清关键帧。
- Chromium播放至72秒结束：{p['ended']}；共{p['frames']}帧，丢帧{p['dropped']}，媒体错误{p['error']}。
- 实际motion函数检查24片变换边界，最大前后各1微秒参数差 {c['maximum_boundary_parameter_delta']:.9g}（像素/角度混合单位）。只说明参数连续性，不是物理仿真认证。
- 第1875帧重复渲染PNG逐字节相同：{d['byte_identical']}。

## 声音

处理后音乐主BPM候选{m['bpm_candidates'][0]['bpm']}，未人工确认小节重拍。72秒音乐来自用户素材38—92秒的0.75倍速处理。音效为本地合成，含与实际变换时间一致的连续摩擦纹理；没有新旁白。

混音AAC技术测量约 −16.82 LUFS、真峰值 −2.15 dBTP。最终MP4音轨解码峰值 {q['audio']['peak_linear']:.6f}，与预定混音相关系数 {q['audio']['reference_correlation']:.6f}，没有数值削波。自动浏览器播放静音，未进行真人试听，不能声称音效观感已通过人耳验收。

## 依赖与限制

Remotion 4.0.536、React 19.2.4、TypeScript 5.9.3和Chromium/FFmpeg沿用现有安装，没有新增npm依赖。Python声音制作使用既有NumPy/SciPy，字体子集使用既有fontTools。

可编辑工程包含原始PNG、全部Remotion源码、字体、音轨与生成/检查脚本。不是可旋转至任意视角的三维模型工程。技术检查不能认证“最惊艳”或电影级审美；以实际成片供用户判断。其他系统上的完整依赖安装和渲染未验证。
'''
(O/'Acceptance.md').write_text(s);print(s)
