export const clamp=(v:number)=>Math.max(0,Math.min(1,v));
export const smooth=(v:number)=>{v=clamp(v);return v*v*v*(v*(v*6-15)+10)};
export const r=(t:number,a:number,b:number)=>smooth((t-a)/(b-a));
export const mix=(a:number,b:number,t:number)=>a+(b-a)*t;
export const rnd=(i:number)=>{const v=Math.sin(i*79.13+73.77)*43758.5453;return v-Math.floor(v)};
export function track(t:number,keys:number[][]){for(let i=0;i<keys.length-1;i++){const[a,v]=keys[i],[b,w]=keys[i+1];if(t<=b)return mix(v,w,r(t,a,b))}return keys[keys.length-1][1]}
export const W=620,H=1072,N=24,bandH=H/N;
export function camera(t:number){return{x:track(t,[[0,1220],[6,1270],[12,1280],[22,1190],[28,1190],[32,550],[46.8,550],[49,1240],[56.8,1240],[58,960],[66,960],[72,960]]),y:track(t,[[0,650],[6,565],[12,565],[22,570],[32,570],[48,565],[58,540],[72,540]]),scale:track(t,[[0,1.7],[6,.82],[12,.82],[22,.85],[32,.77],[48,.78],[58,.8],[66,.8],[72,.8]]),yaw:track(t,[[0,-6],[6,0],[12,-8],[22,8],[32,-5],[48,0],[58,0],[72,0]])}}
export const special=[5,10,15,20];
export function slab(i:number,t:number){const c=camera(t),side=i%2?1:-1;const settle=(1-r(t,2+rnd(i)*.25,5.7+rnd(i)*.25));const loosen=r(t,17,21)*(1-r(t,23,26));const response=r(t,41,44)*(1-r(t,48+Math.floor(i/5)*2,49.4+Math.floor(i/5)*2));const single=i===11?r(t,45,47)*(1-r(t,52,53.4)):0;
 let dx=side*(45+50*rnd(i+2))*settle+side*(30+45*rnd(i+3))*loosen+side*25*response+single*200;
 let dy=(i-N/2)*1.5*(settle+loosen)+single*20;let z=(rnd(i+5)-.5)*110*(settle+loosen)+single*150,ry=side*7*(settle+loosen),rz=0,height=bandH;
 const k=special.indexOf(i);const start=k>=0?58+k*.55:58+rnd(i+11)*1.8;const q=r(t,start,start+2.2);
 if(k>=0){const target=[[500,340],[1420,340],[500,745],[1420,745]][k];dx=mix(dx,(target[0]-c.x)/c.scale,q);dy=mix(dy,(target[1]-c.y)/c.scale-(i+.5)*bandH+H/2,q);z=mix(z,0,q);ry=mix(ry,180,q);rz=mix(rz,k%2?2:-2,q);height=mix(bandH,110,r(t,start+1.1,start+2.2));const out=r(t,66,68.5);dx+=(k%2?1:-1)*out*1500;dy+=(k<2?-1:1)*out*400;rz+=(k%2?1:-1)*out*18;
 }else{dx+=side*q*(1200+500*rnd(i+3));dy+=(i-N/2)*q*80;z+=q*100;ry+=side*q*65;rz+=side*q*(6+15*rnd(i+9))}
 return{dx,dy,z,ry,rz,height,flip:q};}
