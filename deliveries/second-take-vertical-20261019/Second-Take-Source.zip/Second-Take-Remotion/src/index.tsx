import React from 'react';
import {Composition,registerRoot} from 'remotion';
import {StoryFilm} from './Film';
const Root=()=> <Composition id="SecondTake" component={StoryFilm} durationInFrames={1380} fps={30} width={1080} height={1920}/>;
registerRoot(Root);
