from pathlib import Path
import subprocess,json,hashlib,math,re
import numpy as np
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parents[1];o=R/'output';v=o/'Second-Take-Vertical-46s.mp4'
p=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(v)]));s=next(x for x in p['streams'] if x['codec_type']=='video');a=next(x for x in p['streams'] if x['codec_type']=='audio');assert(s['width'],s['height'],s['r_frame_rate'],int(s['nb_frames']))==(1080,1920,'30/1',1380);assert abs(float(s['duration'])-46)<.001;(o/'probe.json').write_text(json.dumps(p,indent=2))
r=subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(v),'-f','null','-'],capture_output=True,text=True);assert r.returncode==0;(o/'decode.log').write_text(r.stderr)
idx=set(range(0,1380,15))|{1379}
for sec in [2.7,4.3,8.2,10.2833,10.6833,11.0833,14.6667,19.2,24.9,27.7,29.2,30.3667,32.8,36.8,38.8667,43.2]:
 for d in [-.1,.1,.3,.5]:idx.add(max(0,min(1379,round((sec+d)*30))))
proc=subprocess.Popen(['ffmpeg','-v','error','-i',str(v),'-an','-vf','scale=270:480','-pix_fmt','rgb24','-f','rawvideo','-'],stdout=subprocess.PIPE);frames={};last=None;diff=[];luma=[];n=0
while True:
 b=proc.stdout.read(270*480*3)
 if not b:break
 assert len(b)==270*480*3;x=np.frombuffer(b,np.uint8).reshape(480,270,3);luma.append(float(x.mean()))
 if last is not None:diff.append(float(np.abs(x.astype(np.int16)-last).mean()))
 if n in idx:frames[n]=Image.fromarray(x.copy())
 last=x.astype(np.int16);n+=1
assert proc.wait()==0 and n==1380 and min(luma)>18
review=o/'review';review.mkdir(exist_ok=True);font=ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',18);images=[];indices=sorted(frames)
for k in range(math.ceil(len(indices)/12)):
 page=Image.new('RGB',(1080,1578),'#e0d0ad');d=ImageDraw.Draw(page)
 for j,f in enumerate(indices[k*12:(k+1)*12]):
  x=j%4*270;y=j//4*526;page.paste(frames[f],(x,y));d.text((x+10,y+483),f'{f:04} / {f/30:.2f}s',font=font,fill='#303c33')
 page.save(review/f'{k+1:02}.jpg',quality=91);images.append(page)
images[0].save(o/'Second-Take-Keyframes.pdf',save_all=True,append_images=images[1:],resolution=110)
(o/'motion.json').write_text(json.dumps({'frames':n,'frame_mean_changes':diff,'minimum_frame_mean_luma':min(luma),'maximum_frame_mean_change':max(diff)},indent=2))
# Check actual rendered audio against the exact supplied mixed master.
def sound(path):return np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-vn','-ac','1','-ar','16000','-f','f32le','-']),np.float32)
x=sound(v);y=sound(R/'public/audio/final-mix.m4a');m=min(len(x),len(y));corr=float(np.corrcoef(x[:m],y[:m])[0,1]);assert corr>.99
r=subprocess.run(['ffmpeg','-hide_banner','-i',str(v),'-af','ebur128=peak=true,silencedetect=noise=-60dB:d=0.25','-vn','-f','null','-'],capture_output=True,text=True);assert r.returncode==0;(o/'audio-check.log').write_text(r.stderr)
from fontTools.ttLib import TTFont
cn={ord(c) for c in (R/'src/Film.tsx').read_text()+(R/'src/dialogue.json').read_text() if '\u4e00'<=c<='\u9fff'}
for name in ['StorySans','StorySerif']:assert not cn-set(TTFont(R/f'public/fonts/{name}.woff').getBestCmap())
rows=json.loads((R/'src/dialogue.json').read_text());assert all(a['start']+a['duration']<b['start'] for a,b in zip(rows,rows[1:]));assert rows[-1]['end']<46
q={'title':'第二遍','duration_seconds':46,'resolution':[1080,1920],'aspect_ratio':'9:16','fps':30,'frames':1380,'bytes':v.stat().st_size,'sha256':hashlib.sha256(v.read_bytes()).hexdigest(),'strict_decode_exit_code':0,'decoded_frames':n,'overview_samples':len(indices),'overview_pages':len(images),'minimum_frame_mean_luma':min(luma),'audio_codec':a['codec_name'],'audio_sample_rate':a['sample_rate'],'audio_master_correlation':corr,'dialogue_overlap':False,'font_chinese_glyph_coverage':True,'music':'User uploaded mmexport1792300994359.mp3, original audio first 46 seconds','narration':False,'human_audio_listening':False,'source_asr_file':'voice-asr.json'};(o/'quality.json').write_text(json.dumps(q,ensure_ascii=False,indent=2));print(json.dumps(q,ensure_ascii=False,indent=2))
