from pathlib import Path
import sherpa_onnx,numpy as np,json,subprocess,re,difflib
R=Path(__file__).resolve().parents[1];p=R.parent/'assets/models/sherpa-onnx-paraformer-zh-small-2024-03-09';a=sherpa_onnx.OfflineRecognizer.from_paraformer(paraformer=str(p/'model.int8.onnx'),tokens=str(p/'tokens.txt'),num_threads=2);rows=json.loads((R/'src/dialogue.json').read_text());result=[]
for row in rows:
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(R/f"public/audio/voice-{row['id']:02}.wav"),'-ar','16000','-ac','1','-f','f32le','-']);s=a.create_stream();s.accept_waveform(16000,np.frombuffer(raw,np.float32));a.decode_stream(s);normal=lambda t:re.sub(r'[^\u4e00-\u9fff]','',t);ratio=difflib.SequenceMatcher(None,normal(row['text']),normal(s.result.text)).ratio();result.append({'id':row['id'],'script':row['text'],'asr':s.result.text,'similarity':ratio});print(result[-1],flush=True)
(R/'output/voice-asr.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
