from pathlib import Path
import numpy as np,json,wave,subprocess
from scipy.signal import butter,sosfilt
R=Path(__file__).resolve().parents[1];sr=48000;n=46*sr;rows=json.loads((R/'src/dialogue.json').read_text());rng=np.random.default_rng(4188)
def write(p,x):
 x=np.asarray(x)
 with wave.open(str(p),'wb') as w:w.setparams((x.shape[1] if x.ndim>1 else 1,2,sr,0,'NONE','not compressed'));w.writeframes((x.clip(-1,1)*32767).astype('<i2').tobytes())
def read(p):
 with wave.open(str(p)) as w:return np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32).reshape(-1,w.getnchannels())/32768
voice=np.zeros(n,np.float32);mouths={};duck=np.ones(n,np.float32)
for row in rows:
 x=read(R/f"public/audio/voice-{row['id']:02}.wav").mean(1);i=round(row['start']*sr);voice[i:i+len(x)]+=x
 env=np.array([np.sqrt(np.mean(x[k:k+1600]**2)) for k in range(0,len(x),1600)]);mouths[str(row['id'])]=np.clip(env/(np.percentile(env,85)+1e-6),0,1).round(3).tolist()
 a=max(0,i-8000);b=min(n,i+len(x)+12000);d=np.ones(b-a,np.float32)*.24;attack=min(8000,len(d)//3);release=min(12000,len(d)//3);d[:attack]=np.linspace(1,.24,attack);d[-release:]=np.linspace(.24,1,release);duck[a:b]=np.minimum(duck[a:b],d)
(R/'src/mouths.json').write_text(json.dumps(mouths));write(R/'public/audio/dialogue.wav',voice)
# Rain is a sound of the actual cafe window, not a visual transition accent.
noise=rng.normal(0,1,(n,2)).astype(np.float32);rain=sosfilt(butter(2,[1200,7000],fs=sr,btype='bandpass',output='sos'),noise,axis=0)*.006
amb=rain;foley=np.zeros((n,2),np.float32)
events=[]
def add(t,x,pan,name):
 i=round(t*sr);x=x[:n-i];foley[i:i+len(x),0]+=x*np.sqrt((1-pan)/2);foley[i:i+len(x),1]+=x*np.sqrt((1+pan)/2);events.append({'time':t,'frame':round(t*30),'sound':name})
for at in [4.28,4.35]:
 u=np.arange(round(.32*sr))/sr;x=sum(np.sin(2*np.pi*f*u)*np.exp(-u*(25+k*15))/(k+1) for k,f in enumerate([1643,2709,4213]));add(at,.024*x,-.25,'陶瓷杯落在木托盘')
for at in [11.25,12.833333]:
 u=np.arange(round(.36*sr))/sr;x=sosfilt(butter(2,[900,4800],fs=sr,btype='bandpass',output='sos'),rng.normal(0,1,len(u)))*np.sin(np.pi*u/.36)**2;add(at,x*.014,.35,'手指触碰折皱纸稿')
u=np.arange(round(.85*sr))/sr;x=sosfilt(butter(2,[100,1600],fs=sr,btype='bandpass',output='sos'),rng.normal(0,1,len(u)))*np.sin(np.pi*u/.85)**2;add(27.833333,x*.025,-.3,'椅脚在地面短距离挪动')
write(R/'public/audio/ambience-foley.wav',amb+foley)
music=read(R/'public/audio/music-selected.wav');music=music[:n];time=np.arange(n)/sr
# Preserve supplied recording; lower it under dialogue, keep an audible bed in pauses.
energy=np.sqrt(np.mean(music**2));base=.045/(energy+1e-8);gain=duck*base
# A gentle dip for the rejection; recovery follows the invitation, not a fabricated soundtrack cue.
smooth=lambda a,b:(lambda u:u*u*(3-2*u))(np.clip((time-a)/(b-a),0,1));gain*=1-.35*smooth(2.58,2.74)*(1-smooth(4.85,5.08));fade=np.minimum(np.clip(time/.20,0,1),np.clip((46-time)/1.6,0,1));mixed=voice[:,None]+music*gain[:,None]+amb+foley;mixed*=fade[:,None];mx=np.abs(mixed).max()
if mx>.89:mixed*=.89/mx
write(R/'public/audio/final-mix.wav',mixed)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(R/'public/audio/final-mix.wav'),'-c:a','aac','-b:a','192k',str(R/'public/audio/final-mix.m4a')],check=True)
analysis=json.loads((R/'output/music-analysis.json').read_text());acc=analysis['accents'];beats=[]
for label,t in [('拒绝回应/音乐下沉',2.7),('放下两杯咖啡',4.3),('转向桌面',320/30),('纸稿触碰音效',385/30),('提出重来',767/30),('椅脚音效',835/30),('重新抬头',911/30),('重新开口',1166/30)]:
 nearest=min(acc,key=lambda a:abs(a['time']-t));beats.append({'event':label,'event_frame':round(t*30),'nearest_music_accent_frame':nearest['frame'],'difference_frames':round(t*30)-nearest['frame'],'speech_timing_preserved':True})
(R/'output/sound-design.json').write_text(json.dumps({'duration':46,'music_source':'user supplied recording / first 46 seconds','music_gain_rms_target':.045,'voice_music_duck_gain':.24,'foley_events':events,'event_music_alignment':beats,'music_source_not_regenerated':True},ensure_ascii=False,indent=2))
print('audio peak',float(np.max(np.abs(mixed))),'voice lines',len(rows))
