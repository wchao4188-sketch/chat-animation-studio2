import {bundle} from '@remotion/bundler';
import {selectComposition,renderStill,openBrowser} from '@remotion/renderer';
import fs from 'node:fs/promises';
const url=await bundle({entryPoint:'src/index.tsx'});const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium',logLevel:'error'});
try{const comp=await selectComposition({serveUrl:url,id:'SecondTake',puppeteerInstance:browser});await fs.mkdir('output/stills',{recursive:true});for(const sec of [1,3,6.5,10,13,15.5,18,22,28,30.8,33,36.5,42.5,47]){await renderStill({composition:comp,serveUrl:url,puppeteerInstance:browser,frame:Math.round(sec*30),output:`output/stills/${sec}.png`,imageFormat:'png',logLevel:'error'});console.log(sec)}}finally{await browser.close({silent:true});}
