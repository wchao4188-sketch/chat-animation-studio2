from pathlib import Path
import sherpa_onnx,numpy as np,wave,json,subprocess
R=Path(__file__).resolve().parents[1];p=R.parent/'assets/models/vits-melo-tts-zh_en'
c=sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(vits=sherpa_onnx.OfflineTtsVitsModelConfig(model=str(p/'model.onnx'),lexicon=str(p/'lexicon.txt'),tokens=str(p/'tokens.txt'),noise_scale=.35,noise_scale_w=.45),num_threads=2),rule_fsts=','.join(str(x) for x in sorted(p.glob('*.fst'))),max_num_sentences=1)
assert c.validate();tts=sherpa_onnx.OfflineTts(c);rows=json.loads((R/'src/dialogue.json').read_text())
import sys
selected={int(x) for x in sys.argv[1:]}
for row in rows:
 if selected and row["id"] not in selected:continue
 a=tts.generate(row['text'],sid=0,speed=.94 if row['speaker']=='man' else .91)
 path=R/f"public/audio/raw-{row['id']:02}.wav"
 with wave.open(str(path),'wb') as w:w.setparams((1,2,a.sample_rate,0,'NONE','not compressed'));w.writeframes((np.asarray(a.samples).clip(-1,1)*32767).astype('<i2').tobytes())
 out=R/f"public/audio/voice-{row['id']:02}.wav";pitch=.925 if row['speaker']=='man' else 1.07
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(path),'-af',f'rubberband=pitch={pitch}:formant=preserved,highpass=f=90,loudnorm=I=-17:TP=-3:LRA=6','-ar','48000',str(out)],check=True)
 with wave.open(str(out)) as w:row['duration']=w.getnframes()/w.getframerate()
 row['end']=round(row['start']+row['duration']+.22,4);print(row,flush=True)
(R/'src/dialogue.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
