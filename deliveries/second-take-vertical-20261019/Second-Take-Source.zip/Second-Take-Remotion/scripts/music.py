from pathlib import Path
import numpy as np,json,subprocess
from scipy.signal import find_peaks
R=Path(__file__).resolve().parents[1];music=Path('/workspace/attachments/a2c6cf64-8078-4ab1-9770-7a7c2ed475d0/mmexport1792300994359.mp3')
subprocess.run(['ffmpeg','-v','error','-y','-i',str(music),'-t','46','-vn','-ar','48000','-ac','2','-c:a','pcm_s16le',str(R/'public/audio/music-selected.wav')],check=True)
x=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(music),'-t','46','-vn','-ac','1','-ar','22050','-f','f32le','-']),np.float32)
win=1024;hop=256;spec=np.abs(np.fft.rfft(np.lib.stride_tricks.sliding_window_view(x,win)[::hop]*np.hanning(win)));flux=np.maximum(np.diff(np.log1p(spec),axis=0),0).sum(axis=1);flux=(flux-flux.mean())/(flux.std()+1e-8);peaks,props=find_peaks(flux,prominence=1.4,distance=int(.32*22050/hop));times=(peaks*hop+win/2)/22050
ac=np.correlate(flux,flux,'full')[len(flux)-1:];lags=np.arange(int(22050/hop*60/140),int(22050/hop*60/65));best=sorted(lags,key=lambda k:ac[k],reverse=True);cand=[]
for k in best:
 bpm=60*22050/hop/k
 if all(abs(bpm-v['bpm'])>4 for v in cand):cand.append({'bpm':float(bpm),'score':float(ac[k]/ac[0])})
 if len(cand)==3:break
out={'source_sha256':__import__('hashlib').sha256(music.read_bytes()).hexdigest(),'selected_seconds':[0,46],'bpm_candidates':cand,'method':'positive log-spectral flux / local peaks / autocorrelation; peaks are energy accents, not confirmed bar downbeats','accents':[{'time':round(float(t),4),'frame':round(float(t)*30),'strength':round(float(flux[k]),3)} for t,k in zip(times,peaks)],'energy_1s_rms':[float(np.sqrt(np.mean(x[k:k+22050]**2))) for k in range(0,len(x),22050)]};(R/'output/music-analysis.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
