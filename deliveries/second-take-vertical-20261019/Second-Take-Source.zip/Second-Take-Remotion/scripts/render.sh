#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
./node_modules/.bin/remotion render src/index.tsx SecondTake output/Second-Take-Vertical-46s.mp4 --browser-executable=/usr/bin/chromium --concurrency=3 --codec=h264 --crf=16 --log=verbose
