from pathlib import Path
from fontTools import subset
R=Path(__file__).resolve().parents[1];text=(R/'src/Film.tsx').read_text()+(R/'src/dialogue.json').read_text()
for kind,path in [('Serif','/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc'),('Sans','/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')]:
 o=subset.Options();o.font_number=2;o.flavor='woff';f=subset.load_font(path,o);s=subset.Subsetter(options=o);s.populate(text=text);s.subset(f);subset.save_font(f,str(R/f'public/fonts/Story{kind}.woff'),o)
