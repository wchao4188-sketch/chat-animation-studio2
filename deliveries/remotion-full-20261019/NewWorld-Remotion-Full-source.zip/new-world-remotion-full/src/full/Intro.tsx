import React,{useLayoutEffect} from 'react';
import {AbsoluteFill,interpolate,staticFile,useCurrentFrame,useVideoConfig,delayRender,continueRender,cancelRender} from 'remotion';
import {Audio} from '@remotion/media';
import {loadFont} from '@remotion/fonts';
import {C,PhoneV2} from '../v2/Phone';
import {TitleV2} from '../v2/Title';
import {getScene,phase,mix,project,pathD,pointAtProgress} from '../v2/geometry';
const fontHandle=delayRender('Load original v1 bundled CJK fonts for v2');
Promise.all([
 loadFont({family:'EditorialSerif',url:staticFile('fonts/EditorialSerif.woff'),weight:'700'}),
 loadFont({family:'EditorialSans',url:staticFile('fonts/EditorialSans.woff'),weight:'400'}),
]).then(()=>continueRender(fontHandle)).catch(cancelRender);

export const FullIntro=()=>{
 const frame=useCurrentFrame();const{fps}=useVideoConfig();const t=frame/fps;const s=getScene(t);
 const probes=[['girl-left',project(s.girl,s.girlLeft)],['girl-right',project(s.girl,s.girlRight)],['left',project(s.left,s.leftPort)],['right',project(s.right,s.rightPort)]] as const;
 // QA observes actual DOM projection, not just two copies of the math model.
 // It never drives animation; any detached socket fails rendering immediately.
 useLayoutEffect(()=>{
  let maxPortError=0,maxTipError=0;
  for(const[id]of probes){
   const a=document.querySelector(`[data-device-port="${id}"]`)?.getBoundingClientRect();
   const b=document.querySelector(`[data-world-port="${id}"]`)?.getBoundingClientRect();
   if(!a||!b){cancelRender(new Error(`Missing socket ${id}`));return;}
   maxPortError=Math.max(maxPortError,Math.hypot(a.x+a.width/2-b.x-b.width/2,a.y+a.height/2-b.y-b.height/2));
  }
  for(let i=0;i<2;i++){
   const path=document.querySelector(`[data-route="${i}"]`) as SVGPathElement|null;
   if(!path)continue;const p=i===0?s.leftWire:s.rightWire;
   const actual=path.getPointAtLength(path.getTotalLength()*p),expected=pointAtProgress(s.cables[i],p);
   maxTipError=Math.max(maxTipError,Math.hypot(actual.x-expected.x,actual.y-expected.y));
  }
  if(maxPortError>.25||maxTipError>.25){cancelRender(new Error(`V2 geometry detached at frame ${frame}: port=${maxPortError}, tip=${maxTipError}`));}
  console.log('V2_GEOMETRY '+JSON.stringify({frame,maxPortError,maxTipError}));
 },[frame]);
 return <AbsoluteFill style={{background:C.paper,color:C.ink,fontFamily:'EditorialSans',overflow:'hidden'}}>

  <svg width="2560" height="1440" style={{position:'absolute',inset:0}}>
   <defs><radialGradient id="paperGlowV2"><stop stopColor="#fffaeb"/><stop offset="1" stopColor={C.paper}/></radialGradient><pattern id="paperDotsV2" width="22" height="22" patternUnits="userSpaceOnUse"><circle cx="1" cy="1" r=".65" fill="#7a6b50" opacity=".16"/></pattern><linearGradient id="floorGlowV2"><stop stopColor="#b59b7333"/><stop offset="1" stopColor="#b59b7300"/></linearGradient></defs>
   <rect width="2560" height="1440" fill="url(#paperGlowV2)"/><rect width="2560" height="1440" fill="url(#paperDotsV2)"/>
   <path d="M-100 1240 C700 1000 1830 1500 2700 1080" fill="none" stroke="#b6a589" strokeWidth="1"/>
   <ellipse cx={mix(1920,1280,s.pull)} cy="1165" rx={mix(490,1120,s.pull)} ry={mix(60,110,s.pull)} fill="url(#floorGlowV2)"/>
   {/* The ground relationship closes only after the second connection arrives. */}
   <ellipse cx="1280" cy="1030" rx="850" ry="195" fill="none" stroke="#a48a61" strokeWidth="1.4" pathLength="1" strokeDasharray="1" strokeDashoffset={1-phase(t,5.903,7.24)} opacity={.65}/>
  </svg>
  <div style={{position:'absolute',top:66,left:100,right:100,display:'flex',justifyContent:'space-between',fontFamily:'FullSans',fontSize:21,letterSpacing:4,color:'#726655'}}><span>新世界 / 会聊天的人</span><span>新世界 · 完整篇</span></div>
  <div style={{position:'absolute',inset:0,clipPath:'inset(190px 0px 320px 0px)'}}><TitleV2 frame={frame} fps={fps}/></div>
  <svg width="2560" height="1440" style={{position:'absolute',inset:0}}>
   <defs><filter id="wireShadowV2"><feDropShadow dx="0" dy="7" stdDeviation="4" floodColor="#726046" floodOpacity=".25"/></filter></defs>
   {s.cables.map((route,i)=>{
    const progress=i===0?s.leftWire:s.rightWire;const tip=pointAtProgress(route,progress);const color=i===0?C.orange:'#7c8567';
    return <g key={i}>
     <path data-route={i} d={pathD(route)} fill="none" stroke="#c7b598" strokeWidth="13" pathLength="1" strokeDasharray="1" strokeDashoffset={1-progress}/>
     <path d={pathD(route)} fill="none" stroke={color} strokeWidth="4" pathLength="1" strokeDasharray="1" strokeDashoffset={1-progress} filter="url(#wireShadowV2)"/>
     {progress>0&&progress<1?<circle cx={tip.x} cy={tip.y} r="5" fill={color}/>:null}
    </g>;
   })}
  </svg>
  {/* Sequential spatial reveal: center movement uncovers 01, its completed
      connection creates the second screen row and uncovers 02. No dissolves. */}
  <PhoneV2 pose={s.left} label="男生 01" role="boy1" color={C.orange} progress={phase(t,4.317,5.2)} t={t}/>
  <PhoneV2 pose={s.right} label="男生 02" role="boy2" color="#aab48a" progress={phase(t,5.903,6.701)} t={t}/>
  <PhoneV2 pose={s.girl} label="女生" role="center" female color={C.gold} t={t}/>
  <svg width="2560" height="1440" style={{position:'absolute',inset:0,pointerEvents:'none'}}>
   {probes.map(([id,p])=><rect key={id} data-world-port={id} x={p.x-.01} y={p.y-.01} width=".02" height=".02" fill="transparent"/>)}
  </svg>
  {t>5.2?<div style={{position:'absolute',left:300,right:300,top:165,height:115,overflow:'hidden',textAlign:'center',fontFamily:'EditorialSerif',fontSize:62,lineHeight:'100px'}}><div style={{translate:`0px ${mix(150,0,phase(t,5.2,5.65))}px`}}>两个男生，同时认识了一个女生。</div></div>:null}
  <div style={{position:'absolute',left:200,right:200,bottom:110,height:125,overflow:'hidden',textAlign:'center'}}>
   <div style={{position:'absolute',inset:0,fontSize:44,lineHeight:'100px',whiteSpace:'nowrap',translate:`0px ${mix(120,0,phase(t,4.317,4.83))-phase(t,7.8,8.3)*150}px`}}>假如现在有两个男生，同时认识了一个女生，</div>
   <div style={{position:'absolute',inset:0,fontFamily:'EditorialSerif',fontSize:68,lineHeight:'100px',whiteSpace:'nowrap',color:C.orange,translate:`0px ${mix(150,0,phase(t,7.78,8.3))}px`}}>假如你是女生又会怎么选？</div>
  </div>
  <div style={{position:'absolute',left:100,bottom:58,right:100,height:2,background:'#b6a990'}}/>
 </AbsoluteFill>;
};
