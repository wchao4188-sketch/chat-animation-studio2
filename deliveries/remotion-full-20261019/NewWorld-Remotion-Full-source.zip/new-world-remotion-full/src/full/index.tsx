import React from 'react';
import {Composition,registerRoot} from 'remotion';
import {FullFilm} from './Film';
const Root=()=> <Composition id="NewWorldFull" component={FullFilm} durationInFrames={6600} fps={30} width={2560} height={1440}/>;
registerRoot(Root);
