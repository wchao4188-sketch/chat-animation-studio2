import React from 'react';
import {registerRoot,Composition} from 'remotion';
import {OpeningV2} from './OpeningV2';
const RootV2=()=> <Composition id="NewWorldOpeningV2" component={OpeningV2} durationInFrames={300} fps={30} width={2560} height={1440}/>;
registerRoot(RootV2);
