export type Vec={x:number;y:number};
export type Pose={x:number;y:number;scale:number;angle:number;rx:number;ry:number};
export type Cable={a:Vec;b:Vec;c:Vec;d:Vec};
export const mix=(a:number,b:number,u:number)=>a+(b-a)*u;
export const clamp=(x:number)=>Math.max(0,Math.min(1,x));
// C2 motion: velocity and acceleration both become zero at each authored endpoint.
export const phase=(t:number,start:number,end:number)=>{const u=clamp((t-start)/(end-start));return u*u*u*(u*(u*6-15)+10);};
const radians=(x:number)=>x*Math.PI/180;
export const mixPose=(a:Pose,b:Pose,u:number):Pose=>({x:mix(a.x,b.x,u),y:mix(a.y,b.y,u),scale:mix(a.scale,b.scale,u),angle:mix(a.angle,b.angle,u),rx:mix(a.rx,b.rx,u),ry:mix(a.ry,b.ry,u)});
// Exact projection of the existing phone's CSS transform, applied right-to-left
// around the fixed 180,290 transform origin. The SVG and screen sockets use this.
export const project=(pose:Pose,p:Vec):Vec=>{
 const x=(p.x-180)*pose.scale,y=(p.y-290)*pose.scale;
 const ay=radians(pose.ry),ax=radians(pose.rx),az=radians(pose.angle);
 const xx=x*Math.cos(ay),zz=-x*Math.sin(ay);
 const yy=y*Math.cos(ax)-zz*Math.sin(ax),z=y*Math.sin(ax)+zz*Math.cos(ax);
 const xxx=xx*Math.cos(az)-yy*Math.sin(az),yyy=xx*Math.sin(az)+yy*Math.cos(az);
 const w=1-z/1600;return {x:pose.x+xxx/w,y:pose.y+yyy/w};
};
export const poseCss=(p:Pose)=>`perspective(1600px) rotateZ(${p.angle}deg) rotateX(${p.rx}deg) rotateY(${p.ry}deg) scale(${p.scale})`;
const normalize=(p:Vec)=>{const d=Math.hypot(p.x,p.y)||1;return{x:p.x/d,y:p.y/d};};
export const cable=(source:Pose,sourceLocal:Vec,target:Pose,targetLocal:Vec,side:number):Cable=>{
 const a=project(source,sourceLocal),d=project(target,targetLocal);
 const s=project(source,{x:sourceLocal.x+side*45,y:sourceLocal.y});
 const e=project(target,{x:targetLocal.x-side*45,y:targetLocal.y});
 const ns=normalize({x:s.x-a.x,y:s.y-a.y}),nt=normalize({x:e.x-d.x,y:e.y-d.y});
 const reach=Math.min(240,Math.hypot(d.x-a.x,d.y-a.y)*.31);
 return {a,b:{x:a.x+ns.x*reach,y:a.y+ns.y*reach},c:{x:d.x+nt.x*reach,y:d.y+nt.y*reach},d};
};
export const pathD=(c:Cable)=>`M${c.a.x} ${c.a.y} C${c.b.x} ${c.b.y} ${c.c.x} ${c.c.y} ${c.d.x} ${c.d.y}`;
export const curvePoint=(c:Cable,t:number):Vec=>{const q=1-t;return{x:q*q*q*c.a.x+3*q*q*t*c.b.x+3*q*t*t*c.c.x+t*t*t*c.d.x,y:q*q*q*c.a.y+3*q*q*t*c.b.y+3*q*t*t*c.c.y+t*t*t*c.d.y};};
// Invert an arc-length table. SVG dash progress is arc length, not Bezier t.
export const pointAtProgress=(c:Cable,progress:number):Vec=>{
 if(progress<=0)return c.a;if(progress>=1)return c.d;
 const pts=[c.a],lengths=[0];for(let i=1;i<=256;i++){const p=curvePoint(c,i/256),last=pts[i-1];pts.push(p);lengths.push(lengths[i-1]+Math.hypot(p.x-last.x,p.y-last.y));}
 const wanted=lengths[256]*progress;let i=1;while(i<256&&lengths[i]<wanted)i++;
 const u=(wanted-lengths[i-1])/(lengths[i]-lengths[i-1]||1);
 return curvePoint(c,(i-1+u)/256);
};
export const getScene=(t:number)=>{
 const focus=phase(t,.845,2.710),pull=phase(t,3.768,5.903),leftEntry=phase(t,4.317,5.2),rightEntry=phase(t,5.903,6.701);
 const near:Pose={x:mix(1885,1860,focus),y:mix(715,700,focus),scale:mix(1.62,1.72,focus),angle:mix(-9,-7,focus),rx:mix(12,8,focus),ry:mix(-28,-16,focus)};
 const girl=mixPose(near,{x:1280,y:570,scale:1,angle:0,rx:0,ry:0},pull);
 const left=mixPose({x:-420,y:1040,scale:.91,angle:-28,rx:8,ry:40},{x:520,y:870,scale:.91,angle:-12,rx:8,ry:16},leftEntry);
 const right=mixPose({x:2980,y:1040,scale:.91,angle:28,rx:8,ry:-40},{x:2040,y:870,scale:.91,angle:12,rx:8,ry:-16},rightEntry);
 const split=phase(t,2.710,3.768),rowY=mix(367,350,split),rowH=mix(83,62,split);
 const girlLeft={x:1,y:rowY+rowH/2},girlRight={x:359,y:465},leftPort={x:359,y:407},rightPort={x:1,y:407};
 const cables=[cable(girl,girlLeft,left,leftPort,-1),cable(girl,girlRight,right,rightPort,1)];
 return {girl,left,right,focus,pull,leftEntry,rightEntry,rowY,rowH,split,girlLeft,girlRight,leftPort,rightPort,cables,leftWire:phase(t,3.768,5.903),rightWire:phase(t,6.431,6.961),firstContact:phase(t,5.903,6.16),secondContact:phase(t,6.961,7.24),secondRow:phase(t,5.903,6.431),firstSocket:phase(t,2.710,3.768),secondSocket:phase(t,5.903,6.431)};
};
