import React from 'react';
import {Easing,interpolate} from 'remotion';
import {C} from './Phone';
const cubic=Easing.bezier(.2,.8,.2,1);
const tween=(f:number,a:number,b:number)=>interpolate(f,[a,b],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:cubic});
export const TitleV2=({frame,fps}:{frame:number;fps:number})=>{
 const exit=tween(frame,4.05*fps,4.8*fps);return <div style={{position:'absolute',left:156,top:310,transform:`translateY(${-exit*1100}px) rotate(${-exit*2}deg)`,clipPath:'inset(-300px -100px -200px -50px)',fontFamily:'EditorialSerif',color:C.ink}}>
  <div style={{fontFamily:'EditorialSans',fontSize:22,letterSpacing:7,marginBottom:45,color:'#766b5c'}}>从第一句话，开始认识一个人</div>
  {['为什么会聊天的人','大多数的开场','不是询问信息？'].map((s,i)=><div key={s} style={{height:153,overflow:'hidden'}}><div style={{fontSize:i===2?111:100,lineHeight:'145px',whiteSpace:'nowrap',color:i===2?C.orange:C.ink,translate:`0px ${interpolate(frame,[i*.23*fps,(i*.23+.62)*fps],[170,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:cubic})}px`}}>{s}</div></div>)}
  <svg width="1060" height="50"><path d="M0 15C290 10 500 36 930 13" stroke={C.orange} strokeWidth="5" fill="none" pathLength="1" strokeDasharray="1" strokeDashoffset={1-tween(frame,.84*fps,2.710*fps)}/></svg>
 </div>;
};
