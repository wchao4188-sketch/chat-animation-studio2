import React from 'react';
import {Pose,poseCss,getScene,phase} from './geometry';
export const C={paper:'#e9e2d4',ink:'#211e1a',faint:'#b8ae9b',orange:'#d75230',gold:'#e4b75e',cream:'#fff3da'};
const Person=({female=false,color=C.cream}:{female?:boolean;color?:string})=><g fill="none" stroke={color} strokeWidth="4" strokeLinecap="round"><path d="M-47 63 C-43 16 43 16 47 63"/><circle cy="-10" r="26"/>{female?<path d="M-35 6 C-59-74 64-80 36 5 M-32-27 Q-1-63 30-22"/>:<path d="M-23-20 Q-11-48 23-25"/>}<path d="M-18-2h1 M17-2h1 M-5 17q8 5 15-1" strokeWidth="3"/></g>;

export const PhoneV2=({pose,label,female=false,color=C.orange,progress=1,role,t}:{pose:Pose;label:string;female?:boolean;color?:string;progress?:number;role:'center'|'boy1'|'boy2';t:number})=>{
 const {x,y,scale,angle,rx,ry}=pose;const state=getScene(t);
 return <div style={{position:'absolute',left:x-180,top:y-290,width:360,height:580,transform:poseCss(pose),transformOrigin:'50% 50%',transformStyle:'preserve-3d'}}>
  {/* Extruded edges are actual displaced layers; the object, not the whole frame, changes viewpoint. */}
  {[18,12,6].map((z)=><div key={z} style={{position:'absolute',inset:0,borderRadius:45,background:'#39312a',transform:`translate(${z}px,${z*1.1}px) translateZ(${-z}px)`,boxShadow:z===18?'12px 25px 38px #30231635':undefined}}/>)}
  <svg width="360" height="580" viewBox="0 0 360 580" style={{position:'absolute',overflow:'visible'}}>
   <defs><clipPath id="row2Content"><rect x="42" y="434" width="276" height={62*state.secondRow}/></clipPath><linearGradient id={'metal'+role} x1="0" y1="0" x2="1" y2="1"><stop stopColor="#f1e1c2"/><stop offset=".3" stopColor="#9a8b76"/><stop offset=".7" stopColor="#f5dfae"/><stop offset="1" stopColor="#7b6b56"/></linearGradient><linearGradient id={'screen'+role} x2=".6" y2="1"><stop stopColor="#36322c"/><stop offset="1" stopColor="#171612"/></linearGradient></defs>
   <rect x="1" y="1" width="358" height="578" rx="45" fill={'url(#metal'+role+')'}/>
   <rect x="7" y="7" width="346" height="566" rx="40" fill={'url(#screen'+role+')'}/>
   <rect x="18" y="18" width="324" height="544" rx="33" fill="none" stroke="#8d806b" strokeWidth=".8"/>
   <rect x="132" y="22" width="96" height="12" rx="6" fill="#0c0b09"/>
   <g transform="translate(180 160)"><circle r="79" fill={color+'18'} stroke={color} strokeWidth="1.5"/><Person female={female}/></g>
   <text x="180" y="293" textAnchor="middle" fontFamily="EditorialSerif" fontSize="34" fill={C.cream}>{label}</text>
   <path d="M50 331H310" stroke="#746653" strokeWidth="1"/>
   {role==='center'?<>
    <rect x="42" y={state.rowY} width="276" height={state.rowH} rx="20" fill="#f3e4ca08" stroke={color} strokeWidth="2" pathLength="1" strokeDasharray="1" strokeDashoffset={1-phase(t,.13,.845)}/>
    {<g opacity={1-state.firstContact}>{[140,180,220].map(cx=><circle key={cx} cx={cx} cy={state.rowY+state.rowH/2} r="5" fill={color}/>)}</g>}
    <g><text x="180" y={state.rowY+state.rowH/2+8} fontFamily="EditorialSans" fontSize="22" textAnchor="middle" fill={C.cream} opacity={state.firstContact}>男生 01</text></g>
    {state.secondRow>0?<g clipPath="url(#row2Content)">
     <rect x="42" y="434" width="276" height={62*state.secondRow} rx="20" fill="#f3e4ca08" stroke={color} strokeWidth="2"/>
     {<g opacity={state.secondRow*(1-state.secondContact)}>{[140,180,220].map(cx=><circle key={cx} cx={cx} cy="465" r="4" fill={color}/>)}</g>}
     <text x="180" y="473" fontFamily="EditorialSans" fontSize="22" textAnchor="middle" fill={C.cream} opacity={state.secondContact}>男生 02</text>
    </g>:null}
    <path d={`M42 ${state.girlLeft.y}H1`} fill="none" stroke={C.orange} strokeWidth="2.2" pathLength="1" strokeDasharray="1" strokeDashoffset={1-state.firstSocket}/>
    <path d="M318 465H359" fill="none" stroke="#aab48a" strokeWidth="2.2" pathLength="1" strokeDasharray="1" strokeDashoffset={1-state.secondSocket}/>
    <circle cx="1" cy={state.girlLeft.y} r="5" fill={C.orange} opacity={state.firstSocket}/>
    <circle cx="359" cy="465" r="5" fill="#aab48a" opacity={state.secondSocket}/>
    <rect data-device-port="girl-left" x={1-.01} y={state.girlLeft.y-.01} width=".02" height=".02" fill="transparent"/>
    <rect data-device-port="girl-right" x={359-.01} y={465-.01} width=".02" height=".02" fill="transparent"/>
   </>:<>
    <rect x="42" y="367" width="276" height="83" rx="22" fill="#f3e4ca08" stroke={color} strokeWidth="2" pathLength="1" strokeDasharray="1" strokeDashoffset={1-progress}/>
    <path d="M68 449L59 465L91 449" stroke={color} strokeWidth="2" fill="#22201a"/>
    {[140,180,220].map(cx=><circle key={cx} cx={cx} cy="407" r="5" fill={color}/>)}
    <path d={role==='boy1'?'M359 407H318':'M1 407H42'} stroke={color} strokeWidth="2.2" fill="none" pathLength="1" strokeDasharray="1" strokeDashoffset={1-(role==='boy1'?state.firstContact:state.secondContact)}/>
    <circle cx={role==='boy1'?359:1} cy="407" r="5" fill={color} opacity={role==='boy1'?state.leftWire:state.rightWire}/>
    <rect data-device-port={role==='boy1'?'left':'right'} x={(role==='boy1'?359:1)-.01} y={407-.01} width=".02" height=".02" fill="transparent"/>
   </>}
   <path d="M142 540H218" stroke="#c3b398" strokeWidth="4" strokeLinecap="round"/>
  </svg>
 </div>;
};