#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
./node_modules/.bin/remotion render src/v2/index.tsx NewWorldOpeningV2 output/v2/NewWorld-Remotion-10s-v2.mp4 --browser-executable=/usr/bin/chromium --concurrency=2 --codec=h264 --crf=17 --log=verbose
