#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
./node_modules/.bin/remotion render src/full/index.tsx NewWorldFull output/full/NewWorld-Remotion-Full.mp4 --browser-executable=/usr/bin/chromium --concurrency=4 --codec=h264 --crf=18 --log=verbose
