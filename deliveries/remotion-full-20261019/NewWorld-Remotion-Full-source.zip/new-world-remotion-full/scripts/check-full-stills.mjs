import {bundle} from '@remotion/bundler';
import {selectComposition,renderStill,openBrowser} from '@remotion/renderer';
import fs from 'node:fs/promises';
const url=await bundle({entryPoint:'src/full/index.tsx'});
const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium',logLevel:'error'});
try{
const comp=await selectComposition({serveUrl:url,id:'NewWorldFull',puppeteerInstance:browser});
await fs.mkdir('output/full/large',{recursive:true});
for(const sec of [14,25,35,61,75,85,95,110,123,140,148,164,172,189,208]){
await renderStill({composition:comp,serveUrl:url,puppeteerInstance:browser,frame:Math.round(sec*30),output:`output/full/large/${sec}.png`,imageFormat:'png',logLevel:'error'});console.log('checked frame',sec);
}
}finally{await browser.close({silent:true});}
