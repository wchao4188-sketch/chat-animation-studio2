from pathlib import Path
import subprocess,json,hashlib,math,re
import numpy as np
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parents[1];o=R/'output/full';v=o/'NewWorld-Remotion-Full.mp4';review=o/'review';review.mkdir(exist_ok=True)
p=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(v)]));(o/'probe.json').write_text(json.dumps(p,indent=2));s=next(x for x in p['streams'] if x['codec_type']=='video');assert(s['width'],s['height'],s['r_frame_rate'],int(s['nb_frames']))==(2560,1440,'30/1',6600)
r=subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(v),'-f','null','-'],capture_output=True,text=True);assert r.returncode==0;(o/'decode.log').write_text(r.stderr)
rows=json.loads((R/'src/full/timeline.json').read_text());original_path=R.parent/'assets/script-original.md';original_path=original_path if original_path.exists() else o/'完整文案.md';original=[x.strip().removeprefix('# ').strip() for x in original_path.read_text().splitlines() if x.strip()];assert original==[x['text'] for x in rows]
indices=set(range(0,6600,30))|{6599}|{round((x['start']+min(x['end'],x['start']+x['duration']))/2*30) for x in rows}
for t in [12.264,15.04,18.54,23.02,29.111,31.43,49.04,58.99,68.77,81.91,88.19,93.32,103.47,115.6,120.34,134.82,143.53,146.97,156.68,162.71,166.26,169.65,180.07,185.22,193.74,199.79,205.83,208.95]:
 for d in [-.1,.3,.7,1.2]:indices.add(max(0,min(6599,round((t+d)*30))))
proc=subprocess.Popen(['ffmpeg','-v','error','-i',str(v),'-an','-vf','scale=640:360','-pix_fmt','rgb24','-f','rawvideo','-'],stdout=subprocess.PIPE)
samples={};motion=[];last=None;n=0;size=640*360*3
while True:
 b=proc.stdout.read(size)
 if not b:break
 assert len(b)==size;a=np.frombuffer(b,np.uint8).reshape(360,640,3)
 if n in indices:samples[n]=Image.fromarray(a.copy())
 if last is not None:motion.append(float(np.abs(a.astype(np.int16)-last).mean()))
 last=a.astype(np.int16);n+=1
assert proc.wait()==0 and n==6600
(o/'motion.json').write_text(json.dumps({'frames':n,'differences':motion,'max':max(motion)},indent=2))
font=ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',20);pages=[];idx=sorted(samples)
for k in range(math.ceil(len(idx)/12)):
 image=Image.new('RGB',(1920,1560),'#e9e2d4');draw=ImageDraw.Draw(image)
 for j,f in enumerate(idx[k*12:(k+1)*12]):
  x=j%3*640;y=j//3*390;image.paste(samples[f],(x,y));draw.text((x+12,y+362),f'{f:04} / {f/30:.3f}s',font=font,fill='#211e1a')
 image.save(review/f'{k+1:02}.jpg',quality=90);pages.append(image)
pages[0].save(o/'NewWorld-Full-Keyframes.pdf',save_all=True,append_images=pages[1:],resolution=120)
r=subprocess.run(['ffmpeg','-hide_banner','-i',str(v),'-af','ebur128=peak=true,silencedetect=noise=-60dB:d=0.25','-vn','-f','null','-'],capture_output=True,text=True);assert r.returncode==0;(o/'audio-check.log').write_text(r.stderr)
def audio(path):return np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-vn','-ac','1','-ar','16000','-f','f32le','-']),np.float32)
a=audio(v);b=audio(R/'public/full/soundtrack.m4a');length=min(len(a),len(b));corr=float(np.corrcoef(a[:length],b[:length])[0,1]);assert corr>.999
preserved=None
manifest=R/'output/v2/v1-preservation.json'
if manifest.exists():
 old=json.loads(manifest.read_text());available=all((R/k).exists() for k in old)
 if available:assert all(hashlib.sha256((R/k).read_bytes()).hexdigest()==h for k,h in old.items());preserved=True
prior=json.loads((R/'prior-artifacts.sha256.json').read_text())
if all((R.parent/k).exists() for k in prior):assert all(hashlib.sha256((R.parent/k).read_bytes()).hexdigest()==h for k,h in prior.items())
v2=R/'output/v2/NewWorld-Remotion-10s-v2.mp4'
if v2.exists():assert hashlib.sha256(v2.read_bytes()).hexdigest()=='99dd7101e8b3cce911e61260d090b9995321c4aff363adb23527a0b7df347d2f'
q={'bytes':v.stat().st_size,'sha256':hashlib.sha256(v.read_bytes()).hexdigest(),'resolution':[2560,1440],'fps':30,'video_frames':6600,'video_duration_seconds':220,'container_duration':p['format']['duration'],'all_frames_decoded':n,'strict_decode_exit_code':0,'script_paragraphs':48,'script_exact_match':True,'visual_review_samples':len(idx),'overview_pages':len(pages),'soundtrack_correlation':corr,'v1_v2_prior_artifacts_unchanged':preserved,'narration':'existing narration.wav, unchanged content and timing','music':'user music, 4s crossfade loop; normalized under narration','human_audio_listening':False,'final_question_hold_seconds':10.65}
(o/'quality.json').write_text(json.dumps(q,indent=2));print(json.dumps(q,indent=2))
