from pathlib import Path
import zipfile,json,hashlib,shutil
r=Path(__file__).resolve().parents[1];o=r/'output/full';q=json.loads((o/'quality.json').read_text());assert q.get('visual_review_completed') is True
z=o/'NewWorld-Remotion-Full-source.zip';files=[]
for folder in ['src','public','.agents/skills']:files+=list((r/folder).rglob('*'))
for folder,pattern in [('scripts','*.sh'),('scripts','*.mjs')]:files+=list((r/folder).glob(pattern))
files += [r/'scripts'/n for n in ['quality-full.py','package-full.py']]
files += [r/n for n in ['package.json','package-lock.json','tsconfig.json','FULL-README.md','V2-README.md','README.md','skills-lock.json','requirements-analysis.txt','prior-artifacts.sha256.json']]
files += [o/n for n in ['quality.json','验收记录.md','probe.json','完整文案.md','audio-check.log','decode.log','NewWorld-Full-Keyframes.pdf','v2-preservation.json']]
files += [r/'analysis/music-analysis.json']
files += list((r.parent/'assets/licenses').glob('*'))
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as f:
 for p in sorted(set(files)):
  if p.is_file():f.write(p,Path('new-world-remotion-full')/(p.relative_to(r) if p.is_relative_to(r) else Path('licenses')/p.name))
 narration=r/'audio-sources/narration.wav';narration=narration if narration.exists() else r.parent/'assets/narration.wav'
 f.write(narration,'new-world-remotion-full/audio-sources/narration.wav')
 music=r/'audio-sources/user-music-original.mp4';music=music if music.exists() else Path('/workspace/attachments/e0ebc65e-d848-4388-bb8b-30e2e6bd107a/mmexport1792300994359.mp3')
 f.write(music,'new-world-remotion-full/audio-sources/user-music-original.mp4')
with zipfile.ZipFile(z) as f:assert f.testzip() is None
assert z.stat().st_size<100*1024*1024
print(json.dumps({'zip_bytes':z.stat().st_size,'zip_sha256':hashlib.sha256(z.read_bytes()).hexdigest()},indent=2))
