import React from 'react';
import {AbsoluteFill,Easing,interpolate,staticFile,useCurrentFrame,useVideoConfig,delayRender,continueRender,cancelRender} from 'remotion';
import {Audio} from '@remotion/media';
import {loadFont} from '@remotion/fonts';

const fontHandle=delayRender('Load bundled CJK fonts');
Promise.all([
  loadFont({family:'EditorialSerif',url:staticFile('fonts/EditorialSerif.woff'),weight:'700'}),
  loadFont({family:'EditorialSans',url:staticFile('fonts/EditorialSans.woff'),weight:'400'}),
]).then(()=>continueRender(fontHandle)).catch(cancelRender);
const C={paper:'#e9e2d4',ink:'#211e1a',faint:'#b8ae9b',orange:'#d75230',gold:'#e4b75e',cream:'#fff3da'};
const clamp=(x:number)=>Math.max(0,Math.min(1,x));
const cubic=Easing.bezier(.2,.8,.2,1);
const tween=(f:number,a:number,b:number,x=0,y=1)=>interpolate(f,[a,b],[x,y],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:cubic});
const lerp=(a:number,b:number,u:number)=>a+(b-a)*u;
// Cubics are shared by the stroke and every information particle, so paths never disconnect.
const point=(p:number,side:number)=>{const q=1-p;const a=side<0?{x:520,y:880}:{x:2040,y:880};const b=side<0?{x:550,y:500}:{x:2010,y:500};const c=side<0?{x:1090,y:900}:{x:1470,y:900};const d={x:1280,y:670};return {x:q*q*q*a.x+3*q*q*p*b.x+3*q*p*p*c.x+p*p*p*d.x,y:q*q*q*a.y+3*q*q*p*b.y+3*q*p*p*c.y+p*p*p*d.y};};
const path=(s:number)=>s<0?'M520 880 C550 500 1090 900 1280 670':'M2040 880 C2010 500 1470 900 1280 670';
const Person=({female=false,color=C.cream}:{female?:boolean;color?:string})=><g fill="none" stroke={color} strokeWidth="4" strokeLinecap="round"><path d="M-47 63 C-43 16 43 16 47 63"/><circle cy="-10" r="26"/>{female?<path d="M-35 6 C-59-74 64-80 36 5 M-32-27 Q-1-63 30-22"/>:<path d="M-23-20 Q-11-48 23-25"/>}<path d="M-18-2h1 M17-2h1 M-5 17q8 5 15-1" strokeWidth="3"/></g>;

const Phone=({x,y,scale=1,angle=0,rx=0,ry=0,label,female=false,color=C.orange,progress=1,role=''}:{x:number;y:number;scale?:number;angle?:number;rx?:number;ry?:number;label:string;female?:boolean;color?:string;progress?:number;role?:string})=>{
 return <div style={{position:'absolute',left:x-180,top:y-290,width:360,height:580,transform:`perspective(1600px) rotateZ(${angle}deg) rotateX(${rx}deg) rotateY(${ry}deg) scale(${scale})`,transformOrigin:'50% 50%',transformStyle:'preserve-3d'}}>
  {/* Extruded edges are actual displaced layers; the object, not the whole frame, changes viewpoint. */}
  {[18,12,6].map((z)=><div key={z} style={{position:'absolute',inset:0,borderRadius:45,background:'#39312a',transform:`translate(${z}px,${z*1.1}px) translateZ(${-z}px)`,boxShadow:z===18?'12px 25px 38px #30231635':undefined}}/>)}
  <svg width="360" height="580" viewBox="0 0 360 580" style={{position:'absolute',overflow:'visible'}}>
   <defs><linearGradient id={'metal'+role} x1="0" y1="0" x2="1" y2="1"><stop stopColor="#f1e1c2"/><stop offset=".3" stopColor="#9a8b76"/><stop offset=".7" stopColor="#f5dfae"/><stop offset="1" stopColor="#7b6b56"/></linearGradient><linearGradient id={'screen'+role} x2=".6" y2="1"><stop stopColor="#36322c"/><stop offset="1" stopColor="#171612"/></linearGradient></defs>
   <rect x="1" y="1" width="358" height="578" rx="45" fill={'url(#metal'+role+')'}/>
   <rect x="7" y="7" width="346" height="566" rx="40" fill={'url(#screen'+role+')'}/>
   <rect x="18" y="18" width="324" height="544" rx="33" fill="none" stroke="#8d806b" strokeWidth=".8"/>
   <rect x="132" y="22" width="96" height="12" rx="6" fill="#0c0b09"/>
   <g transform="translate(180 160)"><circle r="79" fill={color+'18'} stroke={color} strokeWidth="1.5"/><Person female={female}/></g>
   <text x="180" y="293" textAnchor="middle" fontFamily="EditorialSerif" fontSize="34" fill={C.cream}>{label}</text>
   <path d="M50 331H310" stroke="#746653" strokeWidth="1"/>
   <rect x="42" y="367" width="276" height="83" rx="22" fill="#f3e4ca08" stroke={color} strokeWidth="2" pathLength="1" strokeDasharray="1" strokeDashoffset={1-progress}/>
   <path d="M68 449L59 465L91 449" stroke={color} strokeWidth="2" fill="#22201a" opacity={progress}/>
   <circle cx="140" cy="407" r="5" fill={color}/><circle cx="180" cy="407" r="5" fill={color}/><circle cx="220" cy="407" r="5" fill={color}/>
   <path d="M142 540H218" stroke="#c3b398" strokeWidth="4" strokeLinecap="round"/>
  </svg>
 </div>;
};

const Title=({frame,fps}:{frame:number;fps:number})=>{
 const exit=tween(frame,4.05*fps,4.8*fps);return <div style={{position:'absolute',left:156,top:310,transform:`translateY(${-exit*1100}px) rotate(${-exit*2}deg)`,clipPath:'inset(-300px -100px -200px -50px)',fontFamily:'EditorialSerif',color:C.ink}}>
  <div style={{fontFamily:'EditorialSans',fontSize:22,letterSpacing:7,marginBottom:45,color:'#766b5c'}}>从第一句话，开始认识一个人</div>
  {['为什么会聊天的人','大多数的开场','不是询问信息？'].map((s,i)=><div key={s} style={{height:153,overflow:'hidden'}}><div style={{fontSize:i===2?111:100,lineHeight:'145px',whiteSpace:'nowrap',color:i===2?C.orange:C.ink,translate:`0px ${interpolate(frame,[i*.23*fps,(i*.23+.62)*fps],[170,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:cubic})}px`}}>{s}</div></div>)}
  <svg width="1060" height="50"><path d="M0 15C290 10 500 36 930 13" stroke={C.orange} strokeWidth="5" fill="none" pathLength="1" strokeDasharray="1" strokeDashoffset={1-tween(frame,.84*fps,2.710*fps)}/></svg>
 </div>;
};

export const Opening=()=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();const t=frame/fps;
 const unfold=tween(frame,4.317*fps,5.9*fps);const end=tween(frame,8.557*fps,9.16*fps);
 const introPhoneScale=lerp(1.62+.10*tween(frame,2.710*fps,3.24*fps),1.0,unfold);const cx=lerp(1885,1280,unfold);const cy=lerp(715,570,unfold);
 // Initial close-up rotates into the three-person conversation space. It remains the same central window.
 const phoneReveal=tween(frame,.13*fps,.845*fps);const wire=tween(frame,5.2*fps,6.961*fps);
 return <AbsoluteFill style={{background:C.paper,color:C.ink,fontFamily:'EditorialSans',overflow:'hidden'}}>
  <Audio name="Uploaded soundtrack — no added voice" src={staticFile('music-opening.wav')}/>
  {/* Printed page texture: fixed, so it never masquerades as camera shake. */}
  <svg width="2560" height="1440" style={{position:'absolute',inset:0}}>
   <defs><radialGradient id="paperGlow"><stop stopColor="#fffaeb"/><stop offset="1" stopColor={C.paper}/></radialGradient><pattern id="dots" width="22" height="22" patternUnits="userSpaceOnUse"><circle cx="1" cy="1" r=".65" fill="#7a6b50" opacity=".16"/></pattern><linearGradient id="floorGlow"><stop stopColor="#b59b7333"/><stop offset="1" stopColor="#b59b7300"/></linearGradient></defs>
   <rect width="2560" height="1440" fill="url(#paperGlow)"/><rect width="2560" height="1440" fill="url(#dots)"/>
   <path d="M-100 1240 C700 1000 1830 1500 2700 1080" fill="none" stroke="#b6a589" strokeWidth="1"/>
   <ellipse cx={lerp(1920,1280,unfold)} cy="1165" rx={lerp(490,1120,unfold)} ry={lerp(60,110,unfold)} fill="url(#floorGlow)"/>
  </svg>
  <div style={{position:'absolute',top:66,left:100,right:100,display:'flex',justifyContent:'space-between',fontSize:21,letterSpacing:4,color:'#726655'}}><span>新世界 / 会聊天的人</span><span>OPENING STUDY · 01</span></div>
  <div style={{position:"absolute",inset:0,clipPath:"inset(190px 0px 320px 0px)"}}><Title frame={frame} fps={fps}/></div>
  {/* The strokes and their packets are authored in one stable scene coordinate system. */}
  <svg width="2560" height="1440" style={{position:'absolute',inset:0,opacity:unfold}}>
   <defs><filter id="wireShadow"><feDropShadow dx="0" dy="7" stdDeviation="4" floodColor="#726046" floodOpacity=".25"/></filter></defs>
   {[-1,1].map(side=><g key={side}>
    <path d={path(side)} fill="none" stroke="#c7b598" strokeWidth="16" pathLength="1" strokeDasharray="1" strokeDashoffset={1-wire}/>
    <path d={path(side)} fill="none" stroke={side<0?C.orange:'#7c8567'} strokeWidth="5" pathLength="1" strokeDasharray="1" strokeDashoffset={1-wire} filter="url(#wireShadow)"/>
    {Array.from({length:20},(_,i)=>{
      const p=clamp((t-5.9-i*.025)/1.05);const pt=point(p,side);const live=t>=5.9+i*.025&&p<1;
      return live?<g key={i} transform={`translate(${pt.x} ${pt.y}) rotate(${side*18})`}><rect x="-5" y="-5" width="10" height="10" rx="2" fill={side<0?C.orange:'#7c8567'}/>{i%6===0?<path d="M-18 0H-8" stroke={side<0?C.orange:'#7c8567'} strokeWidth="2"/>:null}</g>:null;
    })}
   </g>)}
  </svg>
  {/* A continuous ring announces the shared situation, never a liking score. */}
  <svg width="2560" height="1440" style={{position:'absolute',inset:0,pointerEvents:'none'}}>
   <ellipse cx="1280" cy="1030" rx="850" ry="195" fill="none" stroke="#a48a61" strokeWidth="1.4" pathLength="1" strokeDasharray="1" strokeDashoffset={1-tween(frame,6.16*fps,7.2*fps)} opacity={unfold*.65}/>
   <circle cx="1280" cy="570" r={lerp(250,320,end)} fill="none" stroke={C.orange} strokeWidth="2" pathLength="1" strokeDasharray="1" strokeDashoffset={1-end} opacity={end*.55}/>
  </svg>
  {/* Boy 01 enters from the left in perspective; Boy 02 from the right, with equal scale and no success cue. */}
  {unfold>0?<Phone x={lerp(-360,520,unfold)} y={lerp(1120,870,unfold)} scale={.91} angle={lerp(-30,-12,unfold)} ry={lerp(60,16,unfold)} rx={8} label="男生 01" color={C.orange} progress={wire} role="boy1"/>:null}
  {unfold>0?<Phone x={lerp(2920,2040,unfold)} y={lerp(1120,870,unfold)} scale={.91} angle={lerp(30,12,unfold)} ry={lerp(-60,-16,unfold)} rx={8} label="男生 02" color="#aab48a" progress={wire} role="boy2"/>:null}
  <Phone x={cx} y={cy} scale={introPhoneScale} angle={lerp(-9,0,unfold)} rx={lerp(12,0,unfold)} ry={lerp(-28,0,unfold)} label={unfold>.4?'女生':'第一句话'} female={unfold>.4} color={C.gold} progress={phoneReveal} role="center"/>
  {/* Under magnification, particles resolve into the three dots of the central chat bubble. */}
  {unfold<.98?<svg width="2560" height="1440" style={{position:'absolute',inset:0,pointerEvents:'none'}}>
   {Array.from({length:36},(_,i)=>{
    const a=i*2.39996;const radius=380+(i%5)*37;const p=tween(frame,(.15+i*.008)*fps,(1.7+i*.012)*fps);const targetX=1885+(i%3-1)*65;const targetY=715+186;
    const x=lerp(1885+Math.cos(a)*radius,targetX,p);const y=lerp(715+Math.sin(a)*radius,targetY,p);
    return p<.995?<rect key={i} x={x} y={y} width={lerp(12,4,p)} height={lerp(12,4,p)} rx="2" fill={i%3===0?C.orange:C.gold} opacity={(1-tween(frame,3.5*fps,4.4*fps))*.8}/>:null;
   })}
  </svg>:null}
  {/* Text changes through a vertical reveal, then holds. No card dissolves. */}
  {unfold>0?<div style={{position:'absolute',left:300,right:300,top:165,height:115,overflow:'hidden',textAlign:'center',fontFamily:'EditorialSerif',fontSize:62,lineHeight:'100px'}}><div style={{translate:`0px ${lerp(150,0,tween(frame,4.317*fps,4.83*fps))}px`}}>两个男生，同时认识了一个女生。</div></div>:null}
  <div style={{position:'absolute',left:200,right:200,bottom:110,height:125,overflow:'hidden',textAlign:'center'}}>
   <div style={{position:'absolute',inset:0,fontSize:44,lineHeight:'100px',translate:`0px ${lerp(120,0,tween(frame,4.317*fps,4.83*fps))-tween(frame,7.8*fps,8.3*fps)*150}px`}}>假如现在有两个男生，同时认识了一个女生，</div>
   <div style={{position:'absolute',inset:0,fontFamily:'EditorialSerif',fontSize:68,lineHeight:'100px',color:C.orange,translate:`0px ${lerp(150,0,tween(frame,7.78*fps,8.3*fps))}px`}}>假如你是女生又会怎么选？</div>
  </div>
  <div style={{position:'absolute',left:100,bottom:58,right:100,height:2,background:'#b6a990'}}><div style={{height:2,width:interpolate(frame,[0,299],[0,2360]),background:C.orange}}/></div>
 </AbsoluteFill>;
};
