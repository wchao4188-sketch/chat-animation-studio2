import React from 'react';
import {Composition} from 'remotion';
import {Opening} from './Opening';
export const Root=()=> <Composition id="NewWorldOpening" component={Opening} durationInFrames={300} fps={30} width={2560} height={1440}/>;
