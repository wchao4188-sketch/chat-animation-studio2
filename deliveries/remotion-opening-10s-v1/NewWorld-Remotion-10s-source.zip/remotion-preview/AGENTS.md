本目录是「新世界」的独立 Remotion 10秒样片工程。不要重新生成或覆盖上一级 output 中的既有成片、ZIP与验收文件，不访问项目1。
官方 Remotion Skills 已项目级安装于 .agents/skills。制作前读取 .agents/skills/remotion-best-practices/SKILL.md，再按实际任务读取其引用文件。所有动画由 useCurrentFrame 驱动，禁止使用依赖真实时间的CSS动画或随机行为。
先 npm ci，再 npm run studio；只在用户明确要求时渲染。当前样片固定300帧、30fps、2560×1440，不自动扩展整片。npm run render 仅输出本目录 output/NewWorld-Remotion-10s.mp4。保留用户后续修改；覆盖样片前先检查变化。
