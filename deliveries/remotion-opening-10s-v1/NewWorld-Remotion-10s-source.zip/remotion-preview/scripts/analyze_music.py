from pathlib import Path
import numpy as np,json,wave
from scipy.signal import stft,find_peaks,fftconvolve
R=Path(__file__).resolve().parents[1]
with wave.open(str(R/'analysis/music-mono.wav')) as w:sr=w.getframerate();x=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(float)/32768
hop=220;nfft=2048
freq,t,z=stft(x,sr,nperseg=nfft,noverlap=nfft-hop,boundary=None);mag=abs(z)
flux=np.maximum(np.diff(np.log1p(mag*100),axis=1),0);bands=[]
for low,hi in [(35,180),(180,1800),(1800,7000)]:
 env=flux[(freq>=low)&(freq<hi)].mean(0);env=np.maximum(env-np.median(env),0);bands.append(env/(np.percentile(env,95)+1e-9))
onset=.50*bands[0]+.3*bands[1]+.2*bands[2];tt=t[1:];rate=sr/hop
ac=fftconvolve(onset-onset.mean(),(onset-onset.mean())[::-1],mode='full')[len(onset)-1:];lo,hi=int(rate*60/180),int(rate*60/65);ps,_=find_peaks(ac[lo:hi]);ps=ps+lo;top=sorted(ps,key=lambda k:ac[k],reverse=True)[:6];candidates=[{'bpm':float(60*rate/k),'score':float(ac[k]/ac[0])} for k in top]
# Use a regular, energetic first-30-second excerpt; don't claim metrical downbeats from onset energy alone.
peaks,_=find_peaks(onset,distance=int(.20*rate),prominence=.30);peaks=peaks[(tt[peaks]>=0)&(tt[peaks]<30)]
strong=sorted(peaks,key=lambda k:onset[k],reverse=True)[:24]
# local autocorrelation for selected opening music, avoids soundtrack tempo changes
sel=onset[(tt>=0)&(tt<30)];local=fftconvolve(sel-sel.mean(),(sel-sel.mean())[::-1],mode='full')[len(sel)-1:];pp,_=find_peaks(local[lo:hi]);pp+=lo;pp=sorted(pp,key=lambda k:local[k],reverse=True)[:6];local_c=[{'bpm':float(60*rate/k),'score':float(local[k]/local[0])} for k in pp]
result={'source':'mmexport1792300994359.mp3 (MP4 container, extracted AAC audio)','duration_seconds':len(x)/sr,'method':'positive log-spectral flux, three frequency bands, autocorrelation tempo candidates; strong onsets are measured energy accents, not asserted bar downbeats','global_bpm_candidates':candidates,'first_30s_bpm_candidates':local_c,'first_30s_strong_onsets':[{'seconds':float(tt[k]),'strength':float(onset[k])} for k in sorted(strong)],'first_12s_onsets':[{'seconds':float(tt[k]),'strength':float(onset[k])} for k in peaks if tt[k]<12]}
(R/'analysis/music-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
# Compact data for visualization and animation event selection.
np.savez(R/'analysis/onsets.npz',times=tt[:int(30*rate)],onsets=onset[:int(30*rate)])
