import {openBrowser} from '@remotion/renderer';
import fs from 'node:fs/promises';
const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium',logLevel:'error'});
try{
 const page=await browser.newPage({context:()=>null,logLevel:'error',indent:false,pageIndex:0,onBrowserLog:null,onLog:()=>{}});
 await page.setViewport({width:1600,height:1000,deviceScaleFactor:1});
 const response=await page.goto({url:'http://localhost:3100/NewWorldOpening',timeout:30000,options:{waitUntil:'load'}});
 await page.evaluate(async()=>{await new Promise(r=>setTimeout(r,5000));});
 const state=await page.evaluate(()=>({title:document.title,text:document.body.innerText.slice(0,1800),svgs:document.querySelectorAll('svg').length}));
 const screenshot=await page._client().send('Page.captureScreenshot',{format:'png'});
 await fs.writeFile('analysis/studio-environment.png',Buffer.from(screenshot.value.data,'base64'));
 await fs.writeFile('analysis/studio-check.json',JSON.stringify({status:response?.status(),...state},null,2));
 console.log(JSON.stringify(state));
}finally{await browser.close({silent:true});}
