from pathlib import Path
import zipfile,json,hashlib
R=Path(__file__).resolve().parents[1];O=R/'output';files=[R/x for x in ['README.md','package.json','package-lock.json','tsconfig.json','requirements-production.txt']]
for d in ['src','scripts','public','assets']:
 files += [p for p in (R/d).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
for n in ['Acceptance.md','quality-check.json','playback-check.json','music-analysis.json','sound-events.json','particle-continuity.json','determinism.json','audio-measurement.log']:files.append(O/n)
zpath=O/'NewWorld-Age-Is-Not-A-Person-Source.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(set(files)):z.write(p,Path('NewWorld-Age-Is-Not-A-Person')/p.relative_to(R))
with zipfile.ZipFile(zpath) as z:assert z.testzip() is None
rows=[]
for p in [O/'NewWorld-Age-Is-Not-A-Person.mp4',zpath,O/'Age-Is-Not-A-Person-Keyframes.pdf',O/'Acceptance.md']:
 rows.append({'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(O/'manifest.json').write_text(json.dumps(rows,indent=2));(O/'SHA256SUMS.txt').write_text('\n'.join(r['sha256']+'  '+r['name'] for r in rows)+'\n');print(json.dumps(rows,indent=2))
