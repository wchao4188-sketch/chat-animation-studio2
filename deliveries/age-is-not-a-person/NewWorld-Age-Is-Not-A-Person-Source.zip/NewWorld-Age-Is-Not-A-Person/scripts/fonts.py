from pathlib import Path
from fontTools import subset
R=Path(__file__).resolve().parents[1];text=''.join(x.read_text() for x in (R/'src').rglob('*.tsx'))
for src,name,num in [('/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc','Display',2),('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc','Text',2),('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf','Mono',0)]:
 o=subset.Options();o.font_number=num;o.flavor='woff';f=subset.load_font(src,o);s=subset.Subsetter(options=o);s.populate(text=text);s.subset(f);subset.save_font(f,R/'public/fonts'/f'{name}.woff',o)
