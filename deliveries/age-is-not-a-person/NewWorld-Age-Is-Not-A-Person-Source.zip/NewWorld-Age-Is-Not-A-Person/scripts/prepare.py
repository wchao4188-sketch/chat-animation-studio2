from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import numpy as np,json,shutil
R=Path(__file__).resolve().parents[1];rng=np.random.default_rng(4242);N=2400
def glyph(s):
 im=Image.new('L',(900,900));d=ImageDraw.Draw(im);f=ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc',650,index=2)
 box=d.textbbox((0,0),s,font=f);d.text(((900-(box[2]-box[0]))/2-box[0],(900-(box[3]-box[1]))/2-box[1]),s,font=f,fill=255)
 a=np.argwhere(np.asarray(im)>170);ids=rng.choice(len(a),N,replace=False);a=a[ids];return [[round((x-450)/450,5),round((y-450)/450,5),round(float(rng.uniform(-.08,.08)),5)] for y,x in a]
data={'count':N,'number':glyph('24'),'question':glyph('？'),'human':glyph('人'),'seed':4242}
(R/'src/shapes.json').write_text(json.dumps(data,separators=(',',':')))
(R/'assets/content-basis.md').write_text('''# 用户图片内容依据

年龄段经验模型：幻想/现实＋感性/理性，仅初始预判，持续修正，非人口统计。

18—20岁：幻想80%/现实20%；体验、新鲜感、浪漫、未来可能性、自我想象；兴趣、游戏、音乐、动漫、短视频、朋友、校园、旅行、恋爱想象、有趣经历；表达轻松、有趣、有情绪感。
21—24岁：幻想65%/现实35%；过渡期，毕业、工作、收入、城市、独立生活；现实做入口，幻想做出口；工作、城市、旅行、感情、朋友、自由、爱好、未来计划、生活方式。
25—27岁：幻想50%/现实50%；经历现实但不放弃精神、爱情、生活期待；避免过早谈房车婚姻，表达个人观点感受；文学、电影、旅行、审美、摄影、城市感受、事业选择、感情观、人生经历。
28—30岁：幻想35%/现实65%；重视稳定、婚恋、时间成本、对方价值评估；现实给安全感，幻想给吸引力；事业、生活方式、旅行、审美、家庭观、感情经历、未来规划，保留浪漫幽默。
31—32岁：幻想25%/现实75%；原图经验描述为趋于稳定，个人特质权重上升；人品、生活稳定性、人生方向、价值观、生活兼容性；事业、生活习惯、情绪稳定、家庭观念、消费观、未来规划。

双独立维度：幻想↔现实是关注重心；感性↔理性是思考方式。
组合示例：现实＋感性，看重硬性条件，同时期待浪漫情绪共鸣；理想＋理性，向往自由理想，讨论时逻辑清晰、会规划。图中标注四种组合，文字仅举两个例子。

动态修正：年龄段起点→个人基础资料→朋友圈/社交动态→实际聊天交互→长期互动，迭代完善人物理解。
最终理解四项：她喜欢什么、她怎么生活、她怎么看世界、她当下核心需求。

影片保留经验模型的非统计性质，不将年龄比例当作心理测量结果；聊天案例为原创虚构，并在画面标注。
''')
print('Prepared',N,'persistent glyph points')
