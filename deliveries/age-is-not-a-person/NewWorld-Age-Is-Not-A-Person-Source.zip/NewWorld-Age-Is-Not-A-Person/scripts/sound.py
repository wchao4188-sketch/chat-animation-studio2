from pathlib import Path
import numpy as np,subprocess,json,hashlib
from scipy.signal import stft,find_peaks,correlate, butter,sosfilt
R=Path(__file__).resolve().parents[1];A=R/'public/audio';O=R/'output';SR=48000;D=96
src=A/'user-music-source.m4a'
mono=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(src),'-t',str(D),'-ac','1','-ar','22050','-f','f32le','-']),'<f4')
f,t,z=stft(mono,22050,nperseg=1024,noverlap=768);m=abs(z);flux=np.maximum(np.diff(m,axis=1),0).sum(axis=0);flux/=max(flux.max(),1e-8)
peaks,_=find_peaks(flux,distance=20,prominence=.055);onsets=t[1:][peaks];ac=correlate(flux,flux,method='fft')[len(flux)-1:];lags=np.arange(len(ac))*256/22050;valid=np.where((lags>60/180)&(lags<60/60))[0];pk,_=find_peaks(ac[valid]);rank=sorted(valid[pk],key=lambda i:ac[i],reverse=True)[:4]
events=[(0.65,'opening reveal'),(2.7,'question morph'),(7.0,'model unfolds'),(9.0,'age band 1'),(10.4,'age band 2'),(11.8,'age band 3'),(13.2,'age band 4'),(14.6,'age band 5'),(22.0,'axes unfold'),(27.0,'independent dimension'),(31.0,'combination 1'),(33.4,'combination 2'),(36.0,'case begins'),(39.3,'hypotheses branch'),(44.0,'ask for context'),(47.0,'new feedback'),(50.2,'model changes'),(53.0,'revision loop'),(57.0,'profile'),(61.0,'social information'),(65.0,'conversation'),(69.0,'long-term interaction'),(73.0,'four directions unfold'),(76.0,'daily life'),(79.0,'world view'),(82.0,'present needs'),(88.0,'human instead of formula'),(90.5,'closing thought')]
timed=[]
for sec,label in events:
 near=min(onsets,key=lambda x:abs(x-sec))
 timed.append({'design_seconds':sec,'nearest_detected_onset':round(float(near),4),'delta_seconds':round(float(near-sec),4),'event':label,'note':'Reading cadence retained; not all events are forced to an onset.'})
energy=[{'start':i,'rms':float(np.sqrt(np.mean(mono[i*22050:min((i+4)*22050,len(mono))]**2)))} for i in range(0,D,4)]
(O/'music-analysis.json').write_text(json.dumps({'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'selection_seconds':[0,D],'bpm_candidates':[{'bpm':round(60/lags[i],3),'autocorrelation':float(ac[i]/ac[0])} for i in rank],'onsets':np.round(onsets,4).tolist(),'energy_4second_windows':energy,'meter_and_downbeats':'Not manually confirmed','events':timed},indent=2))
music=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(src),'-t',str(D),'-ac','2','-ar',str(SR),'-f','f32le','-']),'<f4').reshape(-1,2).copy();music=music[:D*SR];n=len(music);sfx=np.zeros_like(music);rng=np.random.default_rng(20261021)
def add(sec,kind,pan=0):
 length=.7 if kind=='shift' else .22;tt=np.arange(int(length*SR))/SR
 if kind=='shift':
  noise=rng.normal(size=len(tt));noise=sosfilt(butter(2,[350,2400],btype='bandpass',fs=SR,output='sos'),noise);v=noise*np.sin(np.pi*tt/length)**2*.045
 else:v=(np.sin(2*np.pi*(530*tt+280*tt**2))+.28*np.sin(2*np.pi*1390*tt))*np.exp(-tt*28)*(1-np.exp(-tt*180))*.035
 start=int(sec*SR);end=min(n,start+len(v));p=np.array([np.sqrt((1-pan)/2),np.sqrt((1+pan)/2)]);sfx[start:end]+=v[:end-start,None]*p
for i,(sec,label) in enumerate(events):add(sec,'shift' if sec in [7,22,36,53,73,88] else 'touch',np.sin(i*1.7)*.6)
fade=np.minimum(np.arange(n)/SR/1.1,1)*np.minimum((n-1-np.arange(n))/SR/2.0,1);music*=fade[:,None]*.75;sfx*=fade[:,None];master=music+sfx
peak=abs(master).max();gain=.83/max(peak,1e-9);music*=gain;sfx*=gain;master*=gain
import wave
for name,data in [('music',music),('sfx',sfx),('master',master)]:
 with wave.open(str(A/(name+'.wav')),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR);w.writeframes(np.int16(np.clip(data,-1,1)*32767).tobytes())
subprocess.run(['ffmpeg','-v','error','-y','-i',str(A/'master.wav'),'-c:a','aac','-b:a','256k',str(A/'master.m4a')],check=True)
(O/'sound-events.json').write_text(json.dumps({'voiceover':False,'effects':'Original deterministic local synthesis; no sampled real-world recording claim','events':timed,'peak_linear_before_encoding':float(abs(master).max())},indent=2));print('Music and SFX mixed, no narration. BPM candidates:',[round(60/lags[i],2) for i in rank])
