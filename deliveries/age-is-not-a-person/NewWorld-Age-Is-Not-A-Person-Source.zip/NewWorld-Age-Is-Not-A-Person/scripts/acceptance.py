from pathlib import Path
import json
R=Path(__file__).resolve().parents[1];O=R/'output';q=json.loads((O/'quality-check.json').read_text());p=json.loads((O/'playback-check.json').read_text());c=json.loads((O/'particle-continuity.json').read_text());d=json.loads((O/'determinism.json').read_text());m=json.loads((O/'music-analysis.json').read_text())
s=f'''# 新世界｜别用年龄，读完一个人：实际制作与检查

## 文件与规格

1920×1080、16:9、30fps、{q['video']['frames']}帧、{q['container_duration']}秒。H.264 / yuv420p，AAC / 48kHz / 双声道，无新增旁白。
成片 {q['file']['bytes']:,} 字节；SHA-256 `{q['file']['sha256']}`。

## 内容与原创设计

依据本轮图片的年龄经验模型、两个独立维度、五步修正流程、最终四个理解方向，改编为「别用年龄，读完一个人」。年龄比例明确注明非人口统计，不冒充研究结论；换城市聊天示例明确标注虚构。

2400个持续存在的字形粒子贯穿数字、比例、坐标、解释分支、模型更新、四方向和「人」字。采用Remotion与Canvas的确定性轨迹和空间投影，不宣称真实物理求解或离线三维材质渲染。没有新增npm依赖，没有新配音。

## 实际发现并修复

第一轮分支图的粒子遮住了假设文字，后将文字移到端点之外并缩短路径。模型阶段切换时的形变参数存在不连续，改成连续插值。实际边界检查发现7秒投影角度归零造成约11.83像素跳变，改为提前平滑回正，并停止草稿渲染、重新渲染完整成片。删除装饰网格，改用中性深灰背景。

## 技术与画面检查

- FFmpeg完整解码退出码 {q['full_decode']['exit']}，错误输出为空。帧数、分辨率、帧率、时长均从实际MP4读取。
- 全部2880帧进行亮度及相邻差异检查；另提取整片每0.5秒总览、12段密集转场页和高清关键帧，实际查看画面。
- Chromium完整播放到结束 {p['ended']}；共 {p['frames']} 帧、丢帧 {p['dropped']}、媒体错误 {p['error']}。
- 轨迹与投影实际函数的关键边界检查，前后各1微秒最大位移 {c['maximum_boundary_delta_pixels']:.9g} 像素。这是位置连续性检查，不等于物理真实性认证。
- 第1980帧独立重复渲染两次，PNG SHA-256一致：{d['byte_identical']}。

## 声音

音乐使用用户已有素材0—96秒，算法主BPM候选 {m['bpm_candidates'][0]['bpm']}；未人工确认小节重拍。音乐起音与声音事件映射在JSON中，保留文字阅读时间。

总混音AAC实测约 −14.99 LUFS，真峰值 −1.77 dBTP。最终视频解码峰值 {q['audio']['peak_linear']:.6f}，与预定混音相关系数 {q['audio']['reference_correlation']:.6f}，没有数值削波。音效为本地合成；没有新增配音。浏览器播放为静音自动检查，未进行真人试听，不能声称人耳验收已通过。

## 交付与限制

可编辑工程包含Remotion源码、字形采样、字体、音乐音效分轨和制作脚本；不包含node_modules。实际技术检查不能替代主观审美判断，不以「运行成功」声称已经达到最高视觉水准。原有作品、源码和main均未覆盖。
'''
(O/'Acceptance.md').write_text(s);print(s)
