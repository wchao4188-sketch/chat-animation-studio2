# 新世界｜别用年龄，读完一个人

96秒原创无配音知识动态图形视频。1920×1080、16:9、30fps、2880帧。

## 创作依据

用户本轮提供的思维导图。影片主线是「初始预判→两个独立维度→通过聊天验证→持续修正→具体理解一个人」。年龄比例沿用原图，并在画面注明经验设定、非人口统计，不把比例包装成研究或心理测量。

换城市的聊天是原创虚构示例，画面明确标注。没有引用原著故事、实验、真实人物或统计数据。完整图片文字依据保存在 `assets/content-basis.md`；影片为基于其核心内容的原创改编。

## 视觉方法

同一组2400个固定编号的粒子，从实际字形采样出发，连续变成年龄比例、坐标组合空间、解释分支、更新中的概念模型、四个理解方向，最后重组为「人」。固定种子、解析轨迹、深度投影、稳定的阅读停顿，不使用逐帧随机抖动或静态截图拼接。

主要技术为Remotion + React + TypeScript + Canvas。Canvas使用三维坐标与透视投影表现空间，属于程序化动态图形；不是离线三维材质渲染或真实粒子物理模拟。没有新增npm依赖。Noto字体及DejaVu字体许可在 `assets/`。

## 编辑和重合成

- `npm ci` 安装锁文件中的依赖；当前云环境复用已安装的同版本依赖。
- `npm run studio` 打开独立Studio，端口3140。
- `npm run typecheck` 检查源码。
- `npm run render` 输出完整MP4；默认使用Linux `/usr/bin/chromium` 和已安装FFmpeg。
- `src/scenes/` 的七段分别编辑文字和节奏，在Studio中都有单独合成。
- `src/World.tsx` 是连续粒子主体、曲线、深度和投影；`src/shapes.json` 是已生成的字形采样，不需要重新安装系统字体即可正常渲染。
- `scripts/prepare.py` 重新生成字形采样；`scripts/fonts.py` 重新制作字体子集，使用Linux系统Noto字体。
- `scripts/sound.py` 分析音乐并重新生成音乐、音效和混音；Python制作依赖在 `requirements-production.txt`。普通Remotion重合成不需要Python。

完整重建在当前Linux实际运行；没有声称Windows或macOS安装与完整重建已经验证。原有项目和成果保持不动。

## 音乐与声音

使用用户已有音乐的0—96秒，没有新增配音或TTS。`public/audio/music.wav`、`sfx.wav`、`master.wav` 为分轨及总混音；`master.m4a` 用于正式合成。音效是原创本地合成，不冒充实录。

BPM候选来自真实素材的频谱起音与自相关计算，完整结果在 `output/music-analysis.json`。算法候选不等于人工确认的小节重拍。动作与声音使用同一时间轴，重点动作贴近起音，阅读时间优先。

## 实际检查

`scripts/quality.py` 完整解码、检查全部帧基本指标、提取整片每0.5秒总览及密集转场页、检查音轨相关性和峰值。

`scripts/continuity.cjs` 执行实际 `World.tsx` 中的轨迹和投影函数，检查关键边界的位置连续性；`scripts/determinism.mjs` 重复渲染同一帧并比较SHA-256。它们不替代对实际画面的检查。

启动 `python -m http.server 3141 --bind 127.0.0.1 --directory output` 后，运行 `node scripts/playback.mjs` 完整播放最终MP4。该浏览器检查静音，不等于真人试听。最终事实以 `output/Acceptance.md` 和各检查JSON为准，不把技术检查当作主观审美认证。
