export const clamp=(v:number)=>Math.max(0,Math.min(1,v));
export const ease=(v:number)=>{v=clamp(v);return v*v*v*(v*(v*6-15)+10)};
export const ramp=(t:number,a:number,b:number)=>ease((t-a)/(b-a));
export const mix=(a:number,b:number,t:number)=>a+(b-a)*t;
export const seed=(n:number)=>{const x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x)};
export const C={bg:'#101112',white:'#f0f1ed',muted:'#96a0ae',line:'#303a49',blue:'#8b9dff',cyan:'#75d9d0',lime:'#d6ee9b',purple:'#bc9be4'};
export type Point={x:number;y:number;z:number};
export const lerpP=(a:Point,b:Point,t:number):Point=>({x:mix(a.x,b.x,t),y:mix(a.y,b.y,t),z:mix(a.z,b.z,t)});
