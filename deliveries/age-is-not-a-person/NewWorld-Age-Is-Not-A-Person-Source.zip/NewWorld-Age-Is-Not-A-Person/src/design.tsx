import React from'react';import{useCurrentFrame,useVideoConfig}from'remotion';import{C,ramp}from'./math';
export const useTime=()=>{const f=useCurrentFrame(),{fps}=useVideoConfig();return f/fps};
export const Label=({children,style={}}:{children:React.ReactNode;style?:React.CSSProperties})=><div style={{fontSize:22,letterSpacing:3,color:C.muted,...style}}>{children}</div>;
export const Title=({children,style={}}:{children:React.ReactNode;style?:React.CSSProperties})=><div style={{fontFamily:'Display',fontSize:70,fontWeight:700,lineHeight:1.3,letterSpacing:-2,whiteSpace:'pre-line',...style}}>{children}</div>;
export const Copy=({children,style={}}:{children:React.ReactNode;style?:React.CSSProperties})=><div style={{fontSize:31,lineHeight:1.7,color:C.muted,whiteSpace:'pre-line',...style}}>{children}</div>;
export const Reveal=({children,at=0,style={}}:{children:React.ReactNode;at?:number;style?:React.CSSProperties})=>{const t=useTime(),p=ramp(t,at,at+.65);return <div style={{opacity:p,translate:`0 ${22*(1-p)}px`,...style}}>{children}</div>};
export const Left=({children,style={}}:{children:React.ReactNode;style?:React.CSSProperties})=><div style={{position:'absolute',left:110,top:255,width:600,...style}}>{children}</div>;
