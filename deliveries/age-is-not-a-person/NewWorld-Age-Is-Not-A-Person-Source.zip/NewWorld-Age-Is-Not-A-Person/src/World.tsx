import React,{useLayoutEffect,useRef} from 'react';
import {useCurrentFrame,useVideoConfig} from 'remotion';
import shapes from './shapes.json';
import{C,Point,ease,ramp,mix,seed,lerpP,clamp}from'./math';
const N=shapes.count,TAU=Math.PI*2;
const colors=[C.blue,C.cyan,C.lime,C.purple];
const shape=(pts:number[][],i:number,cx:number,cy:number,s:number):Point=>({x:cx+pts[i][0]*s,y:cy+pts[i][1]*s,z:pts[i][2]*220});
const number=(i:number)=>shape(shapes.number,i,1330,550,510);
const question=(i:number)=>shape(shapes.question,i,1330,550,480);
const human=(i:number)=>shape(shapes.human,i,1340,550,490);
const ages=[.80,.65,.50,.35,.25];
function bars(i:number):Point{
 const row=Math.floor(i/480),j=i%480,u=(j%80)/79,v=Math.floor(j/80)/5;
 return{x:815+u*850,y:320+row*116+(v-.5)*34,z:(seed(i+77)-.5)*22};
}
function axes(i:number):Point{
 const a=seed(i+1)*TAU,r=Math.sqrt(seed(i+9));return{x:1280+Math.cos(a)*r*375,y:550+Math.sin(a)*r*295,z:(seed(i+25)-.5)*90};
}
function example(i:number,t:number):Point{
 const group=i%3,u=seed(i+2),sweep=ramp(t,47.0,50.3),g=mix(group,2,sweep),yend=335+g*210;
 const x=900+u*540,y=mix(500,yend,ease(u))+Math.sin(u*Math.PI)*(-80+group*50);
 return{x,y:y+(seed(i+11)-.5)*22*(1-sweep*.5),z:Math.sin(u*Math.PI*2+group)*40};
}
function model(i:number,t:number):Point{
 const phase=Math.max(0,(t-53)/4),stage=Math.min(4,Math.floor(phase)),moving=ramp(t,53+stage*4,54.4+stage*4);
 const a=seed(i+1)*TAU,b=Math.acos(2*seed(i+11)-1),turn=mix(stage,stage+1,moving)*.32;
 const rr=270*(.86+seed(i+8)*.14),x=Math.sin(b)*Math.cos(a+turn),y=Math.cos(b),z=Math.sin(b)*Math.sin(a+turn);
 const d=.08*Math.sin(3*a+(stage+moving)*.8)*Math.sin(b)**2;
 return{x:1330+(rr+d*140)*x,y:545+(rr+d*120)*y*.9,z:z*rr};
}
const centers=[[1090,345],[1580,345],[1090,740],[1580,740]];
function four(i:number):Point{
 const k=Math.floor(i/600),j=i%600,a=j/600*TAU*4,r=110+(seed(i+3)-.5)*12;
 return{x:centers[k][0]+Math.cos(a)*r,y:centers[k][1]+Math.sin(a)*r*.72,z:Math.sin(a)*58+(seed(i+9)-.5)*16};
}
export function pose(i:number,t:number):Point{
 if(t<2.1)return number(i);
 if(t<4)return lerpP(number(i),question(i),ramp(t,2.1+seed(i)*.2,3.8+seed(i)*.2));
 if(t<7)return question(i);
 if(t<9.1){const p=ramp(t,7+seed(i)*.3,8.8+seed(i)*.3);return lerpP(question(i),bars(i),p)}
 if(t<22)return bars(i);
 if(t<24)return lerpP(bars(i),axes(i),ramp(t,22+seed(i)*.15,23.7+seed(i)*.15));
 if(t<36)return axes(i);
 if(t<38)return lerpP(axes(i),example(i,t),ramp(t,36+seed(i)*.1,37.8+seed(i)*.1));
 if(t<53)return example(i,t);
 if(t<55)return lerpP(example(i,52),model(i,t),ramp(t,53+seed(i)*.15,54.8+seed(i)*.15));
 if(t<73)return model(i,t);
 if(t<75)return lerpP(model(i,72.99),four(i),ramp(t,73+seed(i)*.15,74.8+seed(i)*.15));
 if(t<88)return four(i);
 if(t<90.2)return lerpP(four(i),human(i),ramp(t,88+seed(i)*.3,89.9+seed(i)*.3));
 return human(i);
}
export const project=(p:Point,t:number)=>{
 const yaw=t<7?mix(-.18,.15,ramp(t,0,5.5))*(1-ramp(t,5.4,7)):t>88?mix(0,-.12,ramp(t,89,92)):0;
 const xx=p.x-1280,x=xx*Math.cos(yaw)+p.z*Math.sin(yaw),z=-xx*Math.sin(yaw)+p.z*Math.cos(yaw),s=1800/(1800+z);
 return{x:1280+x*s,y:540+(p.y-540)*s,z,s};
};
function draw(ctx:CanvasRenderingContext2D,t:number){
 ctx.fillStyle=C.bg;ctx.fillRect(0,0,1920,1080);
 const bg=ctx.createRadialGradient(1350,450,30,1350,500,1050);bg.addColorStop(0,'#292b2d');bg.addColorStop(.55,'#191b1d');bg.addColorStop(1,C.bg);ctx.fillStyle=bg;ctx.fillRect(0,0,1920,1080);
 const line=(a:Point,b:Point,color:string,alpha=1,w=1)=>{const p=project(a,t),q=project(b,t);ctx.strokeStyle=color;ctx.lineWidth=w;ctx.globalAlpha=alpha;ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(q.x,q.y);ctx.stroke();ctx.globalAlpha=1};
 // The age rows are a single particle structure; split markers carry the hypothetical proportions.
 if(t>=7&&t<24){const a=ramp(t,7.7,9)*(1-ramp(t,22,23.7));for(let row=0;row<5;row++){
  const y=320+row*116,split=815+ages[row]*850;line({x:815,y:y+38,z:0},{x:1665,y:y+38,z:0},C.line,a);
  line({x:split,y:y-35,z:0},{x:split,y:y+35,z:0},C.white,a*.65,1.2);
 }}
 // Two axes are perpendicular, and their semantic ends remain stationary while examples move.
 if(t>=22&&t<38){const a=ramp(t,22,23.5)*(1-ramp(t,36,37.7));
  for(const d of [-2,-1,0,1,2]){line({x:850,y:550+d*115,z:0},{x:1710,y:550+d*115,z:0},C.line,a*.45);line({x:1280+d*150,y:225,z:0},{x:1280+d*150,y:875,z:0},C.line,a*.45)}
  line({x:850,y:550,z:0},{x:1710,y:550,z:0},C.blue,a,1.4);line({x:1280,y:225,z:0},{x:1280,y:875,z:0},C.cyan,a*ramp(t,26,27.5),1.4);
  const pos=[{x:1500,y:735,z:0},{x:1055,y:365,z:0}],cur=t<33.1?0:1,active=ramp(t,30.1,31)*(1-ramp(t,35.3,36));
  const p=project(pos[cur],t);ctx.globalAlpha=a*active;ctx.fillStyle=C.lime;ctx.beginPath();ctx.arc(p.x,p.y,10,0,TAU);ctx.fill();ctx.strokeStyle=C.lime;ctx.lineWidth=1.3;ctx.beginPath();ctx.arc(p.x,p.y,25,0,TAU);ctx.stroke();ctx.globalAlpha=1;
 }
 if(t>=36&&t<55){const a=ramp(t,36,37.7)*(1-ramp(t,53,54.8)),focus=ramp(t,47,49);
  for(let k=0;k<3;k++){ctx.globalAlpha=a*(k===2?1:1-focus*.82);ctx.strokeStyle=k===2?C.lime:C.blue;ctx.lineWidth=k===2?1.8:1;ctx.beginPath();ctx.moveTo(900,500);ctx.bezierCurveTo(1080,500,1200,335+k*210,1440,335+k*210);ctx.stroke()}
  ctx.globalAlpha=1;
 }
 if(t>=53&&t<75){const a=ramp(t,53,54.8)*(1-ramp(t,73,74.8)),stage=Math.min(4,Math.floor(Math.max(0,t-53)/4)),turn=stage*.32+ramp(t,53+stage*4,54.4+stage*4)*.32;
  for(let ring=0;ring<8;ring++){ctx.strokeStyle=ring%2?C.blue:C.cyan;ctx.lineWidth=.6;ctx.globalAlpha=a*.18;ctx.beginPath();for(let j=0;j<=100;j++){const th=j/100*TAU,ph=(ring/8)*Math.PI,rr=270;const p=project({x:1330+Math.cos(th+turn)*Math.sin(ph)*rr,y:545+Math.cos(ph)*rr*.9,z:Math.sin(th+turn)*Math.sin(ph)*rr},t);if(j===0)ctx.moveTo(p.x,p.y);else ctx.lineTo(p.x,p.y)}ctx.stroke()}
  const nodes=[[710,534],[710,620],[710,706],[710,792],[710,878]];for(let k=0;k<=stage;k++){const [x,y]=nodes[k],q=ramp(t,53+k*4,54.3+k*4);line({x,y,z:0},lerpP({x,y,z:0},{x:1140,y:500+(k-2)*35,z:30},q),k===stage?C.lime:C.line,a,.9)}ctx.globalAlpha=1;
 }
 if(t>=73&&t<90){const a=ramp(t,73,74.6)*(1-ramp(t,88,89.8));for(const [x,y]of centers){line({x,y,z:0},{x:1335,y:542,z:40},C.line,a,.8)}
  ctx.globalAlpha=a*.6;ctx.strokeStyle=C.line;ctx.beginPath();ctx.ellipse(1335,542,34,34,0,0,TAU);ctx.stroke();ctx.globalAlpha=1;
 }
 const points=[];for(let i=0;i<N;i++){
  const p=pose(i,t),q=project(p,t);let color=C.blue;
  if(t>=7&&t<23){const row=Math.floor(i/480),u=(i%80)/79;color=u<ages[row]?C.blue:C.cyan}
  else if(t>=36&&t<53)color=i%3===2?C.lime:C.blue;
  else if(t>=73&&t<89)color=colors[Math.floor(i/600)];else color=i%5===0?C.lime:i%3===0?C.cyan:C.blue;
  points.push({i,p,q,color});
 }points.sort((a,b)=>b.q.z-a.q.z);
 for(const {i,p,q,color}of points){ctx.fillStyle=color;ctx.globalAlpha=.42+.5*clamp((300-q.z)/550);const radius=(.9+seed(i+55)*1.2)*q.s;
  ctx.beginPath();ctx.arc(q.x,q.y,radius,0,TAU);ctx.fill();
  // Very short deterministic trails show velocity only while the object is actually transforming.
  if(i%9===0){const old=project(pose(i,Math.max(0,t-.025)),t),speed=Math.hypot(old.x-q.x,old.y-q.y);if(speed>2){ctx.globalAlpha=.19;ctx.strokeStyle=color;ctx.lineWidth=radius*.75;ctx.beginPath();ctx.moveTo(old.x,old.y);ctx.lineTo(q.x,q.y);ctx.stroke()}}
 }ctx.globalAlpha=1;
 // Static fine texture, fixed by seed: no frame-to-frame noise or decorative drifting.
 ctx.fillStyle='#e7eef7';ctx.globalAlpha=.025;for(let i=0;i<900;i++)ctx.fillRect(seed(i+10000)*1920,seed(i+20000)*1080,1,1);ctx.globalAlpha=1;
}
export const World=({offset=0}:{offset?:number})=>{const frame=useCurrentFrame(),{fps}=useVideoConfig(),ref=useRef<HTMLCanvasElement>(null);useLayoutEffect(()=>{const ctx=ref.current?.getContext('2d');if(ctx)draw(ctx,frame/fps+offset)},[frame,fps,offset]);return <canvas ref={ref} width={1920} height={1080} style={{position:'absolute',width:1920,height:1080}}/>};
